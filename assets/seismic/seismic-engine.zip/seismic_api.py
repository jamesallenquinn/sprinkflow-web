# -*- coding: utf-8 -*-
"""Seismic bracing tool API layer for the SprinkFlow desktop app.

Thin orchestration over the seismic_bracing engine: assembles a full brace
calculation (demand -> every constraint -> overall verdict with provenance),
the spacing optimizer, and the export renderers. Exports per the owner spec:
a clean professional PDF and a full-page 8.5x11 PNG at >= 150 dpi for pasting
onto shop-drawing sheets (rendered from the SAME PDF so they always match).
"""
from __future__ import annotations

import io
import json
import re
from datetime import datetime
from pathlib import Path

from seismic_bracing import ENGINE_VERSION, editions
from seismic_bracing import assembly, branch_restraint, fastener_capacity
from seismic_bracing import lateral_bracing, member_capacity, net_vertical, seismic_demand
from seismic_bracing.datasets import (DATA_DIR, NotInEdition, SourceDataRequired,
                                      load_component_dataset, load_json, load_slot)
from seismic_bracing.units import IMPERIAL, Qty

MANUFACTURER_KEYS = {"TOLCO": "tolco", "nVent CADDY": "caddy", "AFCON": "afcon"}


# --- meta --------------------------------------------------------------------

def seismic_meta():
    """Everything the UI needs to build its pickers."""
    from seismic_bracing.datasets import load_table
    editions_meta = []
    for ed in editions.EDITIONS:
        info = editions.edition_info(ed)
        editions_meta.append(info)
    components = {}
    for label, key in MANUFACTURER_KEYS.items():
        try:
            data = load_component_dataset(key)
        except SourceDataRequired:
            continue
        comps = []
        for c in data["components"]:
            sizes = []
            for s in c.get("sizes", []):
                rated = [r for r in s.get("ratedLoads", [])
                         if isinstance(r.get("loadLb"), (int, float))]
                if rated:
                    sizes.append(s["size"])
            if sizes:
                comps.append({"figure": c["figure"], "name": c.get("name", ""),
                              "role": c.get("role", ""), "sizes": sizes})
        components[label] = comps
    members = []
    t = load_table("18.5.11.8(a)")
    for r in t["rows"]:
        members.append({"category": r["member_category"], "size": r["member_size"],
                        "r": r["values"].get("Least Radius of Gyration (r) (in.)")})
    braced_tables = []
    for p in sorted((DATA_DIR / "nfpa13_2025" / "tables").glob("18.5.5.2_*.json")):
        d = load_json(p)
        if d.get("units") == "imperial":
            braced_tables.append({"id": d["identifier"].replace("Table ", ""),
                                  "title": d.get("title", ""),
                                  "sizes": [r["key"] for r in d.get("rows", [])]})
    for p in sorted((DATA_DIR / "manufacturer_tables").glob("*.json")) if (DATA_DIR / "manufacturer_tables").exists() else []:
        d = load_json(p)
        braced_tables.append({"id": d["identifier"].replace("Table ", ""),
                              "title": d.get("title", ""),
                              "sizes": [r["key"] for r in d.get("rows", [])]})
    fastener_tables = []
    for p in sorted((DATA_DIR / "nfpa13_2025" / "tables").glob("18.5.12.2_*.json")):
        d = load_json(p)
        # the concrete-anchor tables repeat each diameter once per prying
        # band - the UI picks the band separately, so sizes are deduped here
        bands = fastener_capacity.pr_bands(d)
        keys = []
        for r in bands[0][1] if bands[0][0] else (d.get("lookup_rows") or d.get("rows") or []):
            if any(isinstance(v, (int, float)) for v in r.get("values", {}).values()) \
                    and r["key"] not in keys:
                keys.append(r["key"])
        if keys:
            fastener_tables.append({"id": d["identifier"].replace("Table ", ""),
                                    "title": d.get("title", ""), "sizes": keys,
                                    "prBands": [b[0] for b in bands if b[0]]})
    restraint_tables = []
    for p in sorted((DATA_DIR / "nfpa13_2025" / "tables").glob("18.6.4_*.json")):
        d = load_json(p)
        restraint_tables.append({"id": d["identifier"].replace("Table ", ""),
                                 "title": d.get("title", ""),
                                 "sizes": [r["key"] for r in d.get("rows", [])]})
    detail_library = []
    try:
        dl = load_json(DATA_DIR / "details" / "details.json")
        detail_library = [{"name": d["name"], "file": d["file"]} for d in dl.get("details", [])]
    except Exception:
        pass
    pipe_weights = []
    for r in load_slot("pipe_weights.json").get("rows", []):
        size, sched = r.get("size"), r.get("schedule_or_type")
        if isinstance(size, str) and size.endswith("*"):
            # Table A.18.5.9 footnote: the starred 8 in. row is Schedule 30
            size, sched = size.rstrip("*"), "Schedule 30"
        pipe_weights.append({"material": r.get("material"), "schedule": sched,
                             "size": size, "lbPerFt": r.get("lb_per_ft")})
    for extra in ("pipe_weights_sch7.json", "pipe_weights_cpvc.json", "pipe_weights_megaflow.json"):
        try:
            for r in load_slot(extra).get("rows", []):
                pipe_weights.append({"material": r.get("material"), "schedule": r.get("schedule_or_type"),
                                     "size": r.get("size"), "lbPerFt": r.get("lb_per_ft")})
        except Exception:
            pass  # manufacturer data is additive - never blocks meta
    return {"editions": editions_meta, "components": components, "members": members,
            "bracedPipeTables": braced_tables, "fastenerTables": fastener_tables,
            "restraintTables": restraint_tables,
            "detailLibrary": detail_library,
            "pipeWeights": pipe_weights,
            "orientations": list(fastener_capacity.ORIENTATION_PHRASES),
            "redbuiltMembers": _redbuilt_details().get("details", []),
            "engineVersion": ENGINE_VERSION}


# --- calc --------------------------------------------------------------------

def _height_multiplier(z_ft, h_ft):
    """NFPA 13 2025 attachment-height Cp reduction from the ratio of component
    attachment height (z) to average roof height (h): 18.5.9.3.4 (< 50%) x 0.75,
    18.5.9.3.3 (50-75%) x 0.875, above that no reduction. Returns
    (multiplier_or_None, ratio_or_None, note)."""
    try:
        z, h = float(z_ft), float(h_ft)
    except (TypeError, ValueError):
        return None, None, ""
    if not (z >= 0 and h > 0):
        return None, None, ""
    r = z / h
    if r < 0.50:
        return 0.75, r, "18.5.9.3.4: attachment < 50% of avg roof height, Cp x 0.75"
    if r <= 0.75:
        return 0.875, r, "18.5.9.3.3: attachment 50-75% of avg roof height, Cp x 0.875"
    return None, r, "attachment > 75% of avg roof height - no Cp reduction"


def _redbuilt_details():
    try:
        return load_json(DATA_DIR / "redbuilt_members.json")
    except Exception:
        return {"details": []}


def _redbuilt_band(angle_deg):
    """The RedBuilt load columns (30/45/60) map to the NFPA brace-angle bands."""
    a = float(angle_deg)
    return "30" if a < 45 else ("45" if a < 60 else "60")


def redbuilt_capacity(detail_id, angle_deg):
    """Allowable horizontal seismic load (lb) for a RedBuilt structural-member
    detail at the brace angle's band, with provenance. Returns
    (ConstraintResult-ready dict) or None if the detail is unknown."""
    data = _redbuilt_details()
    det = next((d for d in data.get("details", []) if d["id"] == detail_id), None)
    if not det:
        return None
    band = _redbuilt_band(angle_deg)
    load = det.get("loadLb", {}).get(band)
    return {
        "detail": det, "band": band, "loadLb": load,
        "provenance": f"RedBuilt {det['id']} ({det['member']}), allowable {load} lb at "
                      f"{band} deg band (incl. 1.60 duration factor); {data.get('identifier', '')}",
    }


def _resolve_cp(edition, seismic):
    if seismic.get("cp") is not None:
        return float(seismic["cp"]), "Cp entered directly"
    mult, ratio, hnote = _height_multiplier(seismic.get("attachHeightFt"), seismic.get("roofHeightFt"))
    kwargs, extra = {}, ""
    if ratio is not None:
        if mult is not None and editions.edition_uses_height_reduction(edition):
            kwargs["height_multiplier"] = mult
            extra = f" x {mult} ({hnote}; z/h = {ratio:.2f})"
        elif mult is not None:
            extra = f" (height reduction is not part of this edition's Cp method; z/h = {ratio:.2f})"
        else:
            extra = f" ({hnote}; z/h = {ratio:.2f})"
    if seismic.get("sds") is not None:
        cp = editions.seismic_coefficient(edition, sds=float(seismic["sds"]), **kwargs)
        return cp, f"Cp from SDS = {seismic['sds']} per {editions.EDITION_LABELS[edition]}{extra}"
    if seismic.get("ss") is not None:
        cp = editions.seismic_coefficient(edition, ss=float(seismic["ss"]), **kwargs)
        return cp, f"Cp from Ss = {seismic['ss']} per {editions.EDITION_LABELS[edition]}{extra}"
    raise ValueError("Provide Cp directly, or SDS/Ss per the edition's method.")


def _component_capacities(payload, angle_deg, edition):
    """Returns (ComponentCapacity list for the check, display rows for the
    report's Listed/Adjusted components table)."""
    comps, rows = [], []
    for c in payload.get("components", []):
        if c.get("manual"):
            m = c["manual"]
            listed = float(m["ratedLb"])
            applied, prov = listed, (m.get("provenance") or "user-entered listed rating")
            if m.get("applyAngleAdjustment"):
                applied, adj_prov = assembly.adjusted_listed_load(listed, angle_deg, edition=edition)
                prov += f"; {adj_prov}"
            comps.append(assembly.ComponentCapacity(
                m.get("role", "component"), m.get("description", "manual component"),
                Qty(applied, "lb", IMPERIAL), prov))
            rows.append({"component": m.get("description", "manual component"),
                         "listedLb": listed, "appliedLb": round(applied, 1),
                         "basis": "manual entry" + (" (angle-adjusted)" if m.get("applyAngleAdjustment") else "")})
            continue
        key = MANUFACTURER_KEYS.get(c["manufacturer"])
        desc = f"{c['manufacturer']} {c['figure']} {c['size']}"
        try:
            d = assembly.resolve_component_rating_detail(key, c["figure"], c["size"],
                                                         angle_deg, edition=edition)
            comps.append(assembly.ComponentCapacity(
                c.get("role", "component"), desc, Qty(d["appliedLb"], "lb", IMPERIAL), d["provenance"]))
            rows.append({"component": desc, "listedLb": d["listedLb"],
                         "appliedLb": round(d["appliedLb"], 1),
                         "basis": f"{d['listing']} @ {d['angleSpec']}"
                                  + (" (adjusted per Table 18.5.2.3)" if d["adjusted"] else "")
                                  + (" — HISTORICAL S.F. 1.5 basis" if d.get("historical") else "")})
        except SourceDataRequired as exc:
            comps.append(assembly.ComponentCapacity(
                c.get("role", "component"), desc, None, pending_identifier=exc.identifier))
            rows.append({"component": desc, "listedLb": None, "appliedLb": None,
                         "basis": f"pending: {exc.identifier}"})
    return comps, rows


def _adjudicate_condition(tail, brace_type, payload, member_resolved):
    """Auto-verdict for conditions the calc inputs already answer. Returns
    (verdict, reason) with verdict in {'ok', 'na', None}. Conservative: only
    conditions fully determined by the selected inputs auto-resolve; anything
    needing field knowledge stays a manual checkbox."""
    f_table = str((payload.get("fastener") or {}).get("tableId") or "")
    if tail.startswith("5.11.11"):
        # powder-driven prohibition: every published 18.5.12.2 table is a
        # wedge anchor / insert / bolt / lag - none are powder-driven
        if f_table:
            return "na", f"not triggered — the selected fastener (Table {f_table}) is not powder-driven"
        return None, ""
    if tail.startswith("5.11.9.1"):
        return "ok", "satisfied by this calculation sheet — include it in the submittal where the AHJ requires"
    if tail.startswith("5.11.9") and member_resolved:
        return "ok", "the brace member resolves in the published Table 18.5.11.8 — no separate PE certification needed"
    if tail.startswith("5.11.6") and brace_type != "longitudinal":
        return "na", f"applies to longitudinal braces only — this is a {brace_type} brace"
    return None, ""


def _conditions_checklist(edition, brace_type, payload=None, member_resolved=False):
    try:
        data = load_slot("condition_resolutions.json", edition=edition)
    except (SourceDataRequired, NotInEdition):
        return []
    entries = data if isinstance(data, list) else (data.get("condition_resolutions")
                                                   or data.get("resolutions") or data.get("entries") or [])
    wanted_suffixes = ["5.13", "5.11."]
    if brace_type == "lateral":
        wanted_suffixes += ["5.5.4", "5.5.9", "5.5.5"]
    elif brace_type == "longitudinal":
        wanted_suffixes += ["5.6.", "5.7."]
    elif brace_type == "riser":
        wanted_suffixes += ["5.8."]
    out = []
    for e in entries:
        sec = str(e.get("section", ""))
        tail = sec.replace("18.", "", 1) if sec.startswith("18.") else sec.replace("9.3.", "", 1)
        if any(tail.startswith(sfx) for sfx in wanted_suffixes):
            verdict, reason = _adjudicate_condition(tail, brace_type, payload or {}, member_resolved)
            out.append({"section": sec, "logic": str(e.get("logic", ""))[:400],
                        "verdict": verdict, "reason": reason})
    return out[:10]


def seismic_calc(payload):
    edition = payload.get("edition", "2025")
    brace = payload["brace"]
    angle = float(brace["angleDeg"])
    spacing = float(payload.get("spacingFt") or 0)
    brace_type = payload.get("braceType", "lateral")

    cp, cp_basis = _resolve_cp(edition, payload.get("seismic", {}))

    _s = payload.get("seismic") or {}
    _hm, _hr, _hnote = _height_multiplier(_s.get("attachHeightFt"), _s.get("roofHeightFt"))
    if _hr is None:
        cp_height_note = None
    elif _hm is not None and editions.edition_uses_height_reduction(edition):
        cp_height_note = f"Attachment height reduction (z/h = {_hr:.2f}): {_hnote}"
    else:
        cp_height_note = f"Attachment height z/h = {_hr:.2f} ({_hnote})"

    zoi = seismic_demand.ZoneOfInfluence(concentrated_lb=float(payload.get("concentratedLb") or 0))
    for run in payload.get("zoi", []):
        zoi.add(run.get("label") or "pipe", Qty(float(run["weightPerFt"]), "lb/ft", IMPERIAL),
                float(run["lengthFt"]))
    wp = seismic_demand.zone_weight(zoi, edition=edition)
    fpw = seismic_demand.horizontal_seismic_force(cp, wp)
    fv = net_vertical.brace_vertical_reaction(fpw, angle)

    constraints = []
    if brace_type == "lateral" and spacing:
        constraints.append(lateral_bracing.check_max_spacing(spacing, edition=edition))
    if brace_type == "longitudinal" and spacing:
        constraints.append(lateral_bracing.check_max_longitudinal_spacing(spacing, edition=edition))
    bp = payload.get("bracedPipe") or {}
    if bp.get("tableId") and spacing and brace_type == "lateral":
        constraints.append(lateral_bracing.check_braced_pipe_stress(
            fpw, bp["tableId"], bp["size"], spacing, edition=edition))
    member_check = member_capacity.check_member(
        fpw, brace["memberCategory"], brace["memberSize"], float(brace["lengthIn"]),
        angle, edition=edition)
    constraints.append(member_check)
    comps, component_rows = _component_capacities(payload, angle, edition)
    if comps:
        constraints.append(assembly.assembly_check(fpw, comps))
    f = payload.get("fastener") or {}
    if f.get("tableId"):
        constraints.append(fastener_capacity.check_fastener(
            fpw, f["tableId"], f["size"], angle, f.get("orientation", "horizontal"),
            edition=edition, pr_band=int(f.get("prBand") or 0)))

    sm = payload.get("structureMember") or {}
    if sm.get("system") == "redbuilt" and sm.get("detailId"):
        rb = redbuilt_capacity(sm["detailId"], angle)
        if rb and rb.get("loadLb"):
            cap = Qty(float(rb["loadLb"]), "lb", IMPERIAL)
            ok = fpw.value <= cap.value
            constraints.append(assembly.ConstraintResult(
                f"RedBuilt {rb['detail']['id']} structure member", assembly.PASS if ok else assembly.FAIL,
                ("RedBuilt Sprinkler System Installation Guide",),
                fpw, cap, governing=rb["detail"]["id"],
                detail=f"{rb['detail']['name']} - allowable {rb['loadLb']} lb at "
                       f"{rb['band']} deg band (incl. 1.60 duration factor)"))

    statuses = [c.status for c in constraints]
    overall = ("FAIL" if "FAIL" in statuses
               else "UNAVAILABLE" if "UNAVAILABLE" in statuses
               else "PASS")
    # ---- governing (weakest) element of the load path -----------------------
    # The assembly is only as strong as its least-margin element: upsizing
    # anything else buys nothing until THAT element changes.  Identify it as an
    # object (not just a label) so the UI can highlight the exact row and state
    # the allowable load and the reason for it.  A failing element always
    # governs over a passing one.
    def _margin(c):
        if c.capacity is None or c.demand is None:
            return None
        return c.capacity.value - c.demand.value

    rated = [c for c in constraints if _margin(c) is not None]
    governing_constraint = None
    if overall == "FAIL":
        failed = [c for c in constraints if c.status == "FAIL"]
        failed_rated = [c for c in failed if _margin(c) is not None]
        governing_constraint = (min(failed_rated, key=_margin) if failed_rated
                                else (failed[0] if failed else None))
    elif rated:
        governing_constraint = min(rated, key=_margin)

    governing = ""
    if governing_constraint is not None:
        governing = governing_constraint.governing or governing_constraint.name

    def cdict(c):
        margin = _margin(c)
        return {"name": c.name, "status": c.status,
                "demandLb": round(c.demand.value, 1) if c.demand else None,
                "capacity": round(c.capacity.value, 1) if c.capacity else None,
                "capacityUnit": c.capacity.unit if c.capacity else None,
                "marginLb": round(margin, 1) if margin is not None else None,
                "isGoverning": c is governing_constraint,
                "governing": c.governing, "detail": c.detail,
                "refs": list(c.nfpa_refs), "pending": list(c.pending)}

    def governing_dict():
        c = governing_constraint
        if c is None:
            return None
        margin = _margin(c)
        return {"name": c.name, "status": c.status,
                "element": c.governing or c.name,
                "capacityLb": round(c.capacity.value, 1) if c.capacity else None,
                "capacityUnit": c.capacity.unit if c.capacity else None,
                "demandLb": round(c.demand.value, 1) if c.demand else None,
                "marginLb": round(margin, 1) if margin is not None else None,
                "why": c.detail, "refs": list(c.nfpa_refs)}

    # detail blocks for the TOLBrace-style calc sheet
    try:
        r_in = member_capacity.member_radius(brace["memberCategory"], brace["memberSize"],
                                             edition=edition)
    except Exception:
        r_in = None
    length_in = float(brace["lengthIn"])
    member_detail = {
        "category": brace["memberCategory"], "size": brace["memberSize"],
        "lengthIn": length_in,
        "lengthFtIn": f"{int(length_in // 12)}' {round(length_in % 12):g}\"",
        "r": r_in, "lr": round(length_in / r_in) if r_in else None,
        "maxLoadLb": member_check.capacity.value if member_check.capacity else None,
    }
    fastener_detail = None
    f = payload.get("fastener") or {}
    if f.get("tableId"):
        fastener_detail = {"tableTitle": "", "size": f.get("size"),
                           "orientation": f.get("orientation"), "category": None,
                           "maxLoadLb": None}
        try:
            from seismic_bracing.datasets import load_table as _lt
            title = _lt(f["tableId"], edition=edition).get("title", "")
            import re as _re
            fastener_detail["tableTitle"] = _re.sub(r"^Max(?:imum)? (?:Fpw \(lb\) for )?(?:Maximum )?Load for\s*", "", title)
        except Exception:
            pass
        try:
            fastener_detail["category"] = fastener_capacity.angle_category(
                angle, f.get("orientation", "horizontal"), edition=edition)
        except Exception:
            pass
        fast_check = next((c for c in constraints if c.name == "fastener capacity"), None)
        if fast_check and fast_check.capacity:
            fastener_detail["maxLoadLb"] = fast_check.capacity.value
        try:
            from seismic_bracing.datasets import find_row, load_table as _lt2
            _tbl = _lt2(f["tableId"], edition=edition)
            _bands = fastener_capacity.pr_bands(_tbl)
            _bi = min(max(int(f.get("prBand") or 0), 0), len(_bands) - 1)
            if _bands[_bi][0]:
                fastener_detail["prBandLabel"] = _bands[_bi][0]
            _sub = dict(_tbl)
            _sub.pop("rows", None)
            _sub["lookup_rows"] = _bands[_bi][1]
            frow = find_row(_sub, f["size"])
            install = {}
            for label_key, out_key in (("Min. Nom. Embedment (in.)", "embedmentIn"),
                                       ("Min. Slab Thickness (in.)", "slabThicknessIn"),
                                       ("Min. Edge Distance (in.)", "edgeDistanceIn"),
                                       ("Max. Flute Center Offset (in.)", "fluteOffsetIn")):
                v = frow.get("values", {}).get(label_key)
                if isinstance(v, (int, float)):
                    install[out_key] = v
            prying = {k: v for k, v in frow.get("values", {}).items()
                      if str(k).startswith("Pr") and v is not None}
            fastener_detail["install"] = install
            if prying:
                fastener_detail["prying"] = prying
        except Exception:
            fastener_detail["install"] = {}

    subtotal = sum(r.weight_per_ft.value * r.length_ft for r in zoi.runs) + zoi.concentrated_lb
    max_fpw_check = next((c for c in constraints if c.name == "braced pipe ZOI stress"), None)

    return {
        "edition": edition, "editionLabel": editions.EDITION_LABELS[edition],
        "editionInfo": editions.edition_info(edition),
        "cp": round(cp, 4), "cpBasis": cp_basis,
        "cpLookup": (payload.get("seismic") or {}).get("lookupNote"),
        "cpHeight": cp_height_note,
        "wpLb": round(wp.value, 1), "fpwLb": round(fpw.value, 1),
        "subtotalLb": round(subtotal, 1),
        "allowanceFactor": round(wp.value / subtotal, 3) if subtotal else None,
        "verticalReactionLb": round(fv.value, 1),
        "spacingFt": spacing, "braceType": brace_type,
        "bracedPipe": {"tableId": bp.get("tableId"), "size": bp.get("size")},
        "maxFpwLb": max_fpw_check.capacity.value if (max_fpw_check and max_fpw_check.capacity) else None,
        "zoi": [{"label": r.label, "weightPerFt": r.weight_per_ft.value,
                 "lengthFt": r.length_ft,
                 "lengthsText": (payload.get("zoi") or [{}] * (i + 1))[i].get("lengthsText"),
                 "weightLb": round(r.weight_per_ft.value * r.length_ft, 1)}
                for i, r in enumerate(zoi.runs)],
        "concentratedLb": zoi.concentrated_lb,
        "constraints": [cdict(c) for c in constraints],
        "overall": overall, "governing": governing,
        "governingDetail": governing_dict(),
        "componentRows": component_rows,
        "memberDetail": member_detail,
        "fastenerDetail": fastener_detail,
        "angleDeg": angle,
        "conditions": [dict(item, acked=bool(item.get("verdict"))
                            or bool((payload.get("conditionAck") or {}).get(item["section"])))
                       for item in _conditions_checklist(
                           edition, brace_type, payload,
                           member_resolved=member_check.status in ("PASS", "FAIL"))],
        "engineVersion": ENGINE_VERSION,
    }


# --- optimizer ----------------------------------------------------------------

def seismic_optimize(payload):
    from seismic_bracing import optimizer as opt
    edition = payload.get("edition", "2025")
    cp, cp_basis = _resolve_cp(edition, payload.get("seismic", {}))
    pipes = [opt.StretchPipe(p.get("label") or "pipe",
                             Qty(float(p["weightPerFt"]), "lb/ft", IMPERIAL),
                             float(p["totalLengthFt"]), bool(p.get("isMain")))
             for p in payload.get("stretch", [])]
    inv = opt.StretchInventory(pipes=pipes,
                               concentrated_lb=float(payload.get("concentratedLb") or 0))
    brace = payload["brace"]
    angle = float(brace["angleDeg"])
    bp = payload.get("bracedPipe") or {}
    f = payload.get("fastener") or {}
    comps_template = payload.get("components", [])
    brace_type = payload.get("braceType", "lateral")

    def constraint_max_spacing(s, fpw):
        if brace_type == "longitudinal":
            return lateral_bracing.check_max_longitudinal_spacing(s, edition=edition)
        return lateral_bracing.check_max_spacing(s, edition=edition)

    def constraint_zoi(s, fpw):
        return lateral_bracing.check_braced_pipe_stress(fpw, bp["tableId"], bp["size"], s,
                                                        edition=edition)

    def constraint_member(s, fpw):
        return member_capacity.check_member(fpw, brace["memberCategory"], brace["memberSize"],
                                            float(brace["lengthIn"]), angle, edition=edition)

    def constraint_assembly(s, fpw):
        comps, _rows = _component_capacities({"components": comps_template}, angle, edition)
        return assembly.assembly_check(fpw, comps)

    def constraint_fastener(s, fpw):
        return fastener_capacity.check_fastener(fpw, f["tableId"], f["size"], angle,
                                                f.get("orientation", "horizontal"), edition=edition,
                                                pr_band=int(f.get("prBand") or 0))

    sm = payload.get("structureMember") or {}
    rb = redbuilt_capacity(sm["detailId"], angle) if (
        sm.get("system") == "redbuilt" and sm.get("detailId")) else None

    def constraint_redbuilt(s, fpw):
        cap = Qty(float(rb["loadLb"]), "lb", IMPERIAL)
        ok = fpw.value <= cap.value
        return assembly.ConstraintResult(
            f"RedBuilt {rb['detail']['id']} structure member",
            assembly.PASS if ok else assembly.FAIL,
            ("RedBuilt Sprinkler System Installation Guide",),
            fpw, cap, governing=rb["detail"]["id"])

    # mode "pipe": only the checks that are knowable from Step 3 - the code
    # spacing ceiling and the braced-pipe zone-of-influence table. Everything
    # else depends on hardware the user has not chosen yet, and running those
    # against whatever happens to be sitting in the form is how the optimizer
    # used to answer 40 ft for a stretch whose real anchor allows 9.
    mode = "pipe" if str(payload.get("mode") or "full").lower() == "pipe" else "full"
    applied, skipped = [], []

    fns = [constraint_max_spacing]
    applied.append("code max spacing")

    zoi_available = bool(bp.get("tableId")) and brace_type != "longitudinal"
    if zoi_available:
        # Table 18.5.5.2 is a LATERAL sway-brace-spacing stress table
        fns.append(constraint_zoi)
        applied.append("braced pipe stress")
    elif brace_type == "longitudinal":
        skipped.append("braced pipe stress (Table 18.5.5.2 is lateral only)")

    hardware = [
        (constraint_member, "brace member capacity", True),
        (constraint_assembly, "brace assembly capacity", bool(comps_template)),
        (constraint_fastener, "fastener capacity", bool(f.get("tableId"))),
        (constraint_redbuilt, "structure member", bool(rb and rb.get("loadLb"))),
    ]
    for fn, name, present in hardware:
        if mode == "pipe":
            skipped.append(name)
        elif present:
            fns.append(fn)
            applied.append(name)
        else:
            skipped.append(name)

    # A longitudinal brace in pipe mode has nothing but the 80 ft code ceiling
    # left, which is not a real answer - say so instead of printing it.
    pipe_limited = mode != "pipe" or zoi_available

    # 1 ft resolution up to the edition's spacing ceiling (40 ft lateral,
    # 80 ft longitudinal): the calc squeezes out every last foot so a field
    # brace an extra foot out still has margin on paper
    ceiling = 81 if brace_type == "longitudinal" else 41
    candidates = payload.get("candidates") or list(range(5, ceiling))
    res = opt.optimize_lateral_spacing(inv, cp, fns, candidates)
    evaluations = [{"spacingFt": s,
                    "fpwLb": round(next((r.demand.value for r in results if r.demand), 0), 1),
                    "results": [{"name": r.name, "status": r.status,
                                 "capacity": (round(r.capacity.value, 1) if r.capacity else None)}
                                for r in results]}
                   for s, results in res.evaluations]
    # The weakest link AT the winning spacing - "what is capping me right now",
    # which is a different question from res.governing ("what blocked the next
    # foot"). Same least-margin rule the calc uses.
    weakest = None
    if res.spacing_ft:
        chosen = next((r for s, r in res.evaluations if s == res.spacing_ft), [])
        rated = [c for c in chosen if c.capacity is not None and c.demand is not None]
        if rated:
            c = min(rated, key=lambda x: x.capacity.value - x.demand.value)
            weakest = {
                "name": c.name,
                "element": c.governing or c.name,
                "capacityLb": round(c.capacity.value, 1),
                "capacityUnit": c.capacity.unit,
                "demandLb": round(c.demand.value, 1),
                "marginLb": round(c.capacity.value - c.demand.value, 1),
            }

    return {"edition": edition, "cp": round(cp, 4), "cpBasis": cp_basis,
            "spacingFt": res.spacing_ft, "braceCount": res.brace_count,
            "codeComplete": res.code_complete, "pending": list(res.pending),
            "governing": res.governing, "evaluations": evaluations,
            "mainLengthFt": inv.main_length_ft(),
            "mode": mode, "applied": applied, "skipped": skipped,
            "pipeLimited": pipe_limited, "weakest": weakest}


def seismic_suggest(payload):
    """Verified fix suggestions for a failing brace: try bounded, sensible
    variations of the CURRENT inputs (hardware upsizes, component swaps,
    steeper angle, shorter member, tighter spacing) and return only the ones
    that actually flip the whole calc to PASS. Every suggestion carries a
    machine-applyable patch."""
    base = seismic_calc(payload)
    if base["overall"] == "PASS":
        return {"overall": "PASS", "suggestions": []}
    failing = {c["name"] for c in base["constraints"] if c["status"] == "FAIL"}
    meta = seismic_meta()
    sugs = []
    budget = [26]          # hard cap on trial calcs

    def clone():
        return json.loads(json.dumps(payload))

    def trial(mutate, label, patch, kind):
        if budget[0] <= 0 or len(sugs) >= 6:
            return False
        budget[0] -= 1
        p2 = clone()
        mutate(p2)
        try:
            r2 = seismic_calc(p2)
        except Exception:
            return False
        if r2["overall"] != "PASS":
            return False
        margins = [c["capacity"] - c["demandLb"] for c in r2["constraints"]
                   if c.get("capacity") is not None and c.get("demandLb") is not None]
        sugs.append({"label": label, "patch": patch, "kind": kind,
                     "minMarginLb": round(min(margins), 1) if margins else None})
        return True

    brace = payload.get("brace") or {}
    f = payload.get("fastener") or {}
    angle = float(brace.get("angleDeg") or 45)

    # 1) hardware upsizes keep the layout untouched - try those first
    if "fastener capacity" in failing and f.get("tableId"):
        tbl = next((t for t in meta["fastenerTables"] if t["id"] == f["tableId"]), None)
        sizes = (tbl or {}).get("sizes") or []
        cur = sizes.index(f["size"]) if f.get("size") in sizes else -1
        for s in sizes[cur + 1:cur + 4]:
            if trial(lambda p, s=s: p["fastener"].__setitem__("size", s),
                     f"Upsize the fastener to {seismicish_pretty(s)} in.",
                     {"fastener": {"size": s}}, "fastener"):
                break
        # single changes dead-ended: a steeper band PLUS a bigger anchor is the
        # classic way out of a low-capacity category-A cell
        if not any(x["kind"] == "fastener" for x in sugs):
            done = False
            for a in (45, 60):
                if angle >= a or done:
                    continue
                for s in sizes[max(cur, 0):cur + 4]:
                    def mut(p, s=s, a=a):
                        p["fastener"]["size"] = s
                        p["brace"]["angleDeg"] = a
                    if trial(mut,
                             f"Steepen to {a}° AND use a {seismicish_pretty(s)} in. fastener",
                             {"fastener": {"size": s}, "brace": {"angleDeg": a}}, "combo"):
                        done = True
                        break

    if "brace member capacity" in failing or any("member" in n for n in failing):
        cat_sizes = [m["size"] for m in meta["members"] if m["category"] == brace.get("memberCategory")]
        cur = cat_sizes.index(brace.get("memberSize")) if brace.get("memberSize") in cat_sizes else -1
        for s in cat_sizes[cur + 1:cur + 4]:
            if trial(lambda p, s=s: p["brace"].__setitem__("memberSize", s),
                     f"Upsize the brace member to {seismicish_pretty(s)} in. {str(brace.get('memberCategory', '')).replace('Pipe Schedule', 'Sch.')}",
                     {"brace": {"memberSize": s}}, "member"):
                break
        # a shorter member fixes l/r failures without touching hardware
        li = float(brace.get("lengthIn") or 0)
        if li > 30:
            short = round(li * 0.75 / 6) * 6
            ftin = f"{int(short // 12)}'-{int(short % 12)}\""
            trial(lambda p: p["brace"].__setitem__("lengthIn", short),
                  f"Shorten the brace member to {ftin} (better l/r)",
                  {"brace": {"lengthIn": short}}, "member")

    # 2) component swaps/upsizes for the weakest link in the assembly
    if "component assembly" in failing or any("assembly" in n for n in failing):
        rows = base.get("componentRows") or []
        weakest = min((r for r in rows if r.get("appliedLb") is not None),
                      key=lambda r: r["appliedLb"], default=None)
        comps_in = payload.get("components") or []
        if weakest and comps_in:
            idx = next((i for i, r in enumerate(rows) if r is weakest), 0)
            slot = comps_in[idx] if idx < len(comps_in) else comps_in[0]
            role = slot.get("role", "structure_attachment")
            mfr = slot.get("manufacturer")
            wanted = {"structure_attachment": ("structure_attachment", "adapter", "brace_fitting"),
                      "pipe_attachment": ("pipe_attachment",)}.get(role, (role,))
            cands = [c for c in (meta["components"].get(mfr) or []) if c["role"] in wanted]
            fig_now = next((c for c in cands if c["figure"] == slot.get("figure")), None)
            # bigger size in the same figure first
            if fig_now and slot.get("size") in fig_now["sizes"]:
                ci = fig_now["sizes"].index(slot["size"])
                for s in fig_now["sizes"][ci + 1:ci + 3]:
                    if trial(lambda p, s=s: p["components"][idx].__setitem__("size", s),
                             f"Upsize {slot.get('figure')} to {s}",
                             {"componentSwap": {"index": idx, "role": role, "manufacturer": mfr,
                                                "figure": slot.get("figure"), "size": s}}, "component"):
                        break
            # then a stronger figure in the same slot
            bp_pretty = seismicish_pretty((payload.get("bracedPipe") or {}).get("size") or "")
            for c in cands:
                if len(sugs) >= 6 or c["figure"] == slot.get("figure"):
                    continue
                size = next((s for s in c["sizes"]
                             if role == "pipe_attachment" and bp_pretty
                             and re.search(rf"(^|[^\d/]){re.escape(bp_pretty)}\s*(in\b|in\.)", str(s))),
                            None) or (next((s for s in c["sizes"] if "1/2" in seismicish_pretty(str(s))), None)
                                      if role != "pipe_attachment" else None) or (c["sizes"][0] if c["sizes"] else None)
                if not size:
                    continue
                def swap(p, fig=c["figure"], size=size):
                    p["components"][idx].update({"figure": fig, "size": size})
                if trial(swap, f"Swap {slot.get('figure')} for {c['figure']} ({size})",
                         {"componentSwap": {"index": idx, "role": role, "manufacturer": mfr,
                                            "figure": c["figure"], "size": size}}, "component"):
                    break

    # 3) a steeper brace improves every rating band (Table 18.5.2.3, Figure
    #    18.5.12.1 categories) - suggest the next band boundary
    for target in (45, 60):
        if angle < target:
            trial(lambda p, a=target: p["brace"].__setitem__("angleDeg", a),
                  f"Steepen the brace to {target}° from vertical (better rating band)",
                  {"brace": {"angleDeg": target}}, "angle")
            break

    # 4) tighter spacing always sheds demand - find the max passing spacing
    #    with the ZOI scaled proportionally (same math as Auto-Fit)
    S0 = float(payload.get("spacingFt") or 0)
    if S0 > 5:
        lo, best = 5, None
        s = int(S0) - 1
        while s >= lo and budget[0] > 0:
            budget[0] -= 1
            p2 = clone()
            p2["spacingFt"] = s
            for z in p2.get("zoi") or []:
                z["lengthFt"] = z["lengthFt"] * s / S0
                z.pop("lengthsText", None)
            p2["concentratedLb"] = float(p2.get("concentratedLb") or 0) * s / S0
            try:
                if seismic_calc(p2)["overall"] == "PASS":
                    best = s
                    break
            except Exception:
                pass
            s -= 1 if S0 - s < 6 else 2
        if best:
            sugs.append({"label": f"Tighten spacing to {best} ft (ZOI scales with it)",
                         "patch": {"spacingFt": best, "scaleZoi": round(best / S0, 4)},
                         "kind": "spacing", "minMarginLb": None})

    return {"overall": base["overall"],
            "failing": sorted(failing),
            "suggestions": sugs[:6]}


# --- exports ------------------------------------------------------------------

def _wrap(c, text, x, y, width, size=7.2, leading=9, font="Helvetica", max_lines=3):
    from reportlab.pdfbase.pdfmetrics import stringWidth
    words = str(text).split()
    line, lines = "", []
    for w in words:
        t = (line + " " + w).strip()
        if stringWidth(t, font, size) <= width:
            line = t
        else:
            lines.append(line)
            line = w
            if len(lines) >= max_lines:
                break
    if line and len(lines) < max_lines:
        lines.append(line)
    c.setFont(font, size)
    for ln in lines:
        c.drawString(x, y, ln)
        y -= leading
    return y


def _draw_brace_schematic(c, x, y, w, h, angle_deg, member_desc, attach_desc, clamp_desc):
    """Simple line diagram of the brace assembly at the TRUE entered angle
    (from vertical) - the TOLBrace-style detail box."""
    import math
    c.saveState()
    c.setLineWidth(0.8)
    c.setStrokeColorRGB(0.25, 0.25, 0.25)
    # structure (ceiling) line at top of box
    top_y = y + h - 14
    c.setLineWidth(2)
    c.line(x + 8, top_y, x + w - 8, top_y)
    c.setLineWidth(0.8)
    for hx in range(int(x + 12), int(x + w - 8), 14):   # hatch above structure
        c.line(hx, top_y, hx + 7, top_y + 6)
    # geometry: brace from pipe (bottom) to structure at angle from vertical
    run = (h - 44) * math.tan(math.radians(min(max(angle_deg, 15), 75)))
    run = min(run, w - 70)
    px = x + 26                       # pipe center
    py = y + 26
    ax = px + run                     # attachment point on structure
    ay = top_y
    # pipe (braced) circle
    c.setLineWidth(1.2)
    c.circle(px, py, 11)
    c.circle(px, py, 7)
    # brace member
    c.setLineWidth(2.2)
    c.line(px + 4, py + 8, ax - 3, ay - 3)
    # fastener block at structure
    c.setLineWidth(1)
    c.rect(ax - 6, ay - 7, 12, 7, stroke=1, fill=0)
    # vertical reference + angle arc at the attachment
    c.setDash(2, 2)
    c.setLineWidth(0.6)
    c.line(ax, ay, ax, ay - 34)
    c.setDash()
    import math as _m
    c.arc(ax - 22, ay - 22 - 12, ax + 22, ay + 22 - 12, 270 - 0, 270)
    c.setFont("Helvetica", 6.5)
    c.drawString(ax + 4, ay - 30, f"{angle_deg:g}°")
    # labels
    c.setFont("Helvetica", 6.5)
    c.drawString(px - 14, py - 22, clamp_desc[:26])
    mid_x, mid_y = (px + ax) / 2, (py + ay) / 2
    c.drawString(mid_x - 10, mid_y - 12, "BRACE: " + member_desc[:22])
    c.drawRightString(x + w - 8, ay - 16, attach_desc[:30])
    c.restoreState()


def seismic_report_pdf(payload, result):
    """Single-page calc sheet in the familiar TOLBrace layout: project blocks,
    Brace Information + Components (Listed/Adjusted) boxes, Fastener
    Information + assembly detail diagram, brace identification, and the
    Sprinkler System Load Calculation (Fpw = CpWp) table."""
    from reportlab.lib.pagesizes import letter
    from reportlab.pdfgen import canvas as rl_canvas
    buf = io.BytesIO()
    c = rl_canvas.Canvas(buf, pagesize=letter)
    W, H = letter
    M = 40
    project = payload.get("project") or {}
    md = result.get("memberDetail") or {}
    fd = result.get("fastenerDetail") or {}

    def box(x, y, w, h, title=None):
        c.setLineWidth(0.9)
        c.setStrokeColorRGB(0.15, 0.15, 0.15)
        c.rect(x, y, w, h, stroke=1, fill=0)
        if title:
            c.setFillColorRGB(0, 0, 0)
            c.setFont("Helvetica-Bold", 9.5)
            c.drawCentredString(x + w / 2, y + h - 13, title)
            c.setLineWidth(0.5)
            c.line(x, y + h - 18, x + w, y + h - 18)

    def kv(x, y, label, value, lw=118, size=8):
        c.setFont("Helvetica", size)
        c.drawString(x, y, label)
        c.setFont("Helvetica-Bold", size)
        c.drawString(x + lw, y, str(value))
        c.setLineWidth(0.3)
        c.setStrokeColorRGB(0.6, 0.6, 0.6)
        c.line(x + lw, y - 2, x + lw + 108, y - 2)
        c.setStrokeColorRGB(0.15, 0.15, 0.15)

    # ---- header ----
    c.setFillColorRGB(0, 0, 0)
    c.setFont("Helvetica-Bold", 15)
    c.drawString(M, H - 46, "Seismic Bracing Calculations")
    c.setFont("Helvetica", 8)
    c.drawString(M, H - 58, f"Calculations based on {result['editionLabel']}")
    c.setFont("Helvetica-Bold", 11)
    c.drawRightString(W - M, H - 44, "SprinkFlow")
    c.setFont("Helvetica", 7)
    c.drawRightString(W - M, H - 54, "sprinkflow.studio")
    c.drawRightString(W - M, H - 63, datetime.now().strftime("%Y-%m-%d"))
    c.setLineWidth(1.2)
    c.line(M, H - 68, W - M, H - 68)

    # ---- project / designer blocks ----
    y0 = H - 80
    c.setFont("Helvetica", 8)
    c.drawString(M, y0, "Project Address:")
    c.setFont("Helvetica-Bold", 9)
    c.drawString(M + 78, y0, (project.get("jobName") or "-")[:46])
    c.setFont("Helvetica", 8)
    if project.get("address"):
        c.drawString(M + 78, y0 - 11, project["address"][:52])
    firm = ""
    if project.get("firmName"):
        role = "Engineer" if project.get("firmRole") == "engineer" else "Contractor"
        lic = f", Lic. {project['firmLicense']}" if project.get("firmLicense") else ""
        firm = f"   {role}: {project['firmName']}{lic}"
    c.drawString(M + 78, y0 - 22, (f"Job # {project.get('jobNumber') or '-'}" + firm)[:64])
    c.drawString(W / 2 + 30, y0, "Designer:")
    c.setFont("Helvetica-Bold", 8)
    c.drawString(W / 2 + 78, y0, (project.get("designer") or "-")[:34])
    c.setFont("Helvetica", 8)
    c.drawString(W / 2 + 30, y0 - 11, "Brace ID:")
    c.setFont("Helvetica-Bold", 8)
    c.drawString(W / 2 + 78, y0 - 11, (project.get("braceId") or "-")[:24])
    bt = result.get("braceType", "lateral")
    c.setFont("Helvetica", 8)
    c.drawString(W / 2 + 30, y0 - 22,
                 f"Brace Type:  Lateral [{'X' if bt == 'lateral' else ' '}]   "
                 f"Longitudinal [{'X' if bt == 'longitudinal' else ' '}]   4-Way [ ]")

    # ---- row 1: Brace Information | Brace Components ----
    row1_top = y0 - 34
    box_h1 = 128
    col_w = (W - 2 * M - 12) / 2
    bx, by = M, row1_top - box_h1
    box(bx, by, col_w, box_h1, "Brace Information")
    member_disp = f"{seismicish_pretty(md.get('size', ''))}\" {str(md.get('category', '')).replace('Pipe Schedule', 'Sch.')}"
    yy = by + box_h1 - 32
    kv(bx + 8, yy, "Maximum Brace Length", md.get("lengthFtIn") or "-"); yy -= 13
    kv(bx + 8, yy, "Brace Member", member_disp[:26]); yy -= 13
    kv(bx + 8, yy, "Angle of Brace", f"{result.get('angleDeg'):g}° from vertical"); yy -= 13
    kv(bx + 8, yy, "Least Rad. of Gyration", f"{md.get('r')}\"" if md.get("r") else "-"); yy -= 13
    kv(bx + 8, yy, "L/R Value", md.get("lr") or "-"); yy -= 13
    kv(bx + 8, yy, "Max Horizontal Load",
       f"{md.get('maxLoadLb'):g} lb" if md.get("maxLoadLb") else "-"); yy -= 13
    kv(bx + 8, yy, "Net Vertical Reaction", f"{result['verticalReactionLb']:g} lb")

    cx = M + col_w + 12
    box(cx, by, col_w, box_h1, "Brace Components")
    c.setFont("Helvetica-Bold", 7.2)
    c.drawString(cx + 8, by + box_h1 - 30, "COMPONENT")
    c.drawRightString(cx + col_w - 78, by + box_h1 - 30, "LISTED LOAD")
    c.drawRightString(cx + col_w - 8, by + box_h1 - 30, "ADJUSTED LOAD")
    yy = by + box_h1 - 42
    for row in (result.get("componentRows") or [])[:5]:
        c.setFont("Helvetica", 7.6)
        c.drawString(cx + 8, yy, row["component"][:34])
        c.drawRightString(cx + col_w - 78, yy,
                          f"{row['listedLb']:g} lb" if row.get("listedLb") is not None else "-")
        c.setFont("Helvetica-Bold", 7.6)
        c.drawRightString(cx + col_w - 8, yy,
                          f"{row['appliedLb']:g} lb" if row.get("appliedLb") is not None else "-")
        c.setFont("Helvetica", 6.2)
        c.setFillColorRGB(0.35, 0.35, 0.35)
        c.drawString(cx + 8, yy - 7, row.get("basis", "")[:64])
        c.setFillColorRGB(0, 0, 0)
        yy -= 17
    c.setFont("Helvetica", 6.2)
    c.setFillColorRGB(0.35, 0.35, 0.35)
    c.drawString(cx + 8, by + 6, "Unqualified listed ratings adjusted per Table 18.5.2.3 at the installed brace angle.")
    c.setFillColorRGB(0, 0, 0)

    # ---- row 2: Fastener Information | Assembly Detail ----
    box_h2 = 122
    by2 = by - 10 - box_h2
    box(M, by2, col_w, box_h2, "Fastener Information")
    yy = by2 + box_h2 - 32
    kv(M + 8, yy, "Fastener", (fd.get("tableTitle") or "-")[:30], lw=88); yy -= 13
    kv(M + 8, yy, "Size", seismicish_pretty(fd.get("size")) if fd.get("size") else "-", lw=88); yy -= 13
    kv(M + 8, yy, "Orientation", (fd.get("orientation") or "-"), lw=88); yy -= 13
    kv(M + 8, yy, "Angle Category (Fig. 18.5.12.1)", fd.get("category") or "-", lw=138); yy -= 13
    kv(M + 8, yy, "Maximum Load",
       f"{fd.get('maxLoadLb'):g} lb" if fd.get("maxLoadLb") else "-", lw=88); yy -= 13
    install = fd.get("install") or {}
    if install.get("embedmentIn") is not None:
        kv(M + 8, yy, "Min. Nom. Embedment",
           f"{install['embedmentIn']:g} in." + (f"  (slab {install['slabThicknessIn']:g} in. min.)"
                                                if install.get("slabThicknessIn") else ""),
           lw=100); yy -= 13
    if install.get("edgeDistanceIn") is not None or install.get("fluteOffsetIn") is not None:
        extra = []
        if install.get("edgeDistanceIn") is not None:
            extra.append(f"edge dist. {install['edgeDistanceIn']:g} in. min.")
        if install.get("fluteOffsetIn") is not None:
            extra.append(f"flute offset {install['fluteOffsetIn']:g} in. max.")
        kv(M + 8, yy, "Installation", "; ".join(extra)[:34], lw=88)
    box(cx, by2, col_w, box_h2, "Seismic Brace Assembly Detail")
    comp_rows = result.get("componentRows") or []

    def short_fig(row_text):
        # 'TOLCO Fig. 980 980-5/8 (11/16 in. mounting hole)' -> 'TOLCO Fig. 980'
        import re as _re
        m = _re.match(r"^(\S+\s+(?:Fig\.?|AF|CSB)\s*\S+)", str(row_text))
        return (m.group(1) if m else str(row_text))[:18]

    _draw_brace_schematic(c, cx + 4, by2 + 4, col_w - 8, box_h2 - 24,
                          result.get("angleDeg") or 45,
                          member_disp,
                          short_fig(comp_rows[0]["component"]) if comp_rows else "",
                          short_fig(comp_rows[1]["component"]) if len(comp_rows) > 1 else "pipe attachment")

    # ---- load calculation table (Fpw = CpWp) ----
    lt_top = by2 - 14
    c.setFont("Helvetica-Bold", 9.5)
    c.drawString(M, lt_top, "Sprinkler System Load Calculation (Fpw = CpWp)")
    c.setFont("Helvetica", 8)
    c.drawRightString(W - M, lt_top, f"Cp = {result['cp']}   ({result['cpBasis'][:44]})")
    small = "  .  ".join(x for x in (result.get("cpLookup"), result.get("cpHeight")) if x)
    yy = lt_top - 14
    if small:
        c.setFont("Helvetica", 6.4)
        c.setFillColorRGB(0.35, 0.35, 0.35)
        c.drawRightString(W - M, lt_top - 8, small[:150])
        c.setFillColorRGB(0, 0, 0)
        yy = lt_top - 17
    cols = {"pipe": M, "len": M + 200, "wpf": M + 280, "wt": W - M - 8}
    c.setFont("Helvetica-Bold", 7.2)
    c.drawString(cols["pipe"], yy, "PIPE")
    c.drawString(cols["len"], yy, "LENGTH (ft)")
    c.drawString(cols["wpf"], yy, "WEIGHT PER FT (lb/ft)")
    c.drawRightString(cols["wt"], yy, "TOTAL WEIGHT (lb)")
    yy -= 3
    c.setLineWidth(0.5)
    c.line(M, yy, W - M, yy)
    yy -= 10
    c.setFont("Helvetica", 8)
    for r in result["zoi"][:7]:
        c.drawString(cols["pipe"], yy, r["label"][:38])
        c.drawString(cols["len"], yy, f"{r['lengthFt']:g}")
        c.drawString(cols["wpf"], yy, f"{r['weightPerFt']:g}")
        c.drawRightString(cols["wt"], yy, f"{r['weightLb']:g}")
        yy -= 11
    if result.get("concentratedLb"):
        c.drawString(cols["pipe"], yy, "Concentrated loads")
        c.drawRightString(cols["wt"], yy, f"{result['concentratedLb']:g}")
        yy -= 11
    c.setLineWidth(0.5)
    c.line(M + 250, yy + 4, W - M, yy + 4)
    yy -= 4
    rows = [("Subtotal Weight", f"{result['subtotalLb']:g} lb"),
            (f"Wp (incl. {result.get('allowanceFactor') or 1.15:g} allowance)", f"{result['wpLb']:g} lb"),
            (f"Total (Fpw = {result['cp']:g} × Wp)", f"{result['fpwLb']:g} lb")]
    if result.get("maxFpwLb"):
        rows.append((f"Maximum Fpw per Table {result['bracedPipe']['tableId']} "
                     f"({seismicish_pretty(result['bracedPipe']['size'])}\" @ {result['spacingFt']:g} ft spacing)",
                     f"{result['maxFpwLb']:g} lb"))
    for label, val in rows:
        c.setFont("Helvetica", 8)
        c.drawRightString(W - M - 110, yy, label)
        c.setFont("Helvetica-Bold", 8)
        c.drawRightString(cols["wt"], yy, val)
        yy -= 12

    # ---- checks summary + verdict ----
    yy -= 4
    c.setFont("Helvetica-Bold", 8)
    c.drawString(M, yy, "Conclusions")
    yy -= 11
    for cn in result["constraints"]:
        c.setFont("Helvetica", 7.6)
        cap = f"{cn['capacity']:g} {cn.get('capacityUnit') or 'lb'}" if cn["capacity"] is not None else "-"
        c.drawString(M + 6, yy, f"{cn['name']}: {cap}")
        if cn["status"] == "PASS":
            c.setFillColorRGB(0.07, 0.5, 0.18)
        elif cn["status"] == "FAIL":
            c.setFillColorRGB(0.8, 0.1, 0.1)
        else:
            c.setFillColorRGB(0.75, 0.5, 0.05)
        c.setFont("Helvetica-Bold", 7.6)
        c.drawString(M + 290, yy, cn["status"])
        c.setFillColorRGB(0, 0, 0)
        yy -= 10
        if yy < 108:
            break

    conds = result.get("conditions") or []
    if conds:
        acked = [x["section"] for x in conds if x.get("acked")]
        c.setFont("Helvetica", 7)
        c.setFillColorRGB(0.25, 0.25, 0.25)
        c.drawString(M, yy, (f"Code conditions verified by designer: {', '.join(acked)}" if acked
                             else f"Code conditions to verify: {', '.join(x['section'] for x in conds[:8])}"))
        c.setFillColorRGB(0, 0, 0)
        yy -= 12

    # verdict banner directly under the conclusions (no stranded void), but
    # never below the footer zone
    banner_y = max(66, yy - 22)
    if result["overall"] == "PASS":
        c.setFillColorRGB(0.07, 0.5, 0.18)
    elif result["overall"] == "FAIL":
        c.setFillColorRGB(0.8, 0.1, 0.1)
    else:
        c.setFillColorRGB(0.75, 0.5, 0.05)
    c.rect(M, banner_y, W - 2 * M, 24, stroke=0, fill=1)
    c.setFillColorRGB(1, 1, 1)
    c.setFont("Helvetica-Bold", 11)
    verdict = {"PASS": "BRACE ASSEMBLY - ACCEPTABLE", "FAIL": "BRACE ASSEMBLY - NOT ACCEPTABLE",
               "UNAVAILABLE": "INCOMPLETE - DATA PENDING"}[result["overall"]]
    c.drawCentredString(W / 2, banner_y + 7, verdict)
    c.setFillColorRGB(0.35, 0.35, 0.35)
    c.setFont("Helvetica", 6.6)
    c.drawString(M, 52, f"Calculations per {result['editionLabel']}. Component ratings from current manufacturer-published data with page-level provenance on file.")
    c.drawString(M, 43, "Generated by SprinkFlow (sprinkflow.studio). The designer of record is responsible for verifying applicability and field conditions.")
    c.showPage()
    c.save()
    return buf.getvalue()


def seismicish_pretty(raw):
    """Fraction typography for the calc sheet ('11⁄4' -> 1-1/4)."""
    import re as _re
    s = str(raw or "").replace("*", "").strip()
    s = _re.sub(r"^(\d+)(\d⁄\d+)", r"\1-\2", s)
    return s.replace("⁄", "/")


def seismic_report_pdf_nfpa(payload, result):
    """The NFPA 13 sample 'Seismic Bracing Calculations' worksheet, reproduced
    from the annex form the owner supplied: header blocks, Brace Information /
    Seismic Brace Attachments (Make/Model + Listed/Adjusted per 18.5.2.3),
    Fastener Information, assembly-detail box, brace identification +
    checkboxes, and the full-width Fpw = CpWp load table."""
    import math
    from reportlab.lib.pagesizes import letter
    from reportlab.pdfgen import canvas as rl_canvas
    buf = io.BytesIO()
    c = rl_canvas.Canvas(buf, pagesize=letter)
    W, H = letter
    M = 30
    project = payload.get("project") or {}
    md = result.get("memberDetail") or {}
    fd = result.get("fastenerDetail") or {}
    comp_rows = result.get("componentRows") or []
    roles = {}
    for c_in, row in zip(payload.get("components", []), comp_rows):
        roles.setdefault(c_in.get("role", "component"), row)

    def hline(x1, y, x2, weight=0.5):
        c.setLineWidth(weight)
        c.line(x1, y, x2, y)

    def blank(x, y, w, value="", size=8.5, bold=True):
        c.setFont("Helvetica-Bold" if bold else "Helvetica", size)
        if value not in (None, ""):
            c.drawCentredString(x + w / 2, y + 2, str(value)[:int(w / 4)])
        hline(x, y, x + w, 0.6)

    def angle_band(angle):
        if angle < 45:
            return "30° to 44°"
        if angle < 60:
            return "45° to 59°"
        return "60° to 90°"

    # ---- outer frame + title band ----
    c.setLineWidth(1.6)
    c.rect(M, 36, W - 2 * M, H - 72, stroke=1, fill=0)
    title_y = H - 66
    c.setFont("Helvetica-Bold", 17)
    c.drawCentredString(W / 2 - 40, title_y, "Seismic Bracing Calculations")
    c.setFont("Helvetica", 9)
    c.drawString(W - M - 150, title_y - 6, "Sheet")
    blank(W - M - 122, title_y - 8, 44)
    c.setFont("Helvetica", 9)
    c.drawString(W - M - 74, title_y - 6, "of")
    blank(W - M - 60, title_y - 8, 44)
    hline(M, H - 78, W - M, 1.6)

    # ---- header blocks ----
    hy = H - 94
    c.setFont("Helvetica", 9)
    c.drawString(M + 10, hy, "Project:")
    blank(M + 62, hy - 2, 200, project.get("jobName") or "")
    c.setFont("Helvetica", 9)
    c.drawString(M + 10, hy - 18, "Address:")
    blank(M + 62, hy - 20, 200, project.get("address") or "")
    blank(M + 62, hy - 38, 200, f"Job # {project['jobNumber']}" if project.get("jobNumber") else "")
    mid = W / 2 + 6
    c.setFont("Helvetica", 9)
    c.drawString(mid, hy, "Contractor:")
    firm_txt = project.get("contractor") or ""
    if not firm_txt and project.get("firmName"):
        firm_txt = project["firmName"] + (f" (Lic. {project['firmLicense']})" if project.get("firmLicense") else "")
    blank(mid + 62, hy - 2, W - M - mid - 72, firm_txt)
    c.setFont("Helvetica", 9)
    c.drawString(mid, hy - 18, "Designer:")
    blank(mid + 62, hy - 20, W - M - mid - 72, project.get("designer") or "")
    c.setFont("Helvetica", 9)
    c.drawString(mid, hy - 36, "Date:")
    blank(mid + 62, hy - 38, W - M - mid - 72, datetime.now().strftime("%Y-%m-%d"))
    hline(M, hy - 50, W - M, 1.6)

    # ---- two columns ----
    col_split = W / 2 - 10
    top = hy - 50

    def box_title(x1, y_top, x2, label, h=18):
        c.setLineWidth(1)
        c.rect(x1, y_top - h, x2 - x1, h, stroke=1, fill=0)
        c.setFont("Helvetica-Bold", 10.5)
        c.drawCentredString((x1 + x2) / 2, y_top - h + 5, label)
        return y_top - h

    # LEFT: Brace Information
    y = box_title(M, top, col_split, "Brace Information")
    y -= 16
    left_rows = [
        ("Length of brace:", md.get("lengthFtIn", "").replace("'", " ft").replace('"', " in.")),
        ("Diameter of brace:", f"{seismicish_pretty(md.get('size', ''))} in."),
        ("Type of brace:", str(md.get("category", "")).replace("Pipe ", "")),
        ("Angle of brace:", angle_band(result.get("angleDeg") or 45)),
        ("Least radius of gyration:*", md.get("r", "")),
        ("l/r value:*", md.get("lr", "")),
        ("Maximum horizontal load:", f"{md.get('maxLoadLb'):g} lb" if md.get("maxLoadLb") else ""),
    ]
    for label, val in left_rows:
        c.setFont("Helvetica", 9)
        c.drawString(M + 14, y, label)
        blank(M + 168, y - 2, col_split - M - 182, val)
        y -= 18
    fast_top = y - 4
    y = box_title(M, fast_top, col_split, "Fastener Information")
    y -= 16
    c.setFont("Helvetica", 9)
    c.drawString(M + 14, y, "Orientation of connecting surface:")
    blank(M + 176, y - 2, 60, f"“{fd.get('category')}”" if fd.get("category") else "")
    y -= 20
    c.setFont("Helvetica", 9)
    c.drawString(M + 14, y, "Fastener:")
    y -= 15
    for label, val in [("Type:", ((fd.get("tableTitle") or "")[:31] + ("…" if len(fd.get("tableTitle") or "") > 31 else "")),),
                       ("Diameter:", seismicish_pretty(fd.get("size")) if fd.get("size") else ""),
                       ("Orientation:", fd.get("orientation") or ""),
                       ("Maximum load:", f"{fd.get('maxLoadLb'):g} lb" if fd.get("maxLoadLb") else "")]:
        c.setFont("Helvetica", 9)
        c.drawString(M + 26, y, label)
        blank(M + 110, y - 2, col_split - M - 124, val)
        y -= 16
    left_bottom = y - 4

    # RIGHT: Seismic Brace Attachments
    y = box_title(col_split + 8, top, W - M, "Seismic Brace Attachments")
    y -= 14
    rx = col_split + 14

    def attachment(title_text, row):
        nonlocal y
        c.setFont("Helvetica", 8.6)
        c.drawString(rx, y, title_text)
        y -= 14
        make, model = "", ""
        listed = adjusted = None
        if row:
            parts = str(row["component"]).split()
            make = parts[0] if parts else ""
            model = " ".join(parts[1:3])
            listed, adjusted = row.get("listedLb"), row.get("appliedLb")
        c.setFont("Helvetica", 8.6)
        c.drawString(rx + 12, y, "Make:")
        blank(rx + 40, y - 2, 90, make)
        c.setFont("Helvetica", 8.6)
        c.drawString(rx + 140, y, "Model:")
        blank(rx + 172, y - 2, W - M - rx - 180, model)
        y -= 14
        c.setFont("Helvetica", 8.6)
        c.drawString(rx + 12, y, "Listed load rating:")
        blank(rx + 86, y - 2, 46, f"{listed:g}" if listed is not None else "- - -")
        c.setFont("Helvetica", 8.6)
        c.drawString(rx + 140, y, "Adjusted per 18.5.2.3:")
        blank(rx + 228, y - 2, W - M - 8 - (rx + 228), f"{adjusted:g}" if adjusted is not None else "- - -")
        y -= 16

    attachment("Structure attachment fitting or tension-only bracing system:",
               roles.get("structure_attachment"))
    attachment("Transition attachment fitting (where applicable):", roles.get("brace_fitting"))
    attachment("Sway brace (pipe attachment) fitting:", roles.get("pipe_attachment"))

    # RIGHT: assembly detail box
    det_top = y - 2
    det_bottom = left_bottom + 46
    c.setLineWidth(1)
    c.rect(col_split + 8, det_bottom, W - M - col_split - 8, det_top - det_bottom, stroke=1, fill=0)
    c.setFont("Helvetica-Bold", 10.5)
    c.drawCentredString((col_split + 8 + W - M) / 2, det_top - 13, "Seismic Brace Assembly Detail")
    c.setFont("Helvetica", 8)
    c.drawCentredString((col_split + 8 + W - M) / 2, det_top - 23, "(Provide detail on plans)")

    def short_fig(row):
        import re as _re
        if not row:
            return ""
        m = _re.match(r"^(\S+\s+(?:Fig\.?|AF|CSB)\s*\S+)", str(row["component"]))
        return (m.group(1) if m else str(row["component"]))[:18]

    _draw_brace_schematic(c, col_split + 12, det_bottom + 4, W - M - col_split - 20,
                          det_top - det_bottom - 32, result.get("angleDeg") or 45,
                          f"{seismicish_pretty(md.get('size', ''))}\" {str(md.get('category', '')).replace('Pipe Schedule', 'Sch.')}",
                          short_fig(roles.get("structure_attachment")),
                          short_fig(roles.get("pipe_attachment")))

    # brace identification + checkboxes
    idy = det_bottom - 4
    c.setLineWidth(1)
    c.rect(col_split + 8, idy - 26, 190, 26, stroke=1, fill=0)
    c.setFont("Helvetica", 7.6)
    c.drawString(col_split + 12, idy - 10, "Brace identification no.")
    c.drawString(col_split + 12, idy - 19, "(to be used on plans)")
    blank(col_split + 96, idy - 21, 96, project.get("braceId") or "")
    cby = idy - 26
    bt = result.get("braceType", "lateral")
    cbx = col_split + 8
    c.setLineWidth(1)
    c.rect(cbx, cby - 20, W - M - cbx, 20, stroke=1, fill=0)
    for label_text, key, off in (("Lateral brace", "lateral", 0),
                                 ("Longitudinal brace", "longitudinal", 100),
                                 ("4-way brace", "riser", 212)):
        x0 = cbx + 8 + off
        c.rect(x0, cby - 14, 8, 8, stroke=1, fill=0)
        if bt == key:
            c.setFont("Helvetica-Bold", 8)
            c.drawString(x0 + 1, cby - 13, "X")
        c.setFont("Helvetica", 8.4)
        c.drawString(x0 + 12, cby - 13, label_text)
    body_bottom = min(left_bottom, cby - 20)
    hline(M, body_bottom, W - M, 1.6)

    # ---- load calc table ----
    y = body_bottom - 14
    c.setFont("Helvetica-Bold", 11)
    c.drawCentredString(W / 2, y, "Sprinkler System Load Calculation (Fpw = CpWp)")
    y -= 13
    c.setFont("Helvetica-Bold", 9.5)
    c.drawCentredString(W / 2 - 30, y, "Cp =")
    blank(W / 2 - 8, y - 2, 60, f"{result['cp']:g}")
    y -= 12
    cols = [M, M + 52, M + 116, M + 300, M + 386, M + 470, W - M]
    headers = ["Diameter", "Type", "Length (ft)", "Total (ft)", "Weight per ft", "Weight"]
    row_h = 16
    c.setLineWidth(0.8)
    c.rect(M, y - row_h, W - 2 * M, row_h, stroke=1, fill=0)
    c.setFont("Helvetica-Bold", 8.6)
    for i, htxt in enumerate(headers):
        c.drawCentredString((cols[i] + cols[i + 1]) / 2, y - row_h + 5, htxt)
    y -= row_h

    import re as _re

    def split_label(label):
        mm = _re.search(r"([\d\-/.]+)\s*(?:in\.?|\")?\s*Sch(?:edule)?\.?\s*(\d+)", str(label), _re.I)
        if mm:
            return f"{mm.group(1)} in.", f"Sch. {mm.group(2)}"
        return "", str(label)[:16]

    zoi_rows = result["zoi"][:6]
    for r in zoi_rows + [None] * (6 - len(zoi_rows)):
        c.rect(M, y - row_h, W - 2 * M, row_h, stroke=1, fill=0)
        for xv in cols[1:-1]:
            c.line(xv, y - row_h, xv, y)
        if r:
            dia, typ = split_label(r["label"])
            c.setFont("Helvetica", 8.6)
            c.drawCentredString((cols[0] + cols[1]) / 2, y - row_h + 5, dia)
            c.drawCentredString((cols[1] + cols[2]) / 2, y - row_h + 5, typ)
            c.setFont("Helvetica", 7.6 if r.get("lengthsText") else 8.6)
            c.drawCentredString((cols[2] + cols[3]) / 2, y - row_h + 5,
                                (r.get("lengthsText") or f"{r['lengthFt']:g} ft")[:44])
            c.setFont("Helvetica", 8.6)
            c.drawCentredString((cols[3] + cols[4]) / 2, y - row_h + 5, f"{r['lengthFt']:g} ft")
            c.drawCentredString((cols[4] + cols[5]) / 2, y - row_h + 5, f"{r['weightPerFt']:g} lb/ft")
            c.drawCentredString((cols[5] + cols[6]) / 2, y - row_h + 5, f"{r['weightLb']:g} lb")
        y -= row_h
    # subtotal / Wp / Fpw ladder
    for label_text, val in [("Subtotal weight", f"{result['subtotalLb']:g} lb"),
                            (f"Wp (incl. {round(((result.get('allowanceFactor') or 1.15) - 1) * 100):g}%)", f"{result['wpLb']:g} lb"),
                            ("Total (Fpw)", f"{result['fpwLb']:g} lb")]:
        c.rect(cols[4], y - row_h, cols[6] - cols[4], row_h, stroke=1, fill=0)
        c.line(cols[5], y - row_h, cols[5], y)
        c.setFont("Helvetica-Bold" if "Fpw" in label_text else "Helvetica", 8.6)
        c.drawRightString(cols[5] - 4, y - row_h + 5, label_text)
        c.setFont("Helvetica-Bold", 8.6)
        c.drawCentredString((cols[5] + cols[6]) / 2, y - row_h + 5, val)
        y -= row_h
    # main size / spacing + max Fpw
    my = y + row_h * 3
    c.setFont("Helvetica-Bold", 8.6)
    c.drawString(M + 4, my - row_h * 2 + 4, "Main Size")
    c.drawString(M + 70, my - row_h * 2 + 4, "Type\\Sch.")
    c.drawString(M + 160, my - row_h * 2 + 4, "Spacing (ft)")
    bp = result.get("bracedPipe") or {}
    _bp_letter = (str(bp.get("tableId") or "")[-2:-1] or "")
    bp_table = {"a": "Sch. 10", "c": "Sch. 40", "e": "Sch. 5", "g": "CPVC",
                "i": "Type M Copper", "k": "Type M Copper (no support)",
                "m": "Red Brass"}.get(_bp_letter, "")
    c.setFont("Helvetica", 8.6)
    c.drawString(M + 4, my - row_h * 3 + 4, f"{seismicish_pretty(bp.get('size'))} in." if bp.get("size") else "")
    c.drawString(M + 70, my - row_h * 3 + 4, bp_table)
    c.drawString(M + 160, my - row_h * 3 + 4, f"{result.get('spacingFt'):g} ft" if result.get("spacingFt") else "")
    c.rect(cols[4], y - row_h, cols[6] - cols[4], row_h, stroke=1, fill=0)
    c.line(cols[5], y - row_h, cols[5], y)
    c.setFont("Helvetica", 8)
    c.drawRightString(cols[5] - 4, y - row_h + 5, "Maximum Fpw per 18.5.5.2 (if applicable)")
    c.setFont("Helvetica-Bold", 8.6)
    c.drawCentredString((cols[5] + cols[6]) / 2, y - row_h + 5,
                        f"{result['maxFpwLb']:g} lb" if result.get("maxFpwLb") else "")
    y -= row_h

    # verdict + footnote
    if result["overall"] == "PASS":
        c.setFillColorRGB(0.07, 0.5, 0.18)
    elif result["overall"] == "FAIL":
        c.setFillColorRGB(0.8, 0.1, 0.1)
    else:
        c.setFillColorRGB(0.75, 0.5, 0.05)
    c.setFont("Helvetica-Bold", 9.5)
    verdict = {"PASS": "BRACE ASSEMBLY - ACCEPTABLE", "FAIL": "BRACE ASSEMBLY - NOT ACCEPTABLE",
               "UNAVAILABLE": "INCOMPLETE - DATA PENDING"}[result["overall"]]
    c.drawString(M + 4, 44, verdict)
    c.setFillColorRGB(0, 0, 0)
    c.setFont("Helvetica", 7.4)
    c.drawString(M + 4, y - 12, "* Excludes tension-only bracing systems")
    c.setFont("Helvetica", 7)
    c.setFillColorRGB(0.35, 0.35, 0.35)
    c.drawRightString(W - M - 4, 44,
                      f"SprinkFlow · {result['editionLabel']} · form per the NFPA 13 sample worksheet")
    c.showPage()
    c.save()
    return buf.getvalue()


def seismic_sds_doc_pdf(payload):
    """One-page 'Seismic Design Parameters' source-documentation sheet.

    Presents the full ASCE 7 parameter set exactly as returned by the USGS
    Seismic Design Web Services, with the geocoded location, the design basis,
    and - the key part - the exact reproducible USGS query URL, so a plan
    reviewer can independently confirm every value came from the official
    source. The designer still owns / verifies the values."""
    from reportlab.lib.pagesizes import letter
    from reportlab.pdfgen import canvas as rl_canvas

    buf = io.BytesIO()
    c = rl_canvas.Canvas(buf, pagesize=letter)
    W, H = letter
    M = 48
    project = payload.get("project") or {}
    navy = (0.094, 0.19, 0.235)
    accent = (0.16, 0.41, 0.48)
    mut = (0.36, 0.42, 0.47)

    def txt(x, y, s, size=10, bold=False, color=(0, 0, 0)):
        c.setFillColorRGB(*color)
        c.setFont("Helvetica-Bold" if bold else "Helvetica", size)
        c.drawString(x, y, "" if s is None else str(s))

    def fmt(v):
        if v is None:
            return "-"
        if isinstance(v, (int, float)):
            return f"{v:g}"
        return str(v)

    # header band
    c.setFillColorRGB(*navy)
    c.rect(0, H - 96, W, 96, fill=1, stroke=0)
    c.setFillColorRGB(*accent)
    c.rect(0, H - 99, W, 3, fill=1, stroke=0)
    txt(M, H - 48, "SEISMIC DESIGN PARAMETERS", 21, True, (1, 1, 1))
    txt(M, H - 70, "Source documentation - USGS Seismic Design Web Services", 10.5, False, (0.80, 0.85, 0.90))
    txt(W - M, H - 70, "SprinkFlow", 10, True, (0.80, 0.85, 0.90))
    c.setFont("Helvetica-Bold", 10)
    c.drawRightString(W - M, H - 48, payload.get("retrievedAt", "")[:10])

    y = H - 128

    # project + location
    def section(title):
        nonlocal y
        c.setFillColorRGB(*accent)
        c.setFont("Helvetica-Bold", 11)
        c.drawString(M, y, title.upper())
        c.setLineWidth(0.6)
        c.setStrokeColorRGB(0.82, 0.85, 0.88)
        c.line(M, y - 5, W - M, y - 5)
        y -= 24

    def row(label, value, bold=False):
        nonlocal y
        txt(M, y, label, 9.5, False, mut)
        txt(M + 165, y, value, 10.5, bold, (0.1, 0.14, 0.2))
        y -= 20

    section("Project")
    row("Project name", project.get("jobName") or "-")
    if project.get("jobNumber"):
        row("Job number", project.get("jobNumber"))
    row("Project address", project.get("address") or payload.get("matchedAddress") or "-")
    y -= 6

    section("Location & basis")
    row("Geocoded address", payload.get("matchedAddress") or "-")
    row("Latitude, Longitude", f"{fmt(payload.get('latitude'))}, {fmt(payload.get('longitude'))}")
    row("Geocoder", payload.get("geocoder") or "-")
    row("Reference document", payload.get("referenceDocument") or payload.get("asce") or "-")
    row("Risk Category", payload.get("riskCategory") or "II")
    row("Site Class", payload.get("siteClass") or "-")
    y -= 6

    # parameter table (skip Fa/Fv/PGA when the edition doesn't return them)
    section("Design parameters (per " + str(payload.get("asce") or "ASCE 7") + ")")
    params = [
        ("Ss", "Mapped MCE_R spectral response, short period", payload.get("ss")),
        ("S1", "Mapped MCE_R spectral response, 1-second", payload.get("s1")),
        ("Fa", "Site coefficient (short period)", payload.get("fa")),
        ("Fv", "Site coefficient (1-second)", payload.get("fv")),
        ("SMS", "Site-modified MCE_R, short period", payload.get("sms")),
        ("SM1", "Site-modified MCE_R, 1-second", payload.get("sm1")),
        ("SDS", "Design spectral response, short period", payload.get("sds")),
        ("SD1", "Design spectral response, 1-second", payload.get("sd1")),
        ("SDC", "Seismic Design Category", payload.get("sdc")),
        ("TL", "Long-period transition period (s)", payload.get("tl")),
        ("PGA_M", "Site-modified peak ground acceleration", payload.get("pgam")),
    ]
    basis = (payload.get("basis") or "sds")
    highlight = {"sds": "SDS", "ss": "Ss", "cp": "SDS"}.get(basis, "SDS")
    c.setFont("Helvetica-Bold", 9)
    c.setFillColorRGB(*mut)
    c.drawString(M, y, "SYMBOL"); c.drawString(M + 70, y, "DESCRIPTION"); c.drawString(W - M - 60, y, "VALUE")
    y -= 4
    c.setStrokeColorRGB(0.82, 0.85, 0.88); c.line(M, y, W - M, y); y -= 18
    for sym, desc, val in params:
        if val is None:
            continue
        is_hl = sym == highlight
        if is_hl:
            c.setFillColorRGB(0.93, 0.96, 0.97)
            c.rect(M - 6, y - 5, W - 2 * M + 12, 20, fill=1, stroke=0)
        txt(M, y, sym, 10.5, True, accent if is_hl else (0.1, 0.14, 0.2))
        txt(M + 70, y, desc, 9.5, False, (0.2, 0.24, 0.3))
        c.setFont("Helvetica-Bold", 11)
        c.setFillColorRGB(*(accent if is_hl else (0.1, 0.14, 0.2)))
        c.drawRightString(W - M, y, fmt(val))
        y -= 20
    y -= 4
    txt(M, y, f"Value used by SprinkFlow for this design: {highlight} = {fmt(payload.get('sds') if highlight=='SDS' else payload.get('ss'))}",
        9.5, True, accent)
    y -= 26

    # provenance
    section("Source & verification")
    txt(M, y, payload.get("source") or "USGS Seismic Design Web Services", 9.5, True, (0.1, 0.14, 0.2)); y -= 16
    txt(M, y, "Retrieved: " + str(payload.get("retrievedAt") or ""), 9, False, mut); y -= 16
    txt(M, y, "Reproduce / verify this result at the exact query below:", 9, False, mut); y -= 14
    url = payload.get("usgsUrl") or ""
    c.setFillColorRGB(0.13, 0.33, 0.55)
    c.setFont("Helvetica", 7.6)
    # wrap the URL across lines so it never clips
    from reportlab.pdfbase.pdfmetrics import stringWidth
    maxw = W - 2 * M
    line = ""
    for ch in url:
        if stringWidth(line + ch, "Helvetica", 7.6) > maxw:
            c.drawString(M, y, line); y -= 11; line = ch
        else:
            line += ch
    if line:
        c.drawString(M, y, line); y -= 11
    if url:
        c.linkURL(url, (M, y, W - M, y + 12 * (1 + len(url) // 120 + 2)), relative=0)

    # footer
    c.setFillColorRGB(*mut)
    c.setFont("Helvetica-Oblique", 8)
    c.drawString(M, 40, "Values retrieved from the official USGS Seismic Design Web Services. The design professional is responsible "
                        "for confirming the site class, risk category, and applicability to the project.")
    c.drawString(M, 28, "Generated by SprinkFlow - sprinkflow.studio")

    c.save()
    return buf.getvalue()


def seismic_restraint(payload):
    """Branch-line restraint spacing check (Table 18.6.4) - edition-aware,
    Cp resolved from the same seismic basis as the main calc."""
    edition = payload.get("edition", "2025")
    cp, cp_basis = _resolve_cp(edition, payload.get("seismic", {}))
    res = branch_restraint.check_restraint_spacing(
        payload["tableId"], payload["size"], cp, float(payload["spacingFt"]),
        edition=edition)
    return {"edition": edition, "cp": round(cp, 4), "cpBasis": cp_basis,
            "status": res.status,
            "maxSpacingFt": res.capacity.value if res.capacity else None,
            "detail": res.detail, "governing": res.governing}


def seismic_riser_screen(payload):
    """Riser-nipple / branch-line screening (Equation 18.5.9.6.2 family),
    evaluated with the chosen edition's printed multiplier and comparator."""
    edition = payload.get("edition", "2025")
    cp, cp_basis = _resolve_cp(edition, payload.get("seismic", {}))
    res = editions.riser_nipple_screening(
        edition, wp_lb=float(payload["wpLb"]), cp=cp,
        hr_in=float(payload["hrIn"]), s_in3=float(payload["sIn3"]),
        fy_psi=float(payload.get("fyPsi") or 30000))
    res["cp"] = round(cp, 4)
    res["cpBasis"] = cp_basis
    res["edition"] = edition
    return res


_SYMBOL_LIB = None


def _load_symbols():
    """Real manufacturer CAD symbols (vector art extracted from published
    catalogs/submittals, or official CAD downloads). {figure: entry}."""
    global _SYMBOL_LIB
    if _SYMBOL_LIB is None:
        try:
            path = DATA_DIR / "symbols" / "symbols.json"
            _SYMBOL_LIB = load_json(path).get("symbols", {})
        except Exception:
            _SYMBOL_LIB = {}
    return _SYMBOL_LIB


def _symbol_for(component_row):
    """Match a componentRow's figure token against the symbol library."""
    if not component_row:
        return None
    text = str(component_row.get("component", ""))
    for figure, entry in _load_symbols().items():
        if figure in text:
            return figure, entry
    return None


def _detail_art():
    try:
        return load_json(DATA_DIR / "detail_art.json").get("symbols") or {}
    except Exception:
        return {}


def _structure_family(payload, edition):
    """wood / steel / concrete from the selected fastener table title."""
    try:
        from seismic_bracing.datasets import load_table as _lt
        title = _lt((payload.get("fastener") or {}).get("tableId"), edition=edition).get("title", "")
    except Exception:
        return None
    if re.search(r"Lumber|Wood(?! Form)", title, re.I):
        return "wood"
    if re.search(r"\bSteel\b", title, re.I):
        return "steel"
    return "concrete"


def seismic_detail_dxf(payload, result):
    """Brace detail composed from REAL manufacturer linework (R12 DXF).

    Component art is TOLCO's own drafting, dissected from the owner's detail
    DWGs into anchored symbols (data/seismic_bracing/detail_art.json): the
    Fig. 800-on-I-beam structure attachment, Fig. 910 swivel, and Fig. 1000
    Fast Clamp for steel; the Fig. 980-at-wood side elevation for wood. The
    swivel and clamp rotate to the TRUE entered brace angle, the Fast Clamp
    scales so its pipe section equals the TRUE braced-pipe OD, and the brace
    member is drawn at its true OD between the art anchors with a standard
    break. Structure families without art yet (concrete/deck) fall back to
    the parametric schematic composer."""
    art = _detail_art()
    edition = payload.get("edition", "2025")
    family = _structure_family(payload, edition)
    if family == "steel" and "steel_ibeam_fig800" in art:
        return _detail_dxf_from_art(payload, result, art, "steel")
    if family == "wood" and "fig980_wood_side" in art:
        return _detail_dxf_from_art(payload, result, art, "wood")
    return _detail_dxf_schematic(payload, result)


def _detail_dxf_from_art(payload, result, art, family):
    import math
    std = load_json(DATA_DIR / "detail_standard.json")
    md = result.get("memberDetail") or {}
    comp_rows = result.get("componentRows") or []
    roles = {}
    for c_in, row in zip(payload.get("components", []), comp_rows):
        roles.setdefault(c_in.get("role", "component"), row)

    def od_in(nps, default):
        key = seismicish_pretty(str(nps or "")).replace('"', "").strip()
        return float(std["pipeOdIn"].get(key, default))

    pipe_od = od_in((result.get("bracedPipe") or {}).get("size"), 2.375)
    member_od = od_in(md.get("size"), 1.315)
    angle = min(max(float(result.get("angleDeg") or 45), 15), 80)
    t = math.radians(angle)

    # scene is drawn in SOURCE ART UNITS; f converts units -> inches so the
    # Fast Clamp's drawn pipe section equals the true braced-pipe OD
    clamp = art["fig1000_clamp_on_pipe"]
    f = (pipe_od / 2.0) / float(clamp.get("pipeRadiusUnits") or 0.246)

    handed = -1.0 if family == "steel" else 1.0   # steel art runs down-left, wood down-right
    down = (handed * math.sin(t), -math.cos(t))    # unit vector along the brace, from structure to pipe

    out = []
    w = lambda code, v: (out.append(str(code)), out.append(str(v)))
    L = std["layers"]

    w(0, "SECTION"); w(2, "HEADER"); w(9, "$ACADVER"); w(1, "AC1009")
    w(9, "$INSUNITS"); w(70, 1); w(0, "ENDSEC")
    w(0, "SECTION"); w(2, "TABLES"); w(0, "TABLE"); w(2, "LAYER"); w(70, 3)
    for key in ("detail", "text", "center"):
        w(0, "LAYER"); w(2, L[key]["name"]); w(70, 0); w(62, L[key]["aci"]); w(6, "CONTINUOUS")
    w(0, "ENDTAB"); w(0, "ENDSEC"); w(0, "SECTION"); w(2, "ENTITIES")
    n = lambda v: "%.4f" % (float(v) * f)

    bb = [1e9, 1e9, -1e9, -1e9]        # running content bbox in art units
    track_on = [True]

    def trk(x, y):
        if not track_on[0]:
            return
        bb[0] = min(bb[0], x); bb[1] = min(bb[1], y)
        bb[2] = max(bb[2], x); bb[3] = max(bb[3], y)

    def pline(pts, layer="detail"):
        w(0, "POLYLINE"); w(8, L[layer]["name"]); w(66, 1); w(70, 0)
        for (x, y) in pts:
            w(0, "VERTEX"); w(8, L[layer]["name"]); w(10, n(x)); w(20, n(y)); w(30, 0)
            trk(x, y)
        w(0, "SEQEND")

    def circle(cx, cy, r, layer="detail"):
        w(0, "CIRCLE"); w(8, L[layer]["name"]); w(10, n(cx)); w(20, n(cy)); w(30, 0); w(40, n(r))
        trk(cx - r, cy - r); trk(cx + r, cy + r)

    def arc(cx, cy, r, a1, a2, layer="detail"):
        w(0, "ARC"); w(8, L[layer]["name"]); w(10, n(cx)); w(20, n(cy)); w(30, 0)
        w(40, n(r)); w(50, "%.3f" % a1); w(51, "%.3f" % a2)
        trk(cx - r, cy - r); trk(cx + r, cy + r)

    def text(x, y, h_units, s_txt, layer="text"):
        w(0, "TEXT"); w(8, L[layer]["name"]); w(10, n(x)); w(20, n(y)); w(30, 0)
        w(40, "%.4f" % (h_units * f)); w(1, str(s_txt).upper())
        trk(x, y - h_units * 0.25); trk(x + len(str(s_txt)) * h_units * 0.72, y + h_units)

    def place(sym, at, rot_deg=0.0):
        """Emit a symbol's primitives rotated about its anchor then moved to `at`."""
        cr, sr = math.cos(math.radians(rot_deg)), math.sin(math.radians(rot_deg))
        rot = lambda x, y: (x * cr - y * sr, x * sr + y * cr)
        for p in sym["prims"]:
            if p["k"] == "l":
                x1, y1 = rot(p["p"][0], p["p"][1]); x2, y2 = rot(p["p"][2], p["p"][3])
                pline([(at[0] + x1, at[1] + y1), (at[0] + x2, at[1] + y2)])
            elif p["k"] == "c":
                cx, cy = rot(*p["c"])
                circle(at[0] + cx, at[1] + cy, p["r"])
            elif p["k"] == "a":
                cx, cy = rot(*p["c"])
                arc(at[0] + cx, at[1] + cy, p["r"], p["a"][0] + rot_deg, p["a"][1] + rot_deg)
            else:
                pts = [rot(q[0], q[1]) for q in p["pts"]]
                pline([(at[0] + x, at[1] + y) for x, y in pts])

    def rot_to(sym, target_vec):
        """Signed rotation (deg) taking the symbol's tipDir onto target_vec."""
        tx, ty = sym.get("tipDir") or [-0.3, -0.32]
        cross = tx * target_vec[1] - ty * target_vec[0]
        dot = tx * target_vec[0] + ty * target_vec[1]
        return math.degrees(math.atan2(cross, dot))

    A = (0.0, 0.0)                 # structure attachment pin
    Lb = 1.85                      # brace run in art units (matches the TOLCO sheet proportions)
    E = (A[0] + down[0] * Lb, A[1] + down[1] * Lb)

    # ---- structure + attachment art ----
    if family == "steel":
        place(art["steel_ibeam_fig800"], A)
        place(art["fig910_swivel"], A, rot_deg=rot_to(art["fig910_swivel"], down))
    else:
        # the wood art carries its own structure - it stays at its drawn
        # attitude (N.T.S. typical); the brace leaves its clevis at true angle
        place(art["fig980_wood_side"], A)

    # ---- brace member: true OD double line with a standard break ----
    hw = (member_od / 2.0) / f
    nx, ny = -down[1], down[0]
    s0 = 0.34 if family == "steel" else 0.2   # clears the swivel/clevis art
    e0 = Lb - (pipe_od / 2.0) / f - 0.16
    b1, b2 = s0 + (e0 - s0) * 0.52, s0 + (e0 - s0) * 0.60
    for seg in ((s0, b1), (b2, e0)):
        for sgn in (1, -1):
            pline([(A[0] + down[0] * seg[0] + sgn * nx * hw, A[1] + down[1] * seg[0] + sgn * ny * hw),
                   (A[0] + down[0] * seg[1] + sgn * nx * hw, A[1] + down[1] * seg[1] + sgn * ny * hw)])
    for bpos, lead in ((b1, 1), (b2, -1)):
        bx, by = A[0] + down[0] * bpos, A[1] + down[1] * bpos
        z = hw * 1.7
        pline([(bx + nx * z, by + ny * z),
               (bx + nx * z * 0.3 + down[0] * 0.03 * lead, by + ny * z * 0.3 + down[1] * 0.03 * lead),
               (bx - nx * z * 0.3 - down[0] * 0.03 * lead, by - ny * z * 0.3 - down[1] * 0.03 * lead),
               (bx - nx * z, by - ny * z)])

    # ---- pipe attachment art at the true angle, pipe section at true OD ----
    place(clamp, E, rot_deg=rot_to(clamp, (-down[0], -down[1])))

    # ---- angle reference (standard) ----
    pline([(A[0], A[1] - 0.06), (A[0], A[1] - 0.9)], "center")
    arc_r = 0.55
    steps = 10
    pts = [(A[0] + handed * arc_r * math.sin(t * i / steps), A[1] - arc_r * math.cos(t * i / steps))
           for i in range(steps + 1)]
    pline(pts, "text")
    text(A[0] + handed * 0.16, A[1] - 0.75, 0.085, f"{angle:g} DEG FROM VERTICAL")

    # ---- standardized callouts: structure-side & pipe-side columns ----
    # matches the TOLCO source sheets - structure/fastener labels stack on the
    # brace-run side, brace/pipe labels on the open side; leaders fan to a rail
    # so none cross each other or the artwork.
    th = 0.085

    def short_fig(row, fallback):
        m = re.match(r"^(\S+\s+(?:Fig\.?|AF|CSB)\s*\S+)", str((row or {}).get("component", "")))
        return (m.group(1) if m else str((row or {}).get("component", "")) or fallback)[:30]

    bp_size = seismicish_pretty((result.get("bracedPipe") or {}).get("size") or "")
    member_lbl = (seismicish_pretty(md.get("size", "")) + " IN. "
                  + str(md.get("category", "")).replace("Pipe Schedule", "SCH.") + " BRACE")
    midp = (A[0] + down[0] * (s0 + e0) / 2, A[1] + down[1] * (s0 + e0) / 2)
    pr = (pipe_od / 2.0) / f

    # snapshot the drawn scene before adding any callout geometry
    scene = (bb[0], bb[1], bb[2], bb[3])
    fd = result.get("fastenerDetail") or {}

    struct_group = [(A[0], A[1] + 0.30,
                     short_fig(roles.get("structure_attachment"), "SWAY BRACE STRUCTURE ATTACHMENT"))]
    if fd.get("size"):
        struct_group.append((A[0] - handed * 0.30, A[1] + 0.52,
                             seismicish_pretty(fd["size"]) + " IN. FASTENER (SEE CALC)"))
    pipe_group = [
        (midp[0], midp[1], member_lbl),
        (E[0] - handed * pr * 0.5, E[1] + pr * 0.5,
         short_fig(roles.get("pipe_attachment"), "SWAY BRACE PIPE ATTACHMENT")),
        (E[0], E[1] - pr * 0.9, (bp_size + " IN. BRACED PIPE") if bp_size else "BRACED PIPE"),
    ]

    gap = 0.7
    # structure text on the brace-run side (handed<0 -> left), pipe text opposite
    struct_rail = (scene[0] - gap) if handed < 0 else (scene[2] + gap)
    struct_side = -1 if handed < 0 else 1
    pipe_rail = (scene[2] + gap) if handed < 0 else (scene[0] - gap)
    pipe_side = 1 if handed < 0 else -1

    def place_column(items, rail_x, side):
        items = sorted(items, key=lambda c: -c[1])   # top of sheet first
        tips = [c[1] for c in items]
        hi, lo = max(tips) + 0.12, min(tips) - 0.12
        need = th * 2.6 * (len(items) - 1)
        if hi - lo < need:
            mid = (hi + lo) / 2
            hi, lo = mid + need / 2, mid - need / 2
        ys = ([hi - (hi - lo) * i / (len(items) - 1) for i in range(len(items))]
              if len(items) > 1 else [items[0][1]])
        for (tx, ty, label), sy in zip(items, ys):
            circle(tx, ty, 0.022)                     # leader dot on the part
            end_x = rail_x + side * 0.30
            pline([(tx, ty), (rail_x, sy), (end_x, sy)], "text")
            if side < 0:
                text(end_x - 0.07 - len(label) * th * 0.72, sy - th / 2, th, label)
            else:
                text(end_x + 0.07, sy - th / 2, th, label)

    place_column(struct_group, struct_rail, struct_side)
    place_column(pipe_group, pipe_rail, pipe_side)

    # ---- drawing border + title block ----
    track_on[0] = False
    m0 = 0.4
    tb_h = 0.62
    x1, y1 = bb[0] - m0, bb[1] - m0 - tb_h
    x2, y2 = bb[2] + m0, bb[3] + m0
    pline([(x1, y1), (x2, y1), (x2, y2), (x1, y2), (x1, y1)])
    tb_top = y1 + tb_h
    pline([(x1, tb_top), (x2, tb_top)])
    div_x = x2 - 1.25
    pline([(div_x, y1), (div_x, tb_top)])
    bid = (payload.get("project") or {}).get("braceId") or ""
    title = std["title"]["format"].replace("{braceId}", bid or "TYP.")
    text(x1 + 0.16, tb_top - 0.30, 0.13, title)
    text(x1 + 0.16, tb_top - 0.52, 0.085, std["title"]["sub"])
    text(div_x + 0.14, tb_top - 0.30, 0.12, "SCALE")
    text(div_x + 0.14, tb_top - 0.52, 0.11, "N.T.S.")

    w(0, "ENDSEC"); w(0, "EOF")
    return "\n".join(out)


def _detail_dxf_schematic(payload, result):
    """STANDARDIZED parametric brace detail (R12 DXF).

    Every detail is composed from data/seismic_bracing/detail_standard.json:
    the braced pipe and brace member are drawn at their TRUE outside diameters
    (ASME B36.10), the brace runs at the TRUE entered angle, and the component
    glyphs (swivel at the structure, clamp at the pipe) are parametric in the
    member/pipe OD - so a 1 in. Sch 40 brace on 4 in. pipe at 45 deg looks
    identical across every detail in the set, and swapping figures never
    changes the family look. Callouts, text heights, layers, hatch and the
    title line all come from the standard."""
    import math
    std = load_json(DATA_DIR / "detail_standard.json")
    md = result.get("memberDetail") or {}
    comp_rows = result.get("componentRows") or []
    roles = {}
    for c_in, row in zip(payload.get("components", []), comp_rows):
        roles.setdefault(c_in.get("role", "component"), row)

    def od(nps, default):
        key = seismicish_pretty(str(nps or "")).replace('"', "").strip()
        return float(std["pipeOdIn"].get(key, default))

    p_od = od((result.get("bracedPipe") or {}).get("size"), 4.5)     # braced pipe
    m_od = od(md.get("size"), 1.315)                                  # brace member
    angle = float(result.get("angleDeg") or 45)
    a_rad = math.radians(min(max(angle, 15), 75))

    # scene geometry (true scale, inches)
    rise = max(6.0, p_od * 1.6 + 4.0)
    run = rise * math.tan(a_rad)
    px, py = p_od / 2 + 1.2, p_od / 2 + 1.2          # braced pipe center
    ax, ay = px + run, py + rise                      # structure connection point

    out = []
    w = lambda code, v: (out.append(str(code)), out.append(str(v)))
    n = lambda v: "%.4f" % float(v)
    L = std["layers"]

    w(0, "SECTION"); w(2, "HEADER"); w(9, "$ACADVER"); w(1, "AC1009")
    w(9, "$INSUNITS"); w(70, 1); w(0, "ENDSEC")
    w(0, "SECTION"); w(2, "TABLES"); w(0, "TABLE"); w(2, "LAYER"); w(70, 3)
    for key in ("detail", "text", "center"):
        w(0, "LAYER"); w(2, L[key]["name"]); w(70, 0); w(62, L[key]["aci"]); w(6, "CONTINUOUS")
    w(0, "ENDTAB"); w(0, "ENDSEC"); w(0, "SECTION"); w(2, "ENTITIES")

    def pline(pts, layer="detail"):
        w(0, "POLYLINE"); w(8, L[layer]["name"]); w(66, 1); w(70, 0)
        for (x, y) in pts:
            w(0, "VERTEX"); w(8, L[layer]["name"]); w(10, n(x)); w(20, n(y)); w(30, 0)
        w(0, "SEQEND")

    def circle(cx, cy, r, layer="detail"):
        w(0, "CIRCLE"); w(8, L[layer]["name"]); w(10, n(cx)); w(20, n(cy)); w(30, 0); w(40, n(r))

    def text(x, y, h, s_txt, layer="text"):
        w(0, "TEXT"); w(8, L[layer]["name"]); w(10, n(x)); w(20, n(y)); w(30, 0)
        w(40, n(h)); w(1, str(s_txt).upper())

    th = std["text"]["calloutHeightIn"]

    def callout(tip_x, tip_y, land_x, land_y, label):
        """Standard leader: tip -> landing point -> horizontal landing + text."""
        landing = std["callout"]["leaderLandingIn"]
        d = 1 if land_x >= tip_x else -1
        pline([(tip_x, tip_y), (land_x, land_y), (land_x + d * landing, land_y)], "text")
        tx = land_x + d * (landing + std["callout"]["gapIn"])
        text(tx if d > 0 else tx - len(label) * th * 0.75, land_y - th / 2, th, label)

    # ---- structure line + hatch ----
    over = std["structure"]["lineOverhangIn"]
    pline([(px - over, ay), (ax + over + 1.5, ay)])
    hx = px - over + 0.2
    while hx < ax + over + 1.3:
        pline([(hx, ay), (hx + std["structure"]["hatchLengthIn"], ay + std["structure"]["hatchLengthIn"])])
        hx += std["structure"]["hatchSpacingIn"]

    # ---- braced pipe: true OD + standard centerline cross ----
    circle(px, py, p_od / 2)
    cl = p_od / 2 + 0.3
    pline([(px - cl, py), (px + cl, py)], "center")
    pline([(px, py - cl), (px, py + cl)], "center")

    # ---- brace member: double line at true OD along the true angle ----
    ux, uy = math.sin(a_rad), math.cos(a_rad)          # unit vector pipe->structure
    nx_, ny_ = -uy, ux                                 # normal
    half = m_od / 2
    start_off = p_od / 2 + 0.22 * m_od                 # clears the clamp band
    sx, sy = px + ux * start_off, py + uy * start_off
    ex, ey = ax - ux * (1.9 * m_od), ay - uy * (1.9 * m_od)   # stops at the swivel clevis
    pline([(sx + nx_ * half, sy + ny_ * half), (ex + nx_ * half, ey + ny_ * half)])
    pline([(sx - nx_ * half, sy - ny_ * half), (ex - nx_ * half, ey - ny_ * half)])

    # ---- pipe clamp glyph (parametric in p_od & m_od) ----
    for band in (0.16, 0.3):
        r = p_od / 2 + band * m_od
        steps = 20
        pts = []
        for i in range(steps + 1):
            ang = -math.pi / 2 + math.pi * i / steps
            pts.append((px + r * math.cos(ang + a_rad - math.pi / 2),
                        py + r * math.sin(ang + a_rad - math.pi / 2)))
        pline(pts)
    pline([(sx + nx_ * half * 1.6, sy + ny_ * half * 1.6),
           (sx - nx_ * half * 1.6, sy - ny_ * half * 1.6)])
    circle(sx + ux * 0.4 * m_od, sy + uy * 0.4 * m_od, 0.28 * m_od)   # clamp bolt

    # ---- swivel glyph at the structure (parametric in m_od) ----
    plate_w = 2.2 * m_od
    plate_t = 0.35 * m_od
    pline([(ax - plate_w / 2, ay), (ax - plate_w / 2, ay - plate_t),
           (ax + plate_w / 2, ay - plate_t), (ax + plate_w / 2, ay)])
    bolt_h = 0.9 * m_od
    for bx in (ax - plate_w * 0.33, ax + plate_w * 0.33):
        pline([(bx - 0.12 * m_od, ay - plate_t), (bx - 0.12 * m_od, ay - plate_t - bolt_h * 0.25),
               (bx + 0.12 * m_od, ay - plate_t - bolt_h * 0.25), (bx + 0.12 * m_od, ay - plate_t)])
    cx1, cy1 = ax - ux * plate_t, ay - uy * plate_t
    pline([(cx1 + nx_ * half * 1.25, cy1 + ny_ * half * 1.25),
           (ex + nx_ * half * 1.25, ey + ny_ * half * 1.25)])
    pline([(cx1 - nx_ * half * 1.25, cy1 - ny_ * half * 1.25),
           (ex - nx_ * half * 1.25, ey - ny_ * half * 1.25)])
    circle(ex + ux * 0.5 * m_od, ey + uy * 0.5 * m_od, 0.3 * m_od)    # swivel pin

    # ---- angle reference (standard) ----
    pline([(ax, ay), (ax, ay - 2.2)], "center")
    arc_r = 1.5
    steps = 10
    pts = [(ax + arc_r * math.sin(a_rad * i / steps), ay - arc_r * math.cos(a_rad * i / steps))
           for i in range(steps + 1)]
    pline(pts, "text")
    text(ax + 0.35, ay - 1.9, th, f"{angle:g} DEG FROM VERTICAL")

    # ---- standardized callouts ----
    def short_fig(row, fallback):
        import re as _re
        if not row:
            return fallback
        m = _re.match(r"^(\S+\s+(?:Fig\.?|AF|CSB)\s*\S+)", str(row.get("component", "")))
        return (m.group(1) if m else str(row.get("component", "")))[:26]

    bp_size = seismicish_pretty((result.get("bracedPipe") or {}).get("size") or "")
    member_lbl = (seismicish_pretty(md.get("size", "")) + " IN. "
                  + str(md.get("category", "")).replace("Pipe Schedule", "SCH.") + " BRACE")
    mid_x, mid_y = (sx + ex) / 2, (sy + ey) / 2
    callout(mid_x - nx_ * half, mid_y - ny_ * half, mid_x + 1.4, mid_y - 1.0, member_lbl)
    callout(px + p_od * 0.35, py - p_od * 0.35, px + p_od / 2 + 1.6, py - p_od * 0.7,
            (bp_size + " IN. BRACED PIPE") if bp_size else "BRACED PIPE")
    callout(sx, sy, px + p_od / 2 + 1.9, py + p_od * 0.55,
            short_fig(roles.get("pipe_attachment"), "SWAY BRACE PIPE ATTACHMENT"))
    callout(ax - plate_w / 2, ay - plate_t, ax - 2.6, ay - 1.1,
            short_fig(roles.get("structure_attachment"), "SWAY BRACE STRUCTURE ATTACHMENT"))
    fd = result.get("fastenerDetail") or {}
    if fd.get("size"):
        callout(ax + plate_w * 0.33, ay - plate_t - bolt_h * 0.25, ax + 2.2, ay - 0.75,
                seismicish_pretty(fd["size"]) + " IN. FASTENER (SEE CALC)")

    # ---- title (standard format) ----
    bid = (payload.get("project") or {}).get("braceId") or ""
    title = std["title"]["format"].replace("{braceId}", bid or "TYP.")
    text(px - p_od / 2 - 0.2, py - p_od / 2 - 1.5, std["text"]["titleHeightIn"], title)
    text(px - p_od / 2 - 0.2, py - p_od / 2 - 1.8, std["text"]["subTitleHeightIn"],
         std["title"]["sub"])
    pline([(px - p_od / 2 - 0.2, py - p_od / 2 - 1.62),
           (px - p_od / 2 - 0.2 + max(4.2, len(title) * std["text"]["titleHeightIn"] * 0.8),
            py - p_od / 2 - 1.62)], "text")

    w(0, "ENDSEC"); w(0, "EOF")
    return "\n".join(out)


def seismic_export_batch(braces, sheet_style="tolbrace"):
    """Render every saved brace to its calc sheet and merge into one PDF.
    Returns (pdf_bytes, summary list). A brace that fails to calculate gets a
    summary entry with its error instead of silently vanishing."""
    from pypdf import PdfReader, PdfWriter
    writer = PdfWriter()
    summary = []
    renderer = seismic_report_pdf_nfpa if sheet_style == "nfpa" else seismic_report_pdf
    for brace_payload in braces:
        label = (brace_payload.get("project") or {}).get("braceId") or "brace"
        try:
            result = seismic_calc(brace_payload)
            page_pdf = renderer(brace_payload, result)
            reader = PdfReader(io.BytesIO(page_pdf))
            for page in reader.pages:
                writer.add_page(page)
            writer.add_outline_item(f"{label} — {result['overall']}", len(writer.pages) - 1)
            summary.append({"braceId": label, "overall": result["overall"],
                            "fpwLb": result["fpwLb"]})
        except Exception as exc:
            summary.append({"braceId": label, "overall": "ERROR", "error": str(exc)})
    if not writer.pages:
        raise ValueError("no braces could be rendered: "
                         + "; ".join(f"{s['braceId']}: {s.get('error')}" for s in summary))
    out = io.BytesIO()
    writer.write(out)
    return out.getvalue(), summary


def seismic_report_png(pdf_bytes, dpi=200):
    """Render page 1 of the calc PDF to a full-page PNG (8.5x11 at >= 150 dpi
    per the owner spec; default 200 dpi = 1700x2200)."""
    import pypdfium2 as pdfium
    doc = pdfium.PdfDocument(pdf_bytes)
    try:
        pil = doc[0].render(scale=dpi / 72.0).to_pil().convert("RGB")
    finally:
        doc.close()
    buf = io.BytesIO()
    pil.save(buf, "PNG")
    return buf.getvalue(), pil.width, pil.height
