# -*- coding: utf-8 -*-
"""Seismic-bracing model vocabulary and calc-sheet recognition.

Why this module exists
----------------------
A real plan set almost never says "lateral brace" and leaves it there. It
carries the manufacturer's seismic bracing CALCULATION SHEET, and that sheet
names the exact components: the pipe attachment (TOLCO Fig. 1001), the swivel /
brace fitting (Fig. 980), the structure attachment (Fig. 825 / 828 / 4L), the
brace member. Those calc sheets are almost always EMBEDDED AS AN IMAGE - they
are a PDF printed out of TolcoCalc / SizeBrace / SprinkFlow and dropped onto
the sheet - so the plan's text layer says nothing about them.

So the detection is two halves:

  * this module - PURE text work: what the model numbers look like, which role
    each one plays, and what a bracing calc sheet reads like. No filesystem, no
    OS, no OCR; it runs unchanged in the browser edition (Pyodide) alongside
    plan_scan_core.
  * plan_detail_ocr.py - the desktop-only half that finds the embedded rasters
    and reads them with tesseract, then hands the text back here.

The vocabulary mirrors data/seismic_bracing/components/*.json (the seismic
calculator's own component library, which carries the manufacturer-published
rated loads). It is transcribed here rather than loaded from disk so the module
stays importable in the browser bundle;
tests/test_plan_bracing_vocab.py asserts the two never drift apart.
"""
from __future__ import annotations

import re

# --------------------------------------------------------------------------
# Manufacturers
# --------------------------------------------------------------------------

TOLCO = "TOLCO"
AFCON = "AFCON"
CADDY = "nVent CADDY"

#: Manufacturer -> the catalog's `manufacturer` spelling for datasheet rows.
#: (data/datasheet_catalog.json files TOLCO rows under "Tolco" and ASC's AFCON
#: rows under "AFCON"; nVent CADDY bracing has no catalog rows yet.)
BRACING_CATALOG_MANUFACTURER = {
    TOLCO: "Tolco",
    AFCON: "AFCON",
    CADDY: "nVent CADDY",
}

#: role -> the words a reviewer actually uses for it.
BRACING_ROLE_LABELS = {
    "pipe_attachment": "Brace attachment (to pipe)",
    "brace_fitting": "Swivel / brace fitting",
    "structure_attachment": "Structure attachment",
    "restraint": "Branch line restraint",
    "rod_stiffener": "Rod stiffener",
    "adapter": "Adapter",
    "brace_member": "Brace member (pipe)",
}

#: Sort order for presenting a found assembly: the way it is built, pipe first.
BRACING_ROLE_ORDER = [
    "pipe_attachment",
    "brace_fitting",
    "structure_attachment",
    "brace_member",
    "restraint",
    "rod_stiffener",
    "adapter",
]


# --------------------------------------------------------------------------
# Vocabulary
#
# Each entry: (match token, display figure, role, product name).
# The match token is what the regexes canonicalise to, NOT what is displayed.
# --------------------------------------------------------------------------

TOLCO_COMPONENTS = [
    ("1001", "Fig. 1001", "pipe_attachment", "Sway Brace Attachment"),
    ("980", "Fig. 980", "brace_fitting", "Universal Swivel Sway Brace Attachment"),
    ("980H", "Fig. 980H", "brace_fitting", "Universal Swivel Sway Brace Attachment (large rod)"),
    ("909", "Fig. 909", "brace_fitting", "No-Thread Swivel Sway Brace Attachment"),
    ("910", "Fig. 910", "brace_fitting", "Threaded Swivel Sway Brace Attachment"),
    ("975", "Fig. 975", "brace_fitting", "Straight Sway Brace Fitting"),
    ("907", "Fig. 907", "brace_fitting", "Multi-Angle Attachment"),
    ("4L", "Fig. 4L", "pipe_attachment", "Sway Brace Attachment (in-line / lateral)"),
    ("1000", "Fig. 1000", "pipe_attachment", "Fast Clamp Sway Brace Attachment"),
    ("2002", "Fig. 2002", "pipe_attachment", "Sway Brace Attachment"),
    ("3000", "Fig. 3000", "pipe_attachment", "CPVC and Steel Sway Brace Attachment"),
    ("4A", "Fig. 4A", "pipe_attachment", "Pipe Clamp for Sway Bracing"),
    ("4LA", "Fig. 4LA", "pipe_attachment", "In-Line Sway Brace Attachment"),
    ("800", "Fig. 800", "structure_attachment", "Adjustable Sway Brace Attachment to Steel"),
    ("825", "Fig. 825", "structure_attachment", "Bar Joist Sway Brace Attachment to Steel"),
    ("825A", "Fig. 825A", "structure_attachment", "Bar Joist Sway Brace Attachment to Steel"),
    ("828", "Fig. 828", "structure_attachment", "Universal Sway Brace Attachment to Steel"),
    ("906", "Fig. 906", "adapter", "Sway Brace Multi-Fastener Adapter"),
    ("98", "Fig. 98", "rod_stiffener", "Rod Stiffener"),
    ("98B", "Fig. 98B", "rod_stiffener", "Rod Stiffener with Break-Off Bolt Head"),
    ("74", "Fig. 74", "structure_attachment", "Structural Attachment for Branch Line Restraint"),
    ("77", "Fig. 77", "restraint", "System Piping Attachment for Restraint Assembly"),
    ("75", "Fig. 75", "structure_attachment", "Swivel Attachment"),
    ("131", "Fig. 131", "structure_attachment", "Seismic Structural Brace Attachment for Wooden Joists"),
]

AFCON_COMPONENTS = [
    ("AF001", "AF001", "pipe_attachment", "Model Q Lateral Sway Brace (Q Brace Clamp)"),
    ("AF035", "AF035", "pipe_attachment", "Model K Lateral Sway Brace (Brace Clamp)"),
    ("AF075", "AF075", "brace_fitting", "Sway Brace Swivel Attachment"),
    ("AF076", "AF076", "brace_fitting", "Sway Brace Swivel Attachment"),
    ("AF077", "AF077", "brace_fitting", "Sway Brace Swivel Attachment"),
    ("AF085", "AF085", "structure_attachment", "Seismic Joist Adapter"),
    ("AF086", "AF086", "structure_attachment", "Adjustable Structural Brace Attachment"),
    ("AF087", "AF087", "structure_attachment", "Structural Brace Attachment"),
    ("AF090", "AF090", "restraint", "Restraining Strap"),
    ("AF090R", "AF090R", "restraint", "Retrofit Restraining Strap"),
    ("AF310", "AF310", "restraint", "Surge Restrainer"),
    ("AF700", "AF700", "brace_fitting", "Universal Swivel Attachment"),
    ("AF700SS", "AF700SS", "brace_fitting", "Universal Swivel Attachment - 316 Stainless Steel"),
    ("AF720", "AF720", "structure_attachment", "Universal Structural Brace Attachment"),
    ("AF727", "AF727", "structure_attachment", "Universal Structural Attachment & Swivel (Bear Claw)"),
    ("AF730", "AF730", "pipe_attachment", "Longitudinal & Lateral Seismic Clamp"),
    ("AF730SS", "AF730SS", "pipe_attachment", "Longitudinal & Lateral Seismic Clamp - 316 Stainless Steel"),
    ("AF735", "AF735", "pipe_attachment", "Multi-Size Lateral Brace Attachment (Bear Trap)"),
    ("AF771", "AF771", "brace_fitting", "Swivel Attachment (socket type)"),
    ("AF772", "AF772", "structure_attachment", "Adjustable Steel Beam Attachment"),
    ("AF773", "AF773", "restraint", "Surge Restrainer (rod-mounted)"),
    ("AF775", "AF775", "pipe_attachment", "Longitudinal & Lateral Seismic Clamp (socket type)"),
    ("AF776", "AF776", "pipe_attachment", "OSHPD Lateral Brace Clamp"),
    ("AF777", "AF777", "restraint", "Swivel Attachment (hanger / branch line restraint)"),
    ("AF778", "AF778", "structure_attachment", "Universal Structural Brace Attachment"),
    ("AF779", "AF779", "adapter", "Multi-Connector Adapter"),
]

#: CADDY part numbers are families, not single figures, so each entry carries
#: its own regex. ORDER MATTERS - longest / most specific first, because these
#: are tried with a first-match-wins scan over one alternation.
CADDY_COMPONENTS = [
    (r"CSB2W[A-Z0-9]{0,4}URC[A-Z0-9]{0,4}L[A-Z0-9]{0,4}", "CSB2W..URC..L..", "brace_fitting", "URC Attachment Kit (two-way cable bracing kit)"),
    (r"CSBQIKCL\d{4}(?:EG)?", "CSBQIKCL....", "pipe_attachment", "Quick Grip Jr. Lateral Sway Brace"),
    (r"CSBQG\d{4}(?:EG)?", "CSBQG....", "pipe_attachment", "Quick Grip Lateral Sway Brace"),
    (r"CSBURCR(?:38|12|58)", "CSBURCR..", "structure_attachment", "Universal Restraint Clip, Retrofit"),
    (r"CSBURC\d{2}", "CSBURC..", "structure_attachment", "Universal Restraint Clip"),
    (r"CSBNPC(?:38|12|58)", "CSBNPC..", "structure_attachment", "No Pry Clip (cable structural attachment)"),
    (r"CSBMA\d{6}(?:EG)?", "CSBMA......", "structure_attachment", "Multi Attachment (two-anchor load spreader)"),
    (r"CSBBRP\d{3}(?:EG)?", "CSBBRP...", "restraint", "Branch Line Restraint, Pipe Attachment Fitting"),
    (r"CSBBRS[123](?:EG)?", "CSBBRS.", "restraint", "Branch Line Restraint, Structural Attachment Fitting"),
    (r"CSBCS\d{4}", "CSBCS....", "adapter", "Clevis Bolt Spacer"),
    (r"CSBRS37(?:EG)?", "CSBRS37", "rod_stiffener", "Strut Rod Stiffener"),
    (r"CSBRS(?:14|[1-6])", "CSBRS.", "rod_stiffener", "Rod Stiffener"),
    (r"CSBUS[12]PA", "CSBUS.PA", "structure_attachment", "Strut Seismic Hinge Bracket Assembly"),
    (r"CSBUS[12]", "CSBUS.", "structure_attachment", "Universal Structural Bracket, Strut Brace"),
    (r"CSBS1A", "CSBS1A", "structure_attachment", "Steel Flange Adapter Assembly"),
    (r"CSBS[1-5]", "CSBS.", "structure_attachment", "Steel Flange / I-Beam Adapter"),
    (r"CSBU[12]", "CSBU.", "structure_attachment", "Universal Structural Bracket"),
    (r"CSBT[1-4]", "CSBT.", "brace_fitting", "Lateral Telescoping Brace Assembly"),
    (r"CSBR[12]", "CSBR.", "brace_fitting", "Trapeze Sway Brace"),
    (r"CSB\d{2}CBL(?:SS)?", "CSB..CBL", "brace_fitting", "Seismic Bracing Cable Spool"),
    (r"CSB\d{4}", "CSB....", "pipe_attachment", "Universal Sway Brace (Sway Brace Fitting)"),
]


def _index(components):
    return {token: (figure, role, name) for token, figure, role, name in components}


TOLCO_BY_TOKEN = _index(TOLCO_COMPONENTS)
AFCON_BY_TOKEN = _index(AFCON_COMPONENTS)


# --------------------------------------------------------------------------
# OCR-noise tolerance
#
# tesseract on a 200-DPI raster of an 8-point table gets the SHAPE right and the
# character class wrong: 1001 comes back "1O01" or "l001", 980H as "98OH", 4L as
# "4l". Every Tolco figure is digits (+ an optional letter suffix), so the fix
# is to canonicalise the confusable glyph pairs and then demand membership in
# the vocabulary - a junk token cannot survive the set test, so being generous
# here costs nothing.
# --------------------------------------------------------------------------

_DIGIT_LOOKALIKES = {"O": "0", "o": "0", "Q": "0", "D": "0",
                     "I": "1", "l": "1", "|": "1", "i": "1", "L": "1",
                     "S": "5", "s": "5", "Z": "2", "z": "2",
                     "B": "8", "G": "6"}

#: Letter suffixes a Tolco figure can legitimately end in (4L, 4LA, 825A, 98B,
#: 980H). Anything else trailing the digits is OCR debris and is dropped.
_TOLCO_SUFFIXES = ("LA", "H", "A", "L", "B")


def canonical_tolco_token(raw: str) -> str:
    """Best-effort repair of an OCR'd Tolco figure number.

    Returns "" when the token cannot be coerced into <digits><suffix?> shape.
    """
    token = re.sub(r"[^0-9A-Za-z|]", "", str(raw or "")).upper()
    if not token:
        return ""
    # Peel a known letter suffix off the end before de-confusing the digits, or
    # "980H" would have its H kept and its 9 8 0 read as digits anyway while
    # "4L" would lose the L to nothing.
    suffix = ""
    for candidate in _TOLCO_SUFFIXES:
        if token.endswith(candidate) and len(token) > len(candidate):
            suffix = candidate
            token = token[: -len(candidate)]
            break
    digits = "".join(_DIGIT_LOOKALIKES.get(ch, ch) for ch in token)
    if not digits.isdigit():
        return ""
    digits = digits.lstrip("0") or "0"
    return f"{digits}{suffix}"


def canonical_afcon_token(raw: str) -> str:
    """Repair an OCR'd AFCON part number ("AFOO1" -> "AF001")."""
    token = re.sub(r"[^0-9A-Za-z]", "", str(raw or "")).upper()
    match = re.fullmatch(r"A[FE]([0-9OoIlSZBG]{3})(SS|R)?", token)
    if not match:
        return ""
    digits = "".join(_DIGIT_LOOKALIKES.get(ch, ch) for ch in match.group(1))
    if not digits.isdigit():
        return ""
    return f"AF{digits}{match.group(2) or ''}"


# --------------------------------------------------------------------------
# Model regexes
# --------------------------------------------------------------------------

#: "TOLCO Fig. 1001", "FIG.1001", "Figure No. 825", "FIG-980H", "Fig 1O01".
#: The figure token is captured loosely and validated by canonicalisation +
#: vocabulary membership, which is what makes the OCR tolerance safe.
TOLCO_FIGURE_RE = re.compile(
    r"(?:\bTOLCO\b[^A-Za-z0-9]{0,12})?"
    r"\bFIG(?:URE)?\b[\s.:#\-_]{0,4}(?:NO\b[\s.:#\-_]{0,4})?"
    r"([0-9OoIl|][0-9A-Za-z|]{0,4})",
    re.IGNORECASE,
)

#: "TOLCO 1001" with no "Fig." at all - common in a calc sheet's component
#: table, where the column header already says the manufacturer.
TOLCO_BARE_RE = re.compile(
    r"\bTOLCO\b[^A-Za-z0-9]{0,4}([0-9OoIl|][0-9A-Za-z|]{0,4})",
    re.IGNORECASE,
)

#: "AF001", "AF-001", "AF 779", "AF700SS".
AFCON_PART_RE = re.compile(r"\bA[F8]\s*[-.]?\s*([0-9OoIlSZBG]{3})\s*(SS|R)?\b", re.IGNORECASE)

CADDY_PART_RE = re.compile(
    "|".join(f"(?:{pattern})" for pattern, *_ in CADDY_COMPONENTS),
    re.IGNORECASE,
)
_CADDY_MATCHERS = [(re.compile(f"^(?:{pattern})$", re.IGNORECASE), figure, role, name)
                   for pattern, figure, role, name in CADDY_COMPONENTS]


# --------------------------------------------------------------------------
# Calc-sheet recognition
# --------------------------------------------------------------------------

#: (label, regex, weight). A weight-2 marker is on its own enough to call the
#: sheet a bracing calc; weight-1 markers need a friend.
BRACING_CALC_MARKERS = [
    ("seismic bracing calculations", re.compile(r"\bseismic\s+brac(?:e|ing)\s+calc", re.IGNORECASE), 2),
    ("brace components table", re.compile(r"\bbrace\s+components?\b", re.IGNORECASE), 2),
    ("zone of influence", re.compile(r"\bzone\s+of\s+influence\b|\bZOI\b"), 2),
    ("sizebrace", re.compile(r"\bsize\s?brace\b", re.IGNORECASE), 2),
    ("bracing calculation", re.compile(r"\bbrac(?:e|ing)\s+calc(?:ulation)?s?\b", re.IGNORECASE), 2),
    ("brace id", re.compile(r"\bbrace\s+id\b", re.IGNORECASE), 2),
    ("horizontal load Fpw", re.compile(r"\bF\s?pw\b"), 2),
    ("NFPA 13 chapter 18.5", re.compile(r"\b18\.5(?:\.\d+)*\b"), 1),
    ("seismic", re.compile(r"\bseismic\b", re.IGNORECASE), 1),
    ("sway brace", re.compile(r"\bsway\s+brac(?:e|es|ing)\b", re.IGNORECASE), 1),
    ("brace type", re.compile(r"\bbrace\s+type\b", re.IGNORECASE), 1),
    ("brace member", re.compile(r"\bbrace\s+member\b", re.IGNORECASE), 1),
    ("max spacing", re.compile(r"\b(?:lateral|longitudinal)\s+max(?:imum)?\s+spacing\b", re.IGNORECASE), 1),
    ("Cp coefficient", re.compile(r"\bCp\s*[=:]"), 1),
    ("tolco", re.compile(r"\bTOLCO\b", re.IGNORECASE), 1),
    ("afcon", re.compile(r"\bAFCON\b", re.IGNORECASE), 1),
    ("asc engineered", re.compile(r"\bASC\s+ENGINEERED\b", re.IGNORECASE), 1),
    ("nvent caddy", re.compile(r"\bn?vent\s+caddy\b|\bCADDY\s+SEISMIC\b", re.IGNORECASE), 1),
]

#: Brace-type checkbox row on a calc sheet: "Brace Type: Lateral [X] Longitudinal [ ]"
_BRACE_TYPE_RE = re.compile(
    r"\b(lateral|longitudinal|4[-\s]?way|four[-\s]?way)\b\s*[\[(<]\s*([xX✓*])?\s*[\])>]",
    re.IGNORECASE,
)


def bracing_calc_markers(text: str) -> list[str]:
    """Which calc-sheet markers a blob of text carries, in table order."""
    source = re.sub(r"\s+", " ", str(text or ""))
    return [label for label, pattern, _weight in BRACING_CALC_MARKERS if pattern.search(source)]


def bracing_calc_score(text: str) -> int:
    source = re.sub(r"\s+", " ", str(text or ""))
    return sum(weight for _label, pattern, weight in BRACING_CALC_MARKERS if pattern.search(source))


def looks_like_bracing_calc(text: str) -> bool:
    """True when a sheet (or an embedded region) reads like a bracing calc."""
    return bracing_calc_score(text) >= 2


def brace_types(text: str) -> list[str]:
    """Brace types a calc sheet declares, from its ticked checkbox row.

    Falls back to a plain word scan when no checkbox row is present (third-party
    calcs often just print "LATERAL BRACE" as a heading).
    """
    source = re.sub(r"\s+", " ", str(text or ""))
    ticked = []
    any_checkbox = False
    for match in _BRACE_TYPE_RE.finditer(source):
        any_checkbox = True
        if match.group(2):
            ticked.append(_normalize_brace_type(match.group(1)))
    if ticked:
        return _dedupe(ticked)
    if any_checkbox:
        return []
    found = []
    if re.search(r"\blongitudinal\b", source, re.IGNORECASE):
        found.append("Longitudinal")
    if re.search(r"\blateral\b", source, re.IGNORECASE):
        found.append("Lateral")
    if re.search(r"\b(?:4[-\s]?way|four[-\s]?way)\b", source, re.IGNORECASE):
        found.append("4-Way")
    return _dedupe(found)


def _normalize_brace_type(value: str) -> str:
    lowered = str(value or "").lower().replace(" ", "").replace("-", "")
    if lowered.startswith("long"):
        return "Longitudinal"
    if lowered.startswith("lat"):
        return "Lateral"
    return "4-Way"


def _dedupe(values):
    seen = set()
    out = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        out.append(value)
    return out


# --------------------------------------------------------------------------
# Model extraction
# --------------------------------------------------------------------------

#: How many characters of context ride along with a hit, for the review row.
_CONTEXT = 90


def _context(source: str, match) -> str:
    start = max(0, match.start() - 24)
    return source[start:match.end() + 40].strip()[:_CONTEXT]


def find_bracing_models(text: str, source_kind: str = "text") -> list[dict]:
    """Every bracing component named in ``text``, with its role.

    ``source_kind`` is carried through onto each hit ("text" for the plan's own
    text layer, "ocr" for something read out of a rendered raster) and decides
    the confidence floor: a glyph the PDF itself declares is not in the same
    class of evidence as a shape tesseract guessed at.
    """
    blob = re.sub(r"[ \t ]+", " ", str(text or ""))
    found: dict[tuple, dict] = {}

    def add(manufacturer: str, token: str, figure: str, role: str, name: str, match) -> None:
        key = (manufacturer, token)
        entry = found.get(key)
        if entry is None:
            entry = {
                "manufacturer": manufacturer,
                "model": figure,
                "token": token,
                "role": role,
                "roleLabel": BRACING_ROLE_LABELS.get(role, role),
                "name": name,
                "hits": 0,
                "sourceKind": source_kind,
                "sourceText": _context(blob, match),
            }
            found[key] = entry
        entry["hits"] += 1
        if source_kind == "text" and entry["sourceKind"] != "text":
            entry["sourceKind"] = "text"

    for pattern in (TOLCO_FIGURE_RE, TOLCO_BARE_RE):
        for match in pattern.finditer(blob):
            token = canonical_tolco_token(match.group(1))
            hit = TOLCO_BY_TOKEN.get(token)
            if hit:
                add(TOLCO, token, hit[0], hit[1], hit[2], match)

    for match in AFCON_PART_RE.finditer(blob):
        token = canonical_afcon_token(f"AF{match.group(1)}{match.group(2) or ''}")
        hit = AFCON_BY_TOKEN.get(token)
        if hit:
            add(AFCON, token, hit[0], hit[1], hit[2], match)

    for match in CADDY_PART_RE.finditer(blob):
        raw = match.group(0).upper().replace(" ", "")
        for matcher, family, role, name in _CADDY_MATCHERS:
            if matcher.match(raw):
                # The part number AS PRINTED is the model - "CSBRS2", not the
                # family pattern "CSBRS." that matched it. The family only
                # decides which role and product name the hit carries.
                add(CADDY, raw, raw, role, f"{name} ({family})", match)
                break

    results = list(found.values())
    for entry in results:
        entry["confidence"] = model_confidence(entry)
    order = {role: index for index, role in enumerate(BRACING_ROLE_ORDER)}
    results.sort(key=lambda entry: (order.get(entry["role"], 99), entry["model"]))
    return results


def model_confidence(entry: dict) -> str:
    """How much weight a found component carries.

    A glyph the PDF itself declares is a fact; a shape tesseract guessed at once
    is a lead. Two independent OCR hits on the same model - which is what a
    calc sheet plus the bracing detail beside it produce - is as good as text.
    """
    if entry["sourceKind"] == "text":
        return "high"
    if entry["hits"] >= 2:
        return "high"
    return "medium"


def dominant_bracing_manufacturer(models: list[dict]) -> str:
    """Which maker the calc is written against.

    Plans mix makers by accident (an AFCON note left in a Tolco set), so the
    winner is the one with the most DISTINCT components, ties broken by total
    hits - never by first-seen, which just tracks page order.
    """
    tally: dict[str, list[int]] = {}
    for entry in models:
        slot = tally.setdefault(entry["manufacturer"], [0, 0])
        slot[0] += 1
        slot[1] += entry.get("hits", 1)
    if not tally:
        return ""
    return max(tally.items(), key=lambda item: (item[1][0], item[1][1]))[0]


def brace_member_from_text(text: str) -> str:
    """The brace PIPE a calc sheet calls for ("1\" Sch. 40"), or ""."""
    source = re.sub(r"\s+", " ", str(text or ""))
    match = re.search(
        r"\bbrace\s+member\b[^A-Za-z0-9]{0,12}"
        r"(\d(?:[-\s]?\d?/\d)?\s*(?:in\.?|\"|')?\s*Sch(?:edule)?\.?\s*\d{1,2})",
        source, re.IGNORECASE,
    )
    if match:
        return re.sub(r"\s+", " ", match.group(1)).strip()
    return ""
