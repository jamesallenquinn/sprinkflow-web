# -*- coding: utf-8 -*-
"""Unit-system separation (instruction #11). Every physical quantity carries its
unit and system; imperial and metric never mix silently — combining them raises
UnitSystemError, and conversion is only ever explicit."""
from __future__ import annotations

from dataclasses import dataclass

IMPERIAL = "imperial"
METRIC = "metric"


class UnitSystemError(ValueError):
    pass


@dataclass(frozen=True)
class Qty:
    value: float
    unit: str          # e.g. "lb", "lb/ft", "ft", "N", "kg/m", "m"
    system: str        # IMPERIAL or METRIC

    def __post_init__(self):
        if self.system not in (IMPERIAL, METRIC):
            raise UnitSystemError(f"unknown unit system {self.system!r}")

    def scaled(self, factor):
        return Qty(self.value * factor, self.unit, self.system)


def require_same_system(*qtys):
    systems = {q.system for q in qtys}
    if len(systems) > 1:
        raise UnitSystemError(
            "refusing to mix unit systems implicitly: " +
            ", ".join(f"{q.value} {q.unit} [{q.system}]" for q in qtys))
    return systems.pop()


def add(a: Qty, b: Qty) -> Qty:
    require_same_system(a, b)
    if a.unit != b.unit:
        raise UnitSystemError(f"cannot add {a.unit} to {b.unit}")
    return Qty(a.value + b.value, a.unit, a.system)


# Explicit conversions only (exact definitions).
_LB_PER_N = 0.2248089431
_FT_PER_M = 3.280839895


def n_to_lb(q: Qty) -> Qty:
    if q.system != METRIC or q.unit != "N":
        raise UnitSystemError(f"n_to_lb expects metric N, got {q.unit} [{q.system}]")
    return Qty(q.value * _LB_PER_N, "lb", IMPERIAL)


def lb_to_n(q: Qty) -> Qty:
    if q.system != IMPERIAL or q.unit != "lb":
        raise UnitSystemError(f"lb_to_n expects imperial lb, got {q.unit} [{q.system}]")
    return Qty(q.value / _LB_PER_N, "N", METRIC)


def m_to_ft(q: Qty) -> Qty:
    if q.system != METRIC or q.unit != "m":
        raise UnitSystemError(f"m_to_ft expects metric m, got {q.unit} [{q.system}]")
    return Qty(q.value * _FT_PER_M, "ft", IMPERIAL)


def ft_to_m(q: Qty) -> Qty:
    if q.system != IMPERIAL or q.unit != "ft":
        raise UnitSystemError(f"ft_to_m expects imperial ft, got {q.unit} [{q.system}]")
    return Qty(q.value / _FT_PER_M, "m", METRIC)
