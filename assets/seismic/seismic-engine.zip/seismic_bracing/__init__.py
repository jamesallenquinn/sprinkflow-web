# -*- coding: utf-8 -*-
"""SprinkFlow seismic bracing calculator engine (NFPA 13 (2025) Chapter 18).

Phase 1: engine machinery + versioned datasets + traceability. No normative
table values or prose-derived logic are fabricated; every unfilled authoritative
value is flagged SOURCE_DATA_REQUIRED with its exact NFPA identifier (see
docs/SEISMIC_BRACING_PLAN.md).

Importing this package registers every module's rules with the traceability
registry (seismic_bracing.traceability); docs/SEISMIC_TRACEABILITY.md is
generated from that registry joined against the pinned Chapter 18 index.
"""
ENGINE_VERSION = "0.1.0-phase1"
NFPA_EDITION = "2025"

from . import (  # noqa: F401  (import for side effect: rule registration)
    applicability,
    flexible_couplings,
    seismic_separation,
    clearance,
    brace_components,
    lateral_bracing,
    longitudinal_bracing,
    direction_changes,
    riser_bracing,
    seismic_demand,
    net_vertical,
    member_capacity,
    fastener_capacity,
    branch_restraint,
    hangers_seismic,
    pipe_stands,
    assembly,
    optimizer,
    editions,
)
