# -*- coding: utf-8 -*-
"""Brace-spacing auto-optimizer - the SprinkFlow differentiator.

Given the piping inventory for a stretch of main (however long), the selected
component assembly, and Cp, find the LARGEST brace spacing that passes every
constraint - replacing the designer's manual try-40ft / try-35ft loop in
TOLBrace.

Demand grows monotonically with spacing (more pipe in the zone of influence)
while capacities are constant, so the passing set is an interval: evaluate the
candidate spacings descending and return the first full PASS. Constraints whose
authoritative data is missing evaluate UNAVAILABLE: the optimizer still reports
the best spacing per the AVAILABLE constraints, but the result is explicitly
marked not code-complete with the pending NFPA identifiers listed
(instruction #10 - honesty over convenience)."""
from __future__ import annotations

from dataclasses import dataclass, field

from .assembly import FAIL, PASS, UNAVAILABLE, ConstraintResult
from .seismic_demand import ZoneOfInfluence, horizontal_seismic_force, zone_weight
from .traceability import rule
from .units import Qty

rule("SB-OPT-001", nfpa=["18.5.5.2", "18.5.9.5", "18.5.11.8", "18.5.12.2"], kind="output",
     title="Automatic optimal lateral-brace spacing search (composes the cited rule families; adds no normative content)",
     status="implemented",
     note="SprinkFlow feature, not an NFPA rule: monotone search over spacing with every constraint attributed to its rule/table.")
rule("SB-OPT-002", nfpa=["18.5.9.5"], kind="warning",
     title="Optimizer result marked not code-complete while any constraint is UNAVAILABLE",
     status="implemented")


@dataclass(frozen=True)
class StretchPipe:
    """One pipe classification within the stretch being braced."""
    label: str               # e.g. '4 in. Sch 10 main'
    weight_per_ft: Qty       # water-filled lb/ft
    total_length_ft: float   # total length of this classification in the stretch
    is_main: bool = False


@dataclass
class StretchInventory:
    """A stretch of main + everything hanging off it. ZOI content per brace is
    assumed proportional to spacing: each foot of main carries
    (total classification length / main length) feet of that classification -
    exactly the proportional scaling designers apply by hand in TOLBrace."""
    pipes: list
    concentrated_lb: float = 0.0

    def main_length_ft(self):
        return sum(p.total_length_ft for p in self.pipes if p.is_main)

    def zoi_for_spacing(self, spacing_ft: float) -> ZoneOfInfluence:
        main_len = self.main_length_ft()
        if main_len <= 0:
            raise ValueError("stretch has no main-run pipe")
        zoi = ZoneOfInfluence(concentrated_lb=self.concentrated_lb * (spacing_ft / main_len))
        for p in self.pipes:
            zoi.add(p.label, p.weight_per_ft, p.total_length_ft * (spacing_ft / main_len))
        return zoi


@dataclass
class OptimizeResult:
    spacing_ft: float | None          # best passing spacing (None = nothing passed)
    brace_count: int | None
    code_complete: bool               # False while any constraint UNAVAILABLE
    pending: tuple                    # NFPA identifiers still needing data
    governing: str                    # constraint that blocks the next-larger spacing
    evaluations: list = field(default_factory=list)   # (spacing, [ConstraintResult])


def optimize_lateral_spacing(inventory: StretchInventory, cp: float,
                             constraint_fns: list, candidate_spacings_ft: list,
                             allowance_factor: float | None = None) -> OptimizeResult:
    """constraint_fns: callables (spacing_ft, fpw: Qty) -> ConstraintResult.
    candidate_spacings_ft: the spacings to consider (e.g. table bucket edges).
    Returns the largest candidate whose available constraints all PASS."""
    candidates = sorted(set(candidate_spacings_ft), reverse=True)
    evaluations = []
    pending_all: set = set()
    best = None
    governing = ""
    for s in candidates:
        wp = zone_weight(inventory.zoi_for_spacing(s), allowance_factor=allowance_factor)
        fpw = horizontal_seismic_force(cp, wp)
        results = [fn(s, fpw) for fn in constraint_fns]
        evaluations.append((s, results))
        for r in results:
            pending_all.update(r.pending)
        failed = [r for r in results if r.status == FAIL]
        if failed:
            # candidates descend, so the last failure seen before the first pass
            # is the constraint blocking the next-larger spacing - that is the
            # governing constraint worth reporting to the designer.
            governing = f"{failed[0].name} at {s:g} ft" + (f" ({failed[0].detail})" if failed[0].detail else "")
            continue
        best = s
        break   # candidates descend; first full pass is the max
    if best is None:
        return OptimizeResult(None, None, not pending_all, tuple(sorted(pending_all)),
                              governing or "no candidate spacing passed", evaluations)
    main_len = inventory.main_length_ft()
    brace_count = max(1, -(-int(round(main_len)) // int(round(best))))   # ceil
    return OptimizeResult(best, brace_count, not pending_all,
                          tuple(sorted(pending_all)), governing, evaluations)
