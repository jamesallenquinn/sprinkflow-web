# -*- coding: utf-8 -*-
"""Seismic separation assemblies (18.3 cluster)."""
from .traceability import rule

rule("SB-SEP-001", nfpa=["18.3", "18.3.2", "18.3.4"], kind="checklist",
     title="Seismic separation assembly where piping crosses building seismic joints",
     status="report_only")
rule("SB-SEP-002", nfpa=["18.3.1"], kind="validation",
     title="Approved seismic separation assembly",
     status="condition_pending_prose",
     note="'approved' condition - AHJ acceptance recorded, not auto-passed.")
rule("SB-SEP-003", nfpa=["18.3.3"], kind="validation",
     title="Four-way bracing adjacent to the separation assembly",
     status="report_only")
