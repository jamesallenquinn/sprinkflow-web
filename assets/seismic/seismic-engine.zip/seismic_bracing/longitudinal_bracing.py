# -*- coding: utf-8 -*-
"""Longitudinal sway bracing (18.5.6 cluster). Same machinery as lateral; its
own spacing rule and zone of influence (18.5.9.7)."""
from .traceability import rule

rule("SB-LONG-001", nfpa=["18.5.6", "18.5.6.1", "18.5.6.3"], kind="validation",
     title="Longitudinal sway-brace spacing (80 ft / 24 m on center) and shared lateral/longitudinal braces",
     status="implemented",
     note="FILLED spacing_rules dataset (feed/cross mains 18.5.6.1); check_max_longitudinal_spacing in the lateral module; ZOI machinery shared.")
rule("SB-LONG-002", nfpa=["18.5.6.2"], kind="exception",
     title="Longitudinal bracing branch-line carve-out ('unless' condition)",
     status="condition_pending_prose")
rule("SB-LONG-003", nfpa=["18.5.6.4", "18.5.9.7"], kind="validation",
     title="Longitudinal zone-of-influence assignment incl. direction changes",
     status="report_only")
