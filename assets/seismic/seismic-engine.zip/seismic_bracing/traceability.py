# -*- coding: utf-8 -*-
"""Traceability registry: every rule, validation, input, output, formula, table
lookup, exception, and warning in the engine registers here with the NFPA
identifiers it implements. Tests assert (a) every cited identifier exists in the
pinned Chapter 18 index, (b) every index identifier receives a disposition, and
(c) no condition-carrying section is marked implemented without an explicit
condition resolution (instruction #4)."""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent.parent / "data" / "seismic_bracing"
INDEX_PATH = DATA_DIR / "nfpa13_2025" / "ch18_index.json"
INDEX_SHA256 = "91F1F2BC65AEF1B5EE7F620B2D00238E2798DFC31AE8B8F58CF967DD9BBB9BAE"

KINDS = {"input", "validation", "formula", "table_lookup", "exception",
         "warning", "output", "checklist"}
STATUSES = {"implemented", "source_data_required", "condition_pending_prose",
            "delegated", "report_only", "deferred"}


@dataclass(frozen=True)
class Rule:
    rule_id: str
    title: str
    nfpa_ids: tuple
    kind: str
    status: str
    module: str
    note: str = ""
    condition_resolution: str = ""   # required if status=implemented on a condition section


_RULES: dict = {}


def rule(rule_id, *, nfpa, kind, title, status, note="", condition_resolution="", module=None):
    if kind not in KINDS:
        raise ValueError(f"{rule_id}: unknown kind {kind!r}")
    if status not in STATUSES:
        raise ValueError(f"{rule_id}: unknown status {status!r}")
    if rule_id in _RULES:
        raise ValueError(f"duplicate rule id {rule_id}")
    import inspect
    mod = module or inspect.stack()[1].frame.f_globals.get("__name__", "?")
    r = Rule(rule_id, title, tuple(nfpa), kind, status, mod, note, condition_resolution)
    _RULES[rule_id] = r
    return r


def all_rules():
    return dict(_RULES)


# --- index access -----------------------------------------------------------

_INDEX_CACHE = None


def load_index():
    global _INDEX_CACHE
    if _INDEX_CACHE is None:
        _INDEX_CACHE = json.loads(INDEX_PATH.read_text(encoding="utf-8"))
    return _INDEX_CACHE


def index_identifiers():
    """Every citable identifier in the pinned index: section numbers, table ids
    ('Table 18.5.5.2(a)'), figure ('Figure 18.5.12.1'), equation
    ('Equation 18.5.9.6.2')."""
    idx = load_index()
    ids = {s["section"] for s in idx["sections"]}
    ids |= {"Table " + t["table"] for t in idx["tables"] if t.get("table")}
    ids |= {"Figure " + f["figure"] for f in idx["figures"]}
    ids |= {"Equation " + e["equation_label"] for e in idx["equations"]}
    return ids


def condition_sections():
    idx = load_index()
    out = {}
    for signal, secs in idx["condition_index"].items():
        for s in secs:
            out.setdefault(s, []).append(signal)
    return out


def delegated_sections():
    """Sections whose requirements are (at least partly) delegated to external
    standards, the AHJ, or a professional engineer."""
    idx = load_index()
    out = {}
    for e in idx["external_standards"]:
        for s in e["referenced_by_sections"]:
            out.setdefault(s, []).append(e["standard"])
    for s in idx["condition_index"].get("professional_engineer", []):
        out.setdefault(s, []).append("professional engineer")
    for s in idx["condition_index"].get("ahj", []):
        out.setdefault(s, []).append("AHJ")
    return out
