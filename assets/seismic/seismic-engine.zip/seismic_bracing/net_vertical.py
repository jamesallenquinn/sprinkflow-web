# -*- coding: utf-8 -*-
"""Net vertical forces (18.5.10).

The statics component - the vertical reaction a brace at angle theta from
vertical develops while resisting horizontal force Fpw - is implemented
(Fv = Fpw / tan(theta), pure statics, no normative wording involved). What the
standard requires you to DO with that force (combination and acceptance) is
surfaced as a report checklist item until backed by the normative prose."""
from __future__ import annotations

import math

from .traceability import rule
from .units import Qty

rule("SB-VERT-001", nfpa=["18.5.10"], kind="formula",
     title="Vertical component of brace reaction: Fv = Fpw / tan(angle from vertical)",
     status="implemented",
     note="Statics only. The normative combination/acceptance requirement is SB-VERT-002.")
rule("SB-VERT-002", nfpa=["18.5.10"], kind="validation",
     title="Net vertical-force combination and acceptance check",
     status="report_only",
     note="Surfaced as a report item (verify uplift path: hanger rod, surge restrainer, etc.) pending prose-backed logic.")


def brace_vertical_reaction(fpw: Qty, angle_from_vertical_deg: float) -> Qty:
    if not (0 < angle_from_vertical_deg < 90):
        raise ValueError("brace angle from vertical must be between 0 and 90 degrees exclusive")
    fv = fpw.value / math.tan(math.radians(angle_from_vertical_deg))
    return Qty(fv, fpw.unit, fpw.system)
