# -*- coding: utf-8 -*-
"""Brace component eligibility, listing, material, and design (18.5.1-18.5.4)."""
from .traceability import rule

rule("SB-COMP-001", nfpa=["18.5.1", "18.5.1.1", "18.5.1.2", "18.5.1.3", "18.5.1.4",
                          "18.5.1.4.1", "18.5.1.5"], kind="validation",
     title="Sway bracing general design requirements (resist Fpw in tension and compression; ZOI assignment)",
     status="report_only",
     note="Load-path requirements surface on the report; the quantitative checks live in the demand/capacity modules.")
rule("SB-COMP-002", nfpa=["18.5.2", "18.5.2.1", "18.5.2.2", "18.5.2.2.1", "18.5.2.3",
                          "18.5.2.3.1", "18.5.2.3.2"], kind="validation",
     title="Component listing requirements and listed-load angle adjustment",
     status="condition_pending_prose",
     note="Table 18.5.2.3 dataset is scaffolded (see SB-ASSY-003); listing conditions need prose.")
rule("SB-COMP-003", nfpa=["18.5.3", "18.5.3.1", "18.5.3.2"], kind="validation",
     title="Brace component material requirements",
     status="condition_pending_prose")
rule("SB-COMP-004", nfpa=["18.5.4", "18.5.4.1", "18.5.4.2", "18.5.4.3"], kind="validation",
     title="Sway bracing design basis (calculated loads vs listed assemblies)",
     status="condition_pending_prose")
