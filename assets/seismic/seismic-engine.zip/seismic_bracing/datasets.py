# -*- coding: utf-8 -*-
"""Versioned dataset layer with provenance (instruction #6, #10).

Every authoritative value the engine consumes lives in a JSON dataset under
data/seismic_bracing/. A dataset either carries real values WITH provenance, or
carries "status": "SOURCE_DATA_REQUIRED" plus the exact NFPA identifier and the
expected data shape. Loading a required-but-unfilled value raises
SourceDataRequired — there are no silent defaults anywhere in the engine.

CLI:
    python -m seismic_bracing.datasets --scaffold   # create table scaffolds from the pinned index
    python -m seismic_bracing.datasets --missing    # print the missing-data inventory
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from .traceability import DATA_DIR, load_index

NFPA_DIR = DATA_DIR / "nfpa13_2025"
TABLES_DIR = NFPA_DIR / "tables"
COMPONENTS_DIR = DATA_DIR / "components"

SOURCE_DATA_REQUIRED = "SOURCE_DATA_REQUIRED"

# Edition keys -> dataset directory. 2022 has one directory: the base files are
# the pre-TIA text and tia/ holds the TIA 22-8 overlay; "post" composes them.
EDITION_DIRS = {
    "2025": "nfpa13_2025",
    "2022-post-tia": "nfpa13_2022",
    "2022-pre-tia": "nfpa13_2022",
    "2019": "nfpa13_2019",
    "2016": "nfpa13_2016",
}
DEFAULT_EDITION = "2025"


class SourceDataRequired(Exception):
    """An authoritative value is needed and has not been supplied yet."""

    def __init__(self, identifier, expected_shape, dataset_path=None):
        self.identifier = identifier
        self.expected_shape = expected_shape
        self.dataset_path = str(dataset_path) if dataset_path else None
        super().__init__(f"{SOURCE_DATA_REQUIRED}: {identifier} ({expected_shape})")


class NotInEdition(Exception):
    """The requested canonical construct does not exist in the chosen edition
    (recorded in that edition's edition_mapping). This is a definitive answer,
    not missing data."""

    def __init__(self, identifier, edition, note=""):
        self.identifier = identifier
        self.edition = edition
        self.note = note
        super().__init__(f"{identifier} is not present in NFPA 13 ({edition})"
                         + (f": {note}" if note else ""))


def _check_edition(edition):
    if edition not in EDITION_DIRS:
        raise ValueError(f"unknown edition {edition!r}; choose from {sorted(EDITION_DIRS)}")
    return DATA_DIR / EDITION_DIRS[edition]


_MAPPING_CACHE = {}


def edition_mapping(edition):
    """canonical identifier -> mapping entry for a non-2025 edition ({} for 2025)."""
    if edition in _MAPPING_CACHE:
        return _MAPPING_CACHE[edition]
    base = _check_edition(edition)
    path = base / "edition_mapping.json"
    out = {}
    if edition != "2025" and path.exists():
        data = load_json(path)
        entries = data if isinstance(data, list) else (data.get("mappings") or data.get("entries") or [])
        out = {e["canonical"]: e for e in entries if e.get("canonical")}
    _MAPPING_CACHE[edition] = out
    return out


def _table_filename(table_id):
    return re.sub(r"[^0-9A-Za-z.]+", "_", table_id).strip("_") + ".json"


def table_path(table_id):
    return TABLES_DIR / _table_filename(table_id)


def load_json(path: Path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _write_json(path: Path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")


def _units_for_title(title):
    t = (title or "").lower()
    if "(lb)" in t or "(lb)," in t or " lb)" in t or "[ft" in t:
        return "imperial"
    if "(n)" in t or "(n)," in t or "[m" in t:
        return "metric"
    return "unspecified"


# --- scaffolding ------------------------------------------------------------

SPECIAL_SLOTS = {
    "cp_determination.json": {
        "identifier": "18.5.9.3",
        "expected_shape": "Mapping/formula from short-period spectral acceleration Ss to seismic coefficient Cp, including floor/ceiling and permitted-alternative rules (18.5.9.3.1-18.5.9.3.4).",
    },
    "equation_18_5_9_6_2.json": {
        "identifier": "Equation 18.5.9.6.2",
        "expected_shape": "Expression over variables Wp, Cp, Fy, Hr, S and its acceptance threshold for riser-nipple / branch-line screening.",
    },
    "figure_18_5_12_1_angle_categories.json": {
        "identifier": "Figure 18.5.12.1",
        "expected_shape": "Mapping (brace angle from vertical range x fastener orientation) -> fastener angle category, as designated by the figure.",
    },
    "zoi_allowance.json": {
        "identifier": "18.5.9.5",
        "expected_shape": "Factor applied to water-filled pipe weight when computing Wp for the zone of influence (and the conditions under which it applies).",
    },
    "spacing_rules.json": {
        "identifier": "18.5.5 / 18.5.6",
        "expected_shape": "Maximum lateral and longitudinal sway-brace spacing values and the conditions/permissions that modify them.",
    },
    "pipe_weights.json": {
        "identifier": "supports Wp (18.5.9.5)",
        "expected_shape": "Water-filled pipe weight per unit length by material, schedule/type, and nominal size; imperial (lb/ft) and metric (kg/m) kept separate.",
    },
    "brace_member_geometry.json": {
        "identifier": "supports Table 18.5.11.8 row selection",
        "expected_shape": "Least radius of gyration r (and section identity) for each brace member type/size, from dimensional standards.",
    },
}


def scaffold_from_index(force=False):
    """Create one dataset file per NFPA table (37) + the special slots, each
    marked SOURCE_DATA_REQUIRED. Never overwrites a filled dataset."""
    idx = load_index()
    created = []
    for t in idx["tables"]:
        tid = t.get("table")
        if not tid:
            continue
        path = table_path(tid)
        if path.exists() and not force:
            continue
        _write_json(path, {
            "dataset": f"nfpa13-2025-table-{tid}",
            "datasetVersion": "scaffold-2026-07-19",
            "status": SOURCE_DATA_REQUIRED,
            "identifier": f"Table {tid}",
            "title": t.get("title"),
            "parent_section": t.get("parent_section"),
            "units": _units_for_title(t.get("title")),
            "expected_shape": {
                "schema_headers": t.get("schema_headers"),
                "body_row_count": t.get("body_row_count"),
                "total_row_count": t.get("total_row_count"),
                "cell_matrix": "rows keyed by first schema column; one value per remaining column",
            },
            "provenance": {
                "document": "NFPA 13 (2025), authenticated NFPA LiNK view",
                "source_anchor": t.get("source_anchor"),
                "source_url": t.get("source_url"),
                "note": "Cell values must be filled from the licensed standard with per-cell anchors; index intentionally excludes them.",
            },
            "rows": [],
        })
        created.append(path.name)
    for fname, meta in SPECIAL_SLOTS.items():
        path = NFPA_DIR / fname if fname != "pipe_weights.json" and fname != "brace_member_geometry.json" else DATA_DIR / fname
        if path.exists() and not force:
            continue
        _write_json(path, {
            "dataset": fname.replace(".json", ""),
            "datasetVersion": "scaffold-2026-07-19",
            "status": SOURCE_DATA_REQUIRED,
            "identifier": meta["identifier"],
            "units": "n/a",
            "expected_shape": meta["expected_shape"],
            "provenance": {"note": "To be filled from the licensed NFPA 13 (2025) text or cited dimensional standards."},
        })
        created.append(path.name)
    return created


# --- lookup helpers for FILLED datasets -------------------------------------

_FRACTION_MAP = {"⁄": "/", "¼": "1/4", "½": "1/2", "¾": "3/4",
                 "⅓": "1/3", "⅛": "1/8", "⅜": "3/8", "⅝": "5/8",
                 "⅞": "7/8", "≤": "<=", "≥": ">=", "—": "-", "°": ""}


def canon_key(value):
    """Canonicalize a size/row/header key for matching: unicode fractions and
    comparison glyphs -> ascii, drop footnote stars, spaces, hyphens; case-fold.
    '11⁄4' == '1-1/4'; '2.0 < Pr ≤ 3.5' == '2.0 < Pr <= 3.5'."""
    s = str(value)
    for u, a in _FRACTION_MAP.items():
        s = s.replace(u, a)
    s = s.replace("*", "").replace("–", "-")
    return "".join(ch for ch in s if not ch.isspace()).replace("-", "").lower()


def find_row(table_data, key):
    """Find a table row whose key matches (canonically; also matches the first
    token of dual-unit keys like '1/2 (15)'). Degenerate-markup tables store
    their usable data in normalized lookup_rows - searched after rows, and
    preferred when the plain row carries no numeric values."""
    want = canon_key(key)

    def match(rows):
        for row in rows:
            rk = canon_key(row.get("key", ""))
            if rk == want or rk.split("(")[0] == want:
                return row
        return None

    plain = match(table_data.get("rows", []))
    if plain is not None and any(isinstance(v, (int, float))
                                 for v in plain.get("values", {}).values()):
        return plain
    normalized = match(table_data.get("lookup_rows", []))
    if normalized is not None:
        return normalized
    if plain is not None:
        return plain
    raise KeyError(f"row {key!r} not in {table_data.get('identifier')}; "
                   f"available: {[r.get('key') for r in table_data.get('rows', [])] or [r.get('key') for r in table_data.get('lookup_rows', [])]}")


_RANGE_PATTERNS = [
    re.compile(r"^>\s*([\d.]+)\s*and\s*≤\s*([\d.]+)$"),          # >20 and <=25
    re.compile(r"^([\d.]+)\s*<\s*\w+\s*≤\s*([\d.]+)$"),          # 0.5 < Cp <= 0.71
    re.compile(r"^≤\s*([\d.]+)$"),                                # <=20
    re.compile(r"^\w+\s*≤\s*([\d.]+)$"),                          # Cp <= 0.50
    re.compile(r"^\w+\s*>\s*([\d.]+)$"),                               # CP > 1.40
    re.compile(r"^>\s*([\d.]+)$"),                                     # >1.40
]


def header_range(header):
    """Parse a bucket header into (lo_exclusive, hi_inclusive); open ends are
    None. Returns None for non-range headers (labels, spanners)."""
    h = " ".join(str(header).split())
    for i, pat in enumerate(_RANGE_PATTERNS):
        m = pat.match(h)
        if not m:
            continue
        if i in (0, 1):
            return (float(m.group(1)), float(m.group(2)))
        if i in (2, 3):
            return (None, float(m.group(1)))
        return (float(m.group(1)), None)
    return None


def bucket_value(row, value):
    """Pick the row cell whose bucket-range header contains `value`.
    Falls back to bare-number column labels (older printings label spacing
    columns '20'/'25'/... meaning 'up to N') - the smallest label >= value
    governs. Returns (header, cell) or (None, None) when no bucket covers it."""
    for header, cell in row.get("values", {}).items():
        rng = header_range(header)
        if rng is None:
            continue
        lo, hi = rng
        if (lo is None or value > lo) and (hi is None or value <= hi):
            return header, cell
    numeric = []
    for header, cell in row.get("values", {}).items():
        h = str(header).strip()
        m = re.fullmatch(r"([\d.]+)[a-z]?", h)   # '20' or '20b' (printed footnote letter)
        if m:
            numeric.append((float(m.group(1)), header, cell))
    if numeric:
        numeric.sort()
        for bound, header, cell in numeric:
            if value <= bound:
                return header, cell
    return None, None


# --- loading ----------------------------------------------------------------

def _edition_table_id(table_id, edition):
    """Translate a canonical (2025) table id to the edition's own id, raising
    NotInEdition where the mapping says the construct does not exist."""
    mapping = edition_mapping(edition)
    entry = mapping.get(f"Table {table_id}") or mapping.get(table_id)
    if entry is None:
        return table_id            # no mapping entry -> same numbering
    this = str(entry.get("this_edition") or "")
    if "NOT_PRESENT" in this:
        raise NotInEdition(f"Table {table_id}", edition, entry.get("notes", ""))
    return this.replace("Table ", "").strip() or table_id


def load_table(table_id, edition=DEFAULT_EDITION):
    """Return the dataset dict for an NFPA table in the chosen edition.
    2022-post-tia composes base + tia/ overlay (override wins per file);
    2016 translates canonical ids through its edition mapping.
    Raises NotInEdition for constructs the edition does not have and
    SourceDataRequired for unfilled data.

    Manufacturer-engineered tables (id prefix 'MFR:') live outside the
    edition dirs in manufacturer_tables/ and are edition-independent -
    their provenance cites the manufacturer document, not NFPA."""
    if str(table_id).startswith("MFR:"):
        path = DATA_DIR / "manufacturer_tables" / (str(table_id)[4:] + ".json")
        if path.exists():
            data = load_json(path)
            if data.get("rows") or data.get("lookup_rows"):
                return data
        raise SourceDataRequired(f"Table {table_id}", "manufacturer table file missing", path)
    base = _check_edition(edition)
    native_id = _edition_table_id(table_id, edition)
    fname = _table_filename(native_id)
    candidates = []
    if edition == "2022-post-tia":
        candidates.append(base / "tia" / "tables" / fname)
    candidates.append(base / "tables" / fname)
    for path in candidates:
        if path.exists():
            data = load_json(path)
            if data.get("status") == SOURCE_DATA_REQUIRED or not (data.get("rows") or data.get("lookup_rows")):
                raise SourceDataRequired(f"Table {table_id} [{edition}]",
                                         json.dumps(data.get("expected_shape")), path)
            return data
    raise SourceDataRequired(f"Table {table_id} [{edition}]",
                             f"dataset file missing ({fname})", candidates[-1])


def load_slot(fname, edition=DEFAULT_EDITION):
    base = _check_edition(edition)
    candidates = []
    if edition == "2022-post-tia":
        candidates.append(base / "tia" / fname)
    candidates += [base / fname, DATA_DIR / fname]
    if edition == "2025":
        candidates.append(NFPA_DIR / fname)
    for path in candidates:
        if path.exists():
            data = load_json(path)
            if data.get("status") == SOURCE_DATA_REQUIRED:
                raise SourceDataRequired(data.get("identifier", fname), data.get("expected_shape", ""), path)
            if data.get("status") == "NOT_PRESENT_IN_EDITION":
                raise NotInEdition(data.get("identifier", fname), edition, str(data.get("notes", "")))
            return data
    raise SourceDataRequired(f"{fname} [{edition}]", "dataset file missing", candidates[0])


def load_component_dataset(manufacturer_key):
    """Load a manufacturer bracing-component dataset (tolco|caddy|afcon)."""
    path = COMPONENTS_DIR / f"{manufacturer_key}_bracing_loads.json"
    if not path.exists():
        raise SourceDataRequired(
            f"{manufacturer_key} component loads",
            "manufacturer dataset pending research extraction", path)
    data = load_json(path)
    if not data.get("components"):
        raise SourceDataRequired(f"{manufacturer_key} component loads", "empty dataset", path)
    return data


def missing_inventory():
    """Every dataset currently flagged SOURCE_DATA_REQUIRED (instruction #10)."""
    out = []
    paths = []
    if TABLES_DIR.exists():
        paths += sorted(TABLES_DIR.glob("*.json"))
    for fname in SPECIAL_SLOTS:
        for base in (DATA_DIR, NFPA_DIR):
            if (base / fname).exists():
                paths.append(base / fname)
                break
        else:
            out.append({"identifier": SPECIAL_SLOTS[fname]["identifier"],
                        "expected_shape": SPECIAL_SLOTS[fname]["expected_shape"],
                        "path": str((NFPA_DIR / fname)), "state": "file missing (run --scaffold)"})
    for p in paths:
        d = load_json(p)
        if d.get("status") == SOURCE_DATA_REQUIRED:
            out.append({"identifier": d.get("identifier"),
                        "expected_shape": d.get("expected_shape"),
                        "path": str(p), "state": SOURCE_DATA_REQUIRED})
    for key in ("tolco", "caddy", "afcon"):
        p = COMPONENTS_DIR / f"{key}_bracing_loads.json"
        if not p.exists():
            out.append({"identifier": f"{key} component loads", "expected_shape":
                        "manufacturer rated-load dataset", "path": str(p),
                        "state": "pending research extraction"})
    return out


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--scaffold", action="store_true")
    ap.add_argument("--missing", action="store_true")
    args = ap.parse_args()
    if args.scaffold:
        created = scaffold_from_index()
        print(f"created {len(created)} dataset scaffolds")
    if args.missing:
        inv = missing_inventory()
        print(f"{len(inv)} SOURCE_DATA_REQUIRED items:")
        for item in inv:
            print(f"  - {item['identifier']}: {item['state']}")
