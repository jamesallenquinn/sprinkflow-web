# -*- coding: utf-8 -*-
"""Pipe with changes in direction (18.5.7 + 18.5.5.6)."""
from .traceability import rule

rule("SB-DIR-001", nfpa=["18.5.7", "18.5.7.1"], kind="validation",
     title="Bracing at changes in direction ('unless' condition on 18.5.7.1)",
     status="condition_pending_prose")
rule("SB-DIR-002", nfpa=["18.5.7.2"], kind="exception",
     title="Permitted direction-change alternative",
     status="condition_pending_prose")
