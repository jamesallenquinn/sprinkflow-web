# -*- coding: utf-8 -*-
"""Lateral sway bracing (18.5.5 cluster): spacing rules, zone of influence, and
the Table 18.5.5.2(a)-(n) maximum-Fpw-in-ZOI limit for the braced pipe.

Implemented machinery: spacing-bucket resolution against the table schema
(<=20 / >20-25 / >25-30 / >30-35 / >35-40 ft, exactly the published column
structure recorded in the index) and the constraint wrapper. Cell values and
the maximum-spacing rule remain dataset-backed (SOURCE_DATA_REQUIRED)."""
from __future__ import annotations

from .assembly import FAIL, PASS, UNAVAILABLE, ConstraintResult
from .datasets import SourceDataRequired, load_slot, load_table
from .traceability import rule
from .units import Qty

# Column buckets exactly as published in the Table 18.5.5.2 schema headers.
SPACING_BUCKETS_FT = ((0, 20), (20, 25), (25, 30), (30, 35), (35, 40))

rule("SB-LAT-001", nfpa=["18.5.5.2"], kind="formula",
     title="Lateral spacing bucketed to the published Table 18.5.5.2 column structure",
     status="implemented",
     note="Buckets read from the index schema headers; a spacing above the last bucket is beyond table coverage.")
rule("SB-LAT-002",
     nfpa=["Table 18.5.5.2(a)", "Table 18.5.5.2(b)", "Table 18.5.5.2(c)", "Table 18.5.5.2(d)",
           "Table 18.5.5.2(e)", "Table 18.5.5.2(f)", "Table 18.5.5.2(g)", "Table 18.5.5.2(h)",
           "Table 18.5.5.2(i)", "Table 18.5.5.2(j)", "Table 18.5.5.2(k)", "Table 18.5.5.2(l)",
           "Table 18.5.5.2(m)", "Table 18.5.5.2(n)"],
     kind="table_lookup",
     title="Maximum Fpw in zone of influence for the braced pipe (by material/schedule, size, spacing bucket)",
     status="implemented",
     note="Datasets FILLED from the authenticated LiNK extraction; published em dashes resolve as no-permitted-value (FAIL).")
rule("SB-LAT-003", nfpa=["18.5.5.2.2", "18.5.5.3", "18.5.5.5"], kind="validation",
     title="Maximum lateral sway-brace spacing rule (40 ft / 12 m on center)",
     status="implemented",
     condition_resolution="18.5.5.3's 'listed' condition (specially listed pipe uses a calculated "
                          "Fpw per Annex E instead of the tables) is surfaced as an explicit user "
                          "choice on the report and never auto-selected; the 40 ft maximum "
                          "(18.5.5.2.2) is enforced unconditionally per the dataset.",
     note="Value from the FILLED spacing_rules dataset (18.5.5.2.2).")
rule("SB-LAT-004", nfpa=["18.5.5.1", "18.5.5.1.1", "18.5.5.7", "18.5.5.8", "18.5.5.9"],
     kind="checklist", title="Lateral brace applicability/placement requirements",
     status="report_only")
rule("SB-LAT-005", nfpa=["18.5.5.4"], kind="exception",
     title="Lateral bracing not-apply carve-out", status="condition_pending_prose",
     note="shall_not_apply per condition_index; requires prose to adjudicate.")
rule("SB-LAT-006", nfpa=["18.5.5.6", "18.5.5.10", "18.5.5.10.1", "18.5.5.10.2",
                         "18.5.5.10.3", "18.5.5.11", "18.5.5.11.1", "18.5.5.11.2", "18.5.5.2.1"],
     kind="exception", title="Permitted lateral-bracing alternatives (wraparound U-hooks etc.)",
     status="condition_pending_prose")


def spacing_bucket(spacing_ft: float):
    """Return the published column bucket containing this spacing, or None when
    beyond the table's last bucket."""
    if spacing_ft <= 0:
        raise ValueError("spacing must be positive")
    for lo, hi in SPACING_BUCKETS_FT:
        if lo < spacing_ft <= hi:
            return (lo, hi)
    return None


def check_braced_pipe_stress(fpw: Qty, table_id: str, pipe_size: str,
                             spacing_ft: float, edition: str = "2025") -> ConstraintResult:
    """Compare Fpw against the Table 18.5.5.2 maximum for the braced pipe,
    per the chosen edition's dataset."""
    from .datasets import NotInEdition, bucket_value, find_row
    refs = (f"Table {table_id}",)
    if spacing_bucket(spacing_ft) is None:
        return ConstraintResult(
            "braced pipe ZOI stress", FAIL, refs, fpw, None,
            detail=f"lateral spacing {spacing_ft:.1f} ft exceeds the published "
                   f"column coverage (max {SPACING_BUCKETS_FT[-1][1]} ft); no extrapolation")
    try:
        table = load_table(table_id, edition=edition)
    except NotInEdition as exc:
        return ConstraintResult(
            "braced pipe ZOI stress", FAIL, refs, fpw, None,
            detail=f"not present in NFPA 13 ({edition}): {exc.note or 'per edition mapping'} - "
                   "choose a piping/table combination this edition covers")
    except SourceDataRequired as exc:
        return ConstraintResult(
            "braced pipe ZOI stress", UNAVAILABLE, refs, fpw, None,
            detail=f"pipe {pipe_size}, spacing {spacing_ft:.1f} ft", pending=(exc.identifier,))
    row = find_row(table, pipe_size)
    header, cell = bucket_value(row, spacing_ft)
    if header is None:
        return ConstraintResult("braced pipe ZOI stress", FAIL, refs, fpw, None,
                                detail=f"no published spacing column covers {spacing_ft:.1f} ft")
    if cell is None:
        return ConstraintResult(
            "braced pipe ZOI stress", FAIL, refs, fpw, None,
            governing=f"{pipe_size} @ {header} ft",
            detail="published as em dash - no permitted value for this size/spacing "
                   + ("; ".join(row.get("footnotes", [])) or ""))
    cap = Qty(float(cell), "lb", fpw.system)
    ok = fpw.value <= cap.value
    return ConstraintResult(
        "braced pipe ZOI stress", PASS if ok else FAIL, refs, fpw, cap,
        governing=f"{table['identifier']} row {row['key']} col {header}",
        detail=f"max Fpw {cap.value:.0f} lb vs demand {fpw.value:.0f} lb "
               f"({table['identifier']}, anchor {row.get('source_anchor')})")


def check_max_spacing(spacing_ft: float, edition: str = "2025") -> ConstraintResult:
    """Maximum lateral sway-brace spacing (18.5.5.2.2 via the edition's spacing_rules)."""
    try:
        rules_data = load_slot("spacing_rules.json", edition=edition)
    except SourceDataRequired as exc:
        return ConstraintResult("lateral max spacing", UNAVAILABLE, ("18.5.5.2.2",),
                                None, None, detail=f"spacing {spacing_ft:.1f} ft",
                                pending=(exc.identifier,))
    max_info = rules_data["lateral"]["maximum_spacing"]
    max_ft = float(max_info["ft"])
    ok = spacing_ft <= max_ft
    return ConstraintResult(
        "lateral max spacing", PASS if ok else FAIL, (max_info.get("section", "18.5.5.2.2"),),
        None, Qty(max_ft, "ft", "imperial"),
        detail=f"spacing {spacing_ft:.1f} ft vs maximum {max_ft:.0f} ft "
               f"{max_info.get('basis', '')} (anchor {max_info.get('source_anchor')})")


def check_max_longitudinal_spacing(spacing_ft: float, edition: str = "2025") -> ConstraintResult:
    """Maximum longitudinal sway-brace spacing via the edition's spacing_rules."""
    try:
        rules_data = load_slot("spacing_rules.json", edition=edition)
    except SourceDataRequired as exc:
        return ConstraintResult("longitudinal max spacing", UNAVAILABLE, ("18.5.6.1",),
                                None, None, pending=(exc.identifier,))
    long_info = rules_data.get("longitudinal", {}).get("feed_and_cross_mains")
    if not long_info:
        return ConstraintResult("longitudinal max spacing", UNAVAILABLE, ("18.5.6.1",),
                                None, None, pending=("18.5.6.1 (not in spacing_rules dataset)",))
    max_ft = float(long_info["maximum_spacing_ft"])
    ok = spacing_ft <= max_ft
    return ConstraintResult(
        "longitudinal max spacing", PASS if ok else FAIL, (long_info.get("section", "18.5.6.1"),),
        None, Qty(max_ft, "ft", "imperial"),
        detail=f"spacing {spacing_ft:.1f} ft vs maximum {max_ft:.0f} ft (anchor {long_info.get('source_anchor')})")
