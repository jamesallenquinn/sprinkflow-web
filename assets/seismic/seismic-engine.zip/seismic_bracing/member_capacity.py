# -*- coding: utf-8 -*-
"""Brace member capacity (18.5.11 cluster).

Implemented machinery: slenderness ratio l/r, banding to the table families'
l/r = 100/200/300 columns (always rounding UP to the next published band - a
member at l/r 147 is checked against the 200 table), and refusal beyond table
coverage. The actual maximum-horizontal-load values are Table 18.5.11.8(a)-(f)
datasets (SOURCE_DATA_REQUIRED until filled). Member least-radius r comes from
the brace_member_geometry dataset or explicit user entry."""
from __future__ import annotations

import re

from .assembly import FAIL, PASS, UNAVAILABLE, ConstraintResult
from .datasets import SourceDataRequired, load_slot, load_table
from .traceability import rule
from .units import Qty

LR_BANDS = (100, 200, 300)

rule("SB-MEMBER-001", nfpa=["18.5.11.8"], kind="formula",
     title="Slenderness ratio l/r and banding to the published l/r 100/200/300 columns (round up)",
     status="implemented")
rule("SB-MEMBER-002",
     nfpa=["Table 18.5.11.8(a)", "Table 18.5.11.8(b)", "Table 18.5.11.8(c)",
           "Table 18.5.11.8(d)", "Table 18.5.11.8(e)", "Table 18.5.11.8(f)"],
     kind="table_lookup", title="Maximum horizontal load for sway brace member by shape/size and l/r band",
     status="implemented",
     note="FILLED datasets. (a)-(c) imperial Fy=36 ksi at l/r 100/200/300; (d)-(f) their metric twins - never mixed. Member selected by max-length-for-band, load by brace-angle column.")
rule("SB-MEMBER-003", nfpa=["18.5.11.8"], kind="validation",
     title="Member beyond published l/r coverage (> 300) is rejected, not extrapolated",
     status="implemented")
rule("SB-MEMBER-004", nfpa=["18.5.11.9", "18.5.11.9.1"], kind="exception",
     title="PE-certified alternative brace members (AHJ-reviewed)",
     status="delegated")
rule("SB-MEMBER-005", nfpa=["18.5.11.1", "18.5.11.2", "18.5.11.3", "18.5.11.4",
                            "18.5.11.5", "18.5.11.6", "18.5.11.7", "18.5.11.10", "18.5.11.11"],
     kind="checklist", title="Brace installation/placement geometry requirements",
     status="report_only",
     note="Surfaced as installer checklist items on the report; several carry unless/listed conditions pending prose.")
rule("SB-MEMBER-006", nfpa=["18.5.11.8"],
     kind="input", title="Member least radius of gyration r (from the FILLED table rows / geometry dataset)",
     status="implemented",
     note="r comes from the published table rows themselves (138 records mirrored to brace_member_geometry.json); printed rounding preserved.")


def slenderness(length_in: float, r_in: float) -> float:
    if length_in <= 0 or r_in <= 0:
        raise ValueError("length and radius of gyration must be positive")
    return length_in / r_in


def lr_band(lr: float):
    """Round UP to the next published l/r column; None when beyond coverage."""
    for band in LR_BANDS:
        if lr <= band:
            return band
    return None


# Imperial band tables: (a)=l/r 100, (b)=200, (c)=300 (Fy 36 ksi).
# (d)-(f) are the metric twins - resolved separately, never mixed.
_IMPERIAL_BAND_TABLES = {100: "18.5.11.8(a)", 200: "18.5.11.8(b)", 300: "18.5.11.8(c)"}

_ANGLE_RE = re.compile(r"(\d+)\s*°\s*to\s*(\d+)\s*°")


def _member_row(table, member_category, member_size):
    from .datasets import canon_key
    want = canon_key(f"{member_category}|{member_size}")
    for row in table.get("rows", []):
        if canon_key(row.get("key", "")) == want:
            return row
    raise KeyError(f"member {member_category!r} {member_size!r} not in {table.get('identifier')}")


def _row_max_length_in(row):
    ft = row["values"].get("ft")
    inch = row["values"].get("in.")
    if ft is None and inch is None:
        return None
    return float(ft or 0) * 12.0 + float(inch or 0)


def _row_angle_load(row, angle_from_vertical_deg):
    for header, cell in row["values"].items():
        m = _ANGLE_RE.search(str(header))
        if m and float(m.group(1)) <= angle_from_vertical_deg <= float(m.group(2)):
            return header, cell
    return None, None


def member_radius(member_category: str, member_size: str, edition: str = "2025") -> float:
    """Least radius of gyration r (in.) as published in the l/r=100 table row."""
    table = load_table(_IMPERIAL_BAND_TABLES[100], edition=edition)
    row = _member_row(table, member_category, member_size)
    r = row["values"].get("Least Radius of Gyration (r) (in.)")
    if r is None:
        raise KeyError(f"no published r for {member_category} {member_size}")
    return float(r)


def check_member(demand: Qty, member_category: str, member_size: str,
                 length_in: float, angle_from_vertical_deg: float,
                 edition: str = "2025") -> ConstraintResult:
    """Check a brace member per the published method: find the smallest l/r band
    whose maximum length covers the actual brace length, then compare the demand
    to that band's load for the brace-angle column. Beyond the l/r=300 length =
    FAIL (no extrapolation)."""
    from .datasets import NotInEdition
    desc = f"{member_category} {member_size}"
    pending = []
    for band in LR_BANDS:
        table_id = _IMPERIAL_BAND_TABLES[band]
        try:
            table = load_table(table_id, edition=edition)
        except NotInEdition as exc:
            return ConstraintResult(
                "brace member capacity", FAIL, (f"Table {table_id}",), demand, None,
                governing=desc, detail=f"not present in NFPA 13 ({edition}): {exc.note or 'per edition mapping'}")
        except SourceDataRequired as exc:
            pending.append(exc.identifier)
            continue
        row = _member_row(table, member_category, member_size)
        max_len = _row_max_length_in(row)
        if max_len is None or length_in > max_len:
            continue   # too long for this band - try the next
        header, cell = _row_angle_load(row, angle_from_vertical_deg)
        if header is None:
            return ConstraintResult(
                "brace member capacity", FAIL, (f"Table {table_id}",), demand, None,
                governing=desc,
                detail=f"brace angle {angle_from_vertical_deg:.0f} deg from vertical is "
                       "outside the published 30-90 deg columns")
        if cell is None:
            return ConstraintResult(
                "brace member capacity", FAIL, (f"Table {table_id}",), demand, None,
                governing=desc, detail=f"published as em dash for {desc} @ {header}")
        r = row["values"].get("Least Radius of Gyration (r) (in.)")
        cap = Qty(float(cell), "lb", demand.system)
        ok = demand.value <= cap.value
        lr_txt = f"l/r band {band}" + (f" (r = {r} in., actual l/r = {length_in / float(r):.0f})" if r else "")
        return ConstraintResult(
            "brace member capacity", PASS if ok else FAIL, (f"Table {table_id}",),
            demand, cap, governing=desc,
            detail=f"max load {cap.value:.0f} lb @ {header} for {desc}, {lr_txt}, "
                   f"length {length_in:.0f} in. <= max {max_len:.0f} in. "
                   f"(anchor {row.get('source_anchor')})")
    if pending:
        return ConstraintResult("brace member capacity", UNAVAILABLE,
                                tuple(f"Table {t}" for t in _IMPERIAL_BAND_TABLES.values()),
                                demand, None, governing=desc, pending=tuple(pending))
    return ConstraintResult(
        "brace member capacity", FAIL, (f"Table {_IMPERIAL_BAND_TABLES[300]}",), demand, None,
        governing=desc,
        detail=f"length {length_in:.0f} in. exceeds the l/r = 300 maximum for {desc}; "
               "no extrapolation - choose a stiffer/shorter member")
