# -*- coding: utf-8 -*-
"""Flexible couplings (18.2 cluster) - detailing/differential-movement checklist."""
from .traceability import rule

rule("SB-FLEX-001", nfpa=["18.2", "18.2.1", "18.2.3", "18.2.5"], kind="checklist",
     title="Flexible couplings at required locations (risers, mains, drops)",
     status="report_only",
     note="Location list requires the normative prose; surfaced as report checklist.")
rule("SB-FLEX-002", nfpa=["18.2.2"], kind="validation",
     title="Listed flexible coupling / permitted alternatives",
     status="condition_pending_prose")
rule("SB-FLEX-003", nfpa=["18.2.4", "18.2.4.1", "18.2.4.2"], kind="validation",
     title="Riser flexible-coupling placement and its not-required carve-outs",
     status="condition_pending_prose")
