# -*- coding: utf-8 -*-
"""Sway bracing of risers (18.5.8) - four-way brace logic."""
from .traceability import rule

rule("SB-RISER-001", nfpa=["18.5.8", "18.5.8.1", "18.5.8.3", "18.5.8.4"], kind="validation",
     title="Four-way bracing of risers (placement and load assignment)",
     status="report_only",
     note="Quantitative demand/capacity run through the shared modules; placement rules surface on the report.")
rule("SB-RISER-002", nfpa=["18.5.8.1.1", "18.5.8.2", "18.5.8.5"], kind="exception",
     title="Riser bracing not-required / permitted carve-outs",
     status="condition_pending_prose")
