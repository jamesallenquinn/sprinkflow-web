# -*- coding: utf-8 -*-
"""Penetration clearance (18.4 cluster)."""
from .traceability import rule

rule("SB-CLR-001", nfpa=["18.4", "18.4.1", "18.4.3", "18.4.6", "18.4.8", "18.4.9",
                         "18.4.11", "18.4.13"], kind="validation",
     title="Clearance around piping penetrating walls/floors/platforms/foundations",
     status="report_only",
     note="Required annular clearance dimensions live in prose - surfaced as checklist with a SOURCE_DATA_REQUIRED dimension slot.")
rule("SB-CLR-002", nfpa=["18.4.2", "18.4.10", "18.4.11.1", "18.4.12", "18.4.13.1"],
     kind="exception", title="Clearance not-required / permitted-alternative carve-outs",
     status="condition_pending_prose")
rule("SB-CLR-003", nfpa=["18.4.4", "18.4.5", "18.4.7"], kind="checklist",
     title="Frangible/breakaway fill and flexible-coupling alternatives at penetrations",
     status="report_only")
