# -*- coding: utf-8 -*-
"""Restraint of branch lines (18.6 cluster) + Tables 18.6.4(a)/(b)."""
from __future__ import annotations

from .assembly import FAIL, PASS, UNAVAILABLE, ConstraintResult
from .datasets import SourceDataRequired, load_table
from .traceability import rule

rule("SB-REST-001", nfpa=["Table 18.6.4(a)", "Table 18.6.4(b)", "18.6.4"], kind="table_lookup",
     title="Maximum branch-line restraint spacing by pipe size and seismic coefficient",
     status="implemented",
     note="FILLED datasets; spacing bucketed by the published Cp column ranges.")
rule("SB-REST-002", nfpa=["18.6", "18.6.1", "18.6.2", "18.6.2.1", "18.6.2.2",
                          "18.6.3", "18.6.3.1", "18.6.6", "18.6.7"], kind="validation",
     title="Restraint methods (wire restraint, hangers as restraint, end-of-line, drops)",
     status="condition_pending_prose",
     note="18.6.1 carries approved/listed conditions; method eligibility needs prose.")
rule("SB-REST-003", nfpa=["18.6.5"], kind="exception",
     title="Branch-line restraint not-required carve-out",
     status="condition_pending_prose")


def check_restraint_spacing(table_id: str, pipe_size: str, seismic_coefficient: float,
                            spacing_ft: float, edition: str = "2025") -> ConstraintResult:
    """Restraint spacing vs the Table 18.6.4 maximum for the pipe size at Cp."""
    from .datasets import NotInEdition, bucket_value, find_row
    refs = (f"Table {table_id}",)
    try:
        table = load_table(table_id, edition=edition)
    except NotInEdition as exc:
        return ConstraintResult("branch-line restraint spacing", FAIL, refs, None, None,
                                detail=f"not present in NFPA 13 ({edition}): {exc.note or 'per edition mapping'}")
    except SourceDataRequired as exc:
        return ConstraintResult("branch-line restraint spacing", UNAVAILABLE, refs,
                                None, None,
                                detail=f"{pipe_size} at Cp {seismic_coefficient}, spacing {spacing_ft:.1f} ft",
                                pending=(exc.identifier,))
    row = find_row(table, pipe_size)
    header, cell = bucket_value(row, seismic_coefficient)
    if header is None or cell is None:
        return ConstraintResult(
            "branch-line restraint spacing", FAIL, refs, None, None,
            detail=f"no published Cp column covers Cp = {seismic_coefficient}"
                   if header is None else "published as em dash for this size/Cp")
    from .units import IMPERIAL, Qty
    cap = Qty(float(cell), "ft", IMPERIAL)
    ok = spacing_ft <= cap.value
    return ConstraintResult(
        "branch-line restraint spacing", PASS if ok else FAIL, refs, None, cap,
        governing=f"{row['key']} @ {header}",
        detail=f"max restraint spacing {cap.value:.0f} ft vs {spacing_ft:.1f} ft "
               f"(anchor {row.get('source_anchor')})")
