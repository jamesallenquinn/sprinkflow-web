# -*- coding: utf-8 -*-
"""Fastener and anchor capacity (18.5.12 cluster).

The angle-category selection depends on Figure 18.5.12.1 (instruction #7) - a
dataset encoding of the figure is required before any fastener table lookup can
resolve, because the category picks the table column. All 14 Table 18.5.12.2
datasets are scaffolded SOURCE_DATA_REQUIRED. Concrete-anchor prequalification
is delegated (ACI 355.2 / ACI 318 / ICC-ES AC446 per the index)."""
from __future__ import annotations

from .assembly import FAIL, PASS, UNAVAILABLE, ConstraintResult
from .datasets import SourceDataRequired, load_slot, load_table
from .traceability import rule
from .units import Qty

rule("SB-FAST-001", nfpa=["Figure 18.5.12.1", "18.5.12.1"], kind="table_lookup",
     title="Fastener angle-category designation from brace angle + fastener orientation",
     status="implemented",
     note="FILLED figure dataset gates every fastener table lookup (instruction #7); ambiguous orientation input raises with the published options listed.")
rule("SB-FAST-002",
     nfpa=["Table 18.5.12.2(a)", "Table 18.5.12.2(b)", "Table 18.5.12.2(c)", "Table 18.5.12.2(d)",
           "Table 18.5.12.2(e)", "Table 18.5.12.2(f)", "Table 18.5.12.2(g)", "Table 18.5.12.2(h)",
           "Table 18.5.12.2(i)", "Table 18.5.12.2(j)", "Table 18.5.12.2(k)", "Table 18.5.12.2(l)",
           "Table 18.5.12.2(m)", "Table 18.5.12.2(n)"],
     kind="table_lookup",
     title="Maximum fastener/anchor loads (wedge anchors, inserts, steel bolts, wood fasteners, specific-gravity factors)",
     status="implemented",
     note="FILLED datasets; capacity by angle-category column, published em dashes FAIL, prying-factor columns preserved for the report.")
rule("SB-FAST-003", nfpa=["18.5.12.2"], kind="exception",
     title="PE-designed fastener alternatives to the prescriptive tables",
     status="delegated")
rule("SB-FAST-004", nfpa=["18.5.12.3", "18.5.12.4", "18.5.12.5", "18.5.12.6",
                          "18.5.12.6.1", "18.5.12.6.2"], kind="validation",
     title="Fastener eligibility conditions (listed devices, wood detailing, powder-driven/welded studs)",
     status="condition_pending_prose")
rule("SB-FAST-005", nfpa=["18.5.12.7", "18.5.12.7.1", "18.5.12.7.2", "18.5.12.7.2.1",
                          "18.5.12.7.2.2", "18.5.12.7.3", "18.5.12.7.3.1", "18.5.12.7.3.2",
                          "18.5.12.7.3.3", "18.5.12.7.3.4", "18.5.12.7.4", "18.5.12.7.5"],
     kind="validation", title="Concrete anchor qualification, embedment, and edge/angle conditions",
     status="delegated",
     note="ACI 355.2 / ACI 318 / ICC-ES AC446 prequalification + prose conditions; anchor capacities themselves are the Table 18.5.12.2 datasets.")


import re as _re

_ANGLE_RANGE_RE = _re.compile(r"(\d+)\s*°\s*to\s*(\d+)\s*°")

# User-facing orientation keys -> phrases that identify the published category
# descriptions in the figure dataset. The UI will present the figure's own
# descriptions; these keys are for programmatic callers.
ORIENTATION_PHRASES = {
    "horizontal": "normal to a horizontal structural member",
    "vertical-perpendicular": "load perpendicular",
    "vertical-parallel": "load parallel",
}


def angle_category(brace_angle_from_vertical_deg: float, fastener_orientation: str,
                   edition: str = "2025") -> str:
    """Resolve the Figure 18.5.12.1 angle category letter from the brace angle
    and fastener orientation (an ORIENTATION_PHRASES key or a phrase that
    matches exactly one published description)."""
    fig = load_slot("figure_18_5_12_1_angle_categories.json", edition=edition)
    phrase = ORIENTATION_PHRASES.get(fastener_orientation, fastener_orientation).lower()
    matches = []
    for cat in fig["categories"]:
        desc = str(cat.get("fastener_orientation", "")).lower()
        if phrase not in desc:
            continue
        m = _ANGLE_RANGE_RE.search(str(cat.get("brace_angle_from_vertical", "")))
        if m and float(m.group(1)) <= brace_angle_from_vertical_deg <= float(m.group(2)):
            matches.append(cat["category"])
    if len(matches) == 1:
        return matches[0]
    if not matches:
        raise ValueError(
            f"no Figure 18.5.12.1 category matches orientation {fastener_orientation!r} at "
            f"{brace_angle_from_vertical_deg:.0f} deg; published orientations: "
            + "; ".join(sorted({c['fastener_orientation'] for c in fig['categories']})))
    raise ValueError(f"orientation {fastener_orientation!r} is ambiguous at "
                     f"{brace_angle_from_vertical_deg:.0f} deg: categories {matches}")


_PR_BAND_RE = _re.compile(r"<\s*Pr\s*(?:≤|<=)|^Pr\s*(?:≤|<=)")


def pr_bands(table) -> list:
    """Split a fastener table into prying-factor bands.

    The concrete-anchor tables (18.5.12.2(a)-(j)) repeat the same diameter
    rows once per Pr band, separated by band-header rows like
    '2.0 < Pr ≤ 3.5'; the leading block is the implicit lowest band. Returns
    [(band_label, rows)] - a single (None, rows) entry when the table has no
    bands (steel/wood tables).
    """
    rows = table.get("lookup_rows") or table.get("rows") or []
    headers = [(i, str(r.get("key", ""))) for i, r in enumerate(rows)
               if _PR_BAND_RE.search(str(r.get("key", "")))]
    if not headers:
        return [(None, rows)]
    first_label = None
    m = _re.match(r"\s*([\d.]+)\s*<\s*Pr", headers[0][1])
    if m:
        first_label = f"Pr ≤ {m.group(1)}"
    bands = [(first_label or "lowest Pr band", rows[:headers[0][0]])]
    for n, (idx, label) in enumerate(headers):
        end = headers[n + 1][0] if n + 1 < len(headers) else len(rows)
        bands.append((label.strip(), rows[idx + 1:end]))
    return bands


def check_fastener(demand: Qty, table_id: str, fastener_size: str,
                   brace_angle_from_vertical_deg: float,
                   fastener_orientation: str, edition: str = "2025",
                   pr_band: int = 0) -> ConstraintResult:
    """Fastener capacity check: angle category (Figure 18.5.12.1) -> table
    column -> capacity vs demand. pr_band selects the prying-factor block
    in the concrete-anchor tables (0 = lowest Pr, the leading block)."""
    from .datasets import NotInEdition, find_row
    refs = (f"Table {table_id}", "Figure 18.5.12.1")
    pending = []
    category = None
    try:
        category = angle_category(brace_angle_from_vertical_deg, fastener_orientation, edition=edition)
    except SourceDataRequired as exc:
        pending.append(exc.identifier)
    try:
        table = load_table(table_id, edition=edition)
    except NotInEdition as exc:
        return ConstraintResult("fastener capacity", FAIL, refs, demand, None,
                                governing=fastener_size,
                                detail=f"not present in NFPA 13 ({edition}): {exc.note or 'per edition mapping'}")
    except SourceDataRequired as exc:
        pending.append(exc.identifier)
    if pending:
        return ConstraintResult("fastener capacity", UNAVAILABLE, refs, demand, None,
                                governing=fastener_size, pending=tuple(pending))
    bands = pr_bands(table)
    band_idx = min(max(int(pr_band or 0), 0), len(bands) - 1)
    band_label, band_rows = bands[band_idx]
    sub = dict(table)
    sub.pop("rows", None)
    sub["lookup_rows"] = band_rows
    row = find_row(sub, fastener_size)
    cell = row["values"].get(category)
    if cell is None:
        return ConstraintResult(
            "fastener capacity", FAIL, refs, demand, None,
            governing=f"{fastener_size} category {category}",
            detail="published as em dash - no permitted value for this fastener/category")
    cap = Qty(float(cell), "lb", demand.system)
    ok = demand.value <= cap.value
    embed = row["values"].get("Min. Nom. Embedment (in.)")
    prying = {k: v for k, v in row["values"].items() if str(k).startswith("Pr")}
    return ConstraintResult(
        "fastener capacity", PASS if ok else FAIL, refs, demand, cap,
        governing=f"{fastener_size} @ category {category}",
        detail=f"max {cap.value:.0f} lb (angle category {category}"
               + (f", {band_label}" if band_label else "")
               + (f", min embedment {embed} in." if embed is not None else "")
               + f"; anchor {row.get('source_anchor')})"
               + (f"; prying columns preserved: {sorted(prying)}" if prying else ""))
