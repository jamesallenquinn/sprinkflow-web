# -*- coding: utf-8 -*-
"""Brace assembly model + the shared constraint-result type.

An assembly is structure attachment + brace member + pipe attachment + fastener.
Every element has a capacity from an authoritative source (manufacturer dataset
row with provenance, an NFPA table lookup, or an explicit user-entered listed
value). The governing capacity is the minimum. A constraint whose authoritative
data is missing evaluates to UNAVAILABLE (never silently passes or fails)."""
from __future__ import annotations

from dataclasses import dataclass, field

from .datasets import SourceDataRequired, load_component_dataset
from .traceability import rule
from .units import Qty

PASS, FAIL, UNAVAILABLE = "PASS", "FAIL", "UNAVAILABLE"

rule("SB-ASSY-001", nfpa=["18.5.1.1", "18.5.1.3", "18.5.4.1"], kind="validation",
     title="Every brace-assembly element's rated capacity must meet the demand; minimum element governs",
     status="implemented",
     note="Capacity values come only from provenance-carrying datasets or explicit user-entered listed data.")
rule("SB-ASSY-002", nfpa=["18.5.2.1", "18.5.2.2", "18.5.2.2.1"], kind="validation",
     title="Sway-brace components listed / rated for the application",
     status="condition_pending_prose",
     note="'unless'/'listed' conditions per condition_index; engine records listing metadata but cannot adjudicate the exception logic without prose.")
rule("SB-ASSY-003", nfpa=["Table 18.5.2.3", "18.5.2.3", "18.5.2.3.1", "18.5.2.3.2"], kind="table_lookup",
     title="Listed horizontal-load adjustment: listed load rating divided by the published angle divisor",
     status="implemented",
     note="FILLED Table 18.5.2.3 (divisors 2.000 / 1.414 / 1.155 by angle from vertical; printed operative text preserved). Null row (90 deg) never resolves to a value.")
rule("SB-ASSY-004", nfpa=["18.5.2.1", "18.5.2.2"], kind="validation",
     title="Component rating basis enforced by edition: historical UL S.F. 1.5 listings excluded for NFPA 13-2019 and later",
     status="implemented",
     condition_resolution="Manufacturer records marked 'historical listing (NFPA 13-2016 and "
                          "earlier)' resolve only under the 2016 edition (and even there the "
                          "current-basis rating is preferred when both exist); 2019+ calcs "
                          "hard-exclude them. The basis used is printed on the calc sheet.")


@dataclass(frozen=True)
class ComponentCapacity:
    role: str                # structure_attachment | brace_member | pipe_attachment | fastener | fitting
    description: str
    capacity: Qty | None     # None => unavailable
    provenance: str = ""
    pending_identifier: str = ""   # set when capacity is None


@dataclass
class ConstraintResult:
    name: str
    status: str                     # PASS | FAIL | UNAVAILABLE
    nfpa_refs: tuple = ()
    demand: Qty | None = None
    capacity: Qty | None = None
    governing: str = ""
    detail: str = ""
    pending: tuple = ()


def resolve_component_rating_detail(manufacturer_key, figure, size,
                                    angle_from_vertical_deg,
                                    listing_preference=("FM", "UL", "unspecified"),
                                    edition="2025"):
    """Look up a manufacturer component's rated load for a size + brace angle.

    A rating published for a specific angle band is used as published (the
    manufacturer already rated it for that geometry). A rating published
    WITHOUT an angle qualification ('all'/'unspecified' - a plain listed
    design load) is divided by the Table 18.5.2.3 divisor for the installed
    angle, exactly like TOLBrace's Listed -> Adjusted column.

    Returns a dict: appliedLb, listedLb, adjusted(bool), divisorNote,
    listing, angleSpec, provenance. Raises SourceDataRequired when no
    published rating covers the request - never interpolates or guesses."""
    data = load_component_dataset(manufacturer_key)
    comp = next((c for c in data["components"] if c.get("figure") == figure), None)
    if comp is None:
        raise SourceDataRequired(f"{manufacturer_key} {figure}", "component not in dataset")
    srow = next((s for s in comp.get("sizes", []) if s.get("size") == size), None)
    if srow is None:
        raise SourceDataRequired(f"{manufacturer_key} {figure} size {size}", "size row not in dataset")

    def angle_ok(spec):
        if spec in ("all", "unspecified", None):
            return True
        try:
            lo, hi = spec.split("-")
            return float(lo) <= angle_from_vertical_deg <= float(hi)
        except Exception:
            return False

    def is_historical(rec):
        return "histor" in str(rec.get("notes", "")).lower()

    candidates = [r for r in srow.get("ratedLoads", [])
                  if angle_ok(r.get("angleFromVertical"))
                  and isinstance(r.get("loadLb"), (int, float))]   # null = published "not rated"
    # Rating-basis enforcement: historical UL S.F. 1.5 listings (published for
    # NFPA 13-2016 and earlier) are only eligible under the 2016 edition.
    if edition != "2016":
        eligible = [r for r in candidates if not is_historical(r)]
        if not eligible and candidates:
            raise SourceDataRequired(
                f"{manufacturer_key} {figure} size {size}",
                f"only historical (S.F. 1.5, NFPA 13-2016 and earlier) ratings are published "
                f"for this angle - not eligible under the {edition} edition")
        candidates = eligible
    if not candidates:
        raise SourceDataRequired(
            f"{manufacturer_key} {figure} size {size}",
            f"no published rating covers brace angle {angle_from_vertical_deg} deg from vertical")
    chosen = None
    for pref in listing_preference:
        current_first = sorted((r for r in candidates if r.get("listing", "unspecified") == pref),
                               key=is_historical)   # current basis preferred even where both allowed
        if current_first:
            chosen = current_first[0]
            break
    if chosen is None:
        raise SourceDataRequired(f"{manufacturer_key} {figure} size {size}", "no rating for preferred listings")
    listed = float(chosen["loadLb"])
    spec = chosen.get("angleFromVertical")
    historical = is_historical(chosen)
    basis = ("historical S.F. 1.5 (NFPA 13-2016 and earlier)" if historical
             else "current listing basis")
    prov = (f"{data.get('manufacturer')} {figure} {size} "
            f"[{chosen.get('listing')} @ {spec} deg, {basis}] "
            f"p.{srow.get('page')} of {data['provenance'].get('document')}")
    if spec in ("all", "unspecified", None):
        applied, adj_prov = adjusted_listed_load(listed, angle_from_vertical_deg, edition=edition)
        return {"appliedLb": applied, "listedLb": listed, "adjusted": True,
                "divisorNote": adj_prov, "listing": chosen.get("listing"),
                "historical": historical, "basis": basis,
                "angleSpec": spec, "provenance": prov + f"; {adj_prov}"}
    return {"appliedLb": listed, "listedLb": listed, "adjusted": False,
            "divisorNote": "published for this angle band - used as rated",
            "listing": chosen.get("listing"), "historical": historical, "basis": basis,
            "angleSpec": spec, "provenance": prov}


def resolve_component_rating(manufacturer_key, figure, size,
                             angle_from_vertical_deg, listing_preference=("FM", "UL", "unspecified"),
                             edition="2025"):
    """Back-compat wrapper: (applied Qty, provenance)."""
    d = resolve_component_rating_detail(manufacturer_key, figure, size,
                                        angle_from_vertical_deg, listing_preference, edition)
    return Qty(d["appliedLb"], "lb", "imperial"), d["provenance"]


def adjusted_listed_load(listed_load_lb: float, brace_angle_from_vertical_deg: float,
                         edition: str = "2025"):
    """Allowable horizontal load for a listed device whose rating is not already
    angle-specific: listed load divided by the Table 18.5.2.3 divisor for the
    installed brace angle. Returns (allowable_lb, provenance). Raises ValueError
    when the published table has no permitted value for the angle."""
    from .datasets import bucket_value, header_range, load_table
    table = load_table("18.5.2.3", edition=edition)
    import re as _re
    for row in table["rows"]:
        m = _re.match(r"^(\d+)\s*(?:to\s*(\d+))?$", str(row["key"]).strip())
        if not m:
            continue
        lo = float(m.group(1))
        hi = float(m.group(2)) if m.group(2) else lo
        if lo <= brace_angle_from_vertical_deg <= hi:
            divisor = row["values"].get("Allowable Horizontal Load")
            published = str(row.get("published_text", "")).strip()
            if divisor is None:
                # The 90-degree row publishes "Listed load rating" with no
                # divisor - the listed rating applies unreduced (divisor 1.0).
                if published.lower() == "listed load rating":
                    divisor = 1.0
                else:
                    raise ValueError(
                        f"Table 18.5.2.3 has no permitted value at {brace_angle_from_vertical_deg:.0f} deg "
                        f"({published or 'published as em dash'})")
            return (listed_load_lb / float(divisor),
                    f"Table 18.5.2.3 row {row['key']}: {published} "
                    f"(anchor {row.get('source_anchor')})")
    raise ValueError(f"no Table 18.5.2.3 row covers {brace_angle_from_vertical_deg:.0f} deg from vertical")


def assembly_check(demand: Qty, components: list, name="brace assembly capacity") -> ConstraintResult:
    """Minimum component capacity governs. Any unavailable element makes the
    whole check UNAVAILABLE (with the pending identifiers listed)."""
    pending = tuple(c.pending_identifier for c in components if c.capacity is None)
    if pending:
        return ConstraintResult(name, UNAVAILABLE, ("18.5.1.1",), demand, None,
                                detail="capacity unavailable for one or more assembly elements",
                                pending=pending)
    weakest = min(components, key=lambda c: c.capacity.value)
    ok = weakest.capacity.value >= demand.value
    return ConstraintResult(
        name, PASS if ok else FAIL, ("18.5.1.1",), demand, weakest.capacity,
        governing=f"{weakest.role}: {weakest.description}",
        detail=f"governing capacity {weakest.capacity.value:.0f} {weakest.capacity.unit} "
               f"vs demand {demand.value:.0f} {demand.unit} ({weakest.provenance})")
