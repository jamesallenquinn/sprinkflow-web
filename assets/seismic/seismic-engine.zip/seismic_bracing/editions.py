# -*- coding: utf-8 -*-
"""Edition selector: one engine serving NFPA 13 2025, 2022 post-TIA, 2022
pre-TIA, 2019, and 2016.

- Dataset resolution lives in datasets.load_table/load_slot (edition kwarg):
  2022 composes pre-TIA base + TIA 22-8 overlay; 2016 translates canonical ids
  through its edition mapping; NOT_PRESENT constructs raise NotInEdition.
- This module adds the per-edition CALCULATION differences: the seismic
  coefficient (formula editions vs table editions) and the riser-nipple
  screening equation, whose multiplier AND comparator direction differ by
  edition and are evaluated exactly as printed (the 2019 text states the pass
  condition '<= Fy'; the others state the trigger '>= Fy' - at exactly Fy the
  editions genuinely disagree and the engine preserves that).
"""
from __future__ import annotations

import re

from .datasets import DEFAULT_EDITION, EDITION_DIRS, NotInEdition, load_slot
from .traceability import rule

EDITIONS = tuple(EDITION_DIRS)   # ('2025', '2022-post-tia', '2022-pre-tia', '2019', '2016')

EDITION_LABELS = {
    "2025": "NFPA 13 (2025)",
    "2022-post-tia": "NFPA 13 (2022) post-TIA 22-8",
    "2022-pre-tia": "NFPA 13 (2022) pre-TIA 22-8",
    "2019": "NFPA 13 (2019)",
    "2016": "NFPA 13 (2016) [Chapter 9.3]",
}

rule("SB-ED-001", nfpa=["18.5.5.2", "18.5.11.8", "18.5.12.2", "18.6.4"], kind="table_lookup",
     title="Edition-selected table resolution (2025 / 2022 post-TIA overlay / 2022 pre-TIA / 2019 / 2016 mapped)",
     status="implemented",
     note="2022 base = pre-TIA text; tia/ = TIA 22-8 overlay (Log 1747, issued 2023-11-30), composition validated against an independent LiNK capture; 2016 ids translated via edition_mapping; NOT_PRESENT raises NotInEdition (never silently substitutes another edition's values).")
rule("SB-ED-002", nfpa=["18.5.9.3", "18.5.9.3.1", "18.5.9.3.3", "18.5.9.3.4"], kind="formula",
     title="Per-edition seismic coefficient: Cp = 0.754 x SDS (2025 / 2022 post-TIA) vs Ss table lookup (2022 pre-TIA / 2019 / 2016)",
     status="implemented",
     condition_resolution="Formula editions take SDS, table editions take Ss - both delegated site "
                          "inputs recorded explicitly; interpolation in table editions is applied "
                          "only where the dataset's interpolation_permitted flag (transcribed from "
                          "the edition text) allows it, otherwise the bracketing (conservative "
                          "higher-Cp) entry governs.",
     note="Table editions' mapping and the formula both live in per-edition cp_determination datasets.")
rule("SB-ED-003", nfpa=["Equation 18.5.9.6.2", "18.5.9.6.2"], kind="formula",
     title="Per-edition riser-nipple screening: multiplier (1.65 post-TIA/2025 only) and comparator direction exactly as printed",
     status="implemented",
     note="2019 prints the pass condition (<= Fy); 2016/2022 print the trigger (>= Fy); at exactly Fy the editions disagree and each edition's printed semantics govern its own calc.")


# --- seismic coefficient ----------------------------------------------------

_CP_FORMULA_RE = re.compile(r"Cp\s*=\s*([0-9.]+)\s*\*\s*SDS", re.IGNORECASE)
_SS_EDGE_RE = re.compile(r"([0-9.]+)\s*or\s*(less|greater|more)", re.IGNORECASE)


def _parse_ss(entry_ss):
    """Mapping 'ss' field -> (value, edge) where edge is '<=', '>=' or None."""
    if isinstance(entry_ss, (int, float)):
        return float(entry_ss), None
    m = _SS_EDGE_RE.search(str(entry_ss))
    if m:
        return float(m.group(1)), ("<=" if m.group(2).lower() == "less" else ">=")
    return float(str(entry_ss)), None


def edition_uses_height_reduction(edition):
    """True for editions whose Cp method carries the 18.5.9.3.3/.3.4
    attachment-height reduction (the SDS-formula editions: 2025, 2022 post-TIA)."""
    slot = load_slot("cp_determination.json", edition=edition)
    return slot.get("method") == "formula"


def seismic_coefficient(edition, *, sds=None, ss=None, height_multiplier=None):
    """Cp for the chosen edition. Formula editions require sds; table editions
    require ss. The wrong input for the edition raises ValueError so a UI can
    never quietly feed Ss into an SDS formula or vice versa."""
    slot = load_slot("cp_determination.json", edition=edition)
    method = slot.get("method")
    if method == "formula":
        if sds is None or ss is not None:
            raise ValueError(f"NFPA 13 ({edition}) determines Cp from SDS - pass sds=, not ss=")
        m = _CP_FORMULA_RE.search(str(slot.get("formula", "")))
        if not m:
            raise ValueError(f"unexpected cp formula shape: {slot.get('formula')!r}")
        if sds <= 0:
            raise ValueError("SDS must be positive")
        cp = float(m.group(1)) * sds
    elif method == "table":
        if ss is None or sds is not None:
            raise ValueError(f"NFPA 13 ({edition}) determines Cp from an Ss table - pass ss=, not sds=")
        if ss <= 0:
            raise ValueError("Ss must be positive")
        entries = []
        for e in slot.get("mapping", []):
            val, edge = _parse_ss(e["ss"])
            entries.append((val, edge, float(e["cp"])))
        entries.sort(key=lambda x: x[0])
        low = entries[0]
        high = entries[-1]
        if ss <= low[0]:
            cp = low[2]
        elif ss >= high[0]:
            cp = high[2]
        else:
            below = max((e for e in entries if e[0] <= ss), key=lambda x: x[0])
            above = min((e for e in entries if e[0] >= ss), key=lambda x: x[0])
            if below[0] == above[0]:
                cp = below[2]
            elif slot.get("interpolation_permitted"):
                frac = (ss - below[0]) / (above[0] - below[0])
                cp = below[2] + frac * (above[2] - below[2])
            else:
                cp = above[2]   # conservative: the higher-Ss (higher-Cp) entry governs
    else:
        raise ValueError(f"cp_determination for {edition} has unknown method {method!r}")
    if height_multiplier is not None:
        permitted = {float(x) for x in re.findall(r"0\.\d+", str(slot.get("floors_ceilings", "")))}
        if height_multiplier not in permitted:
            raise ValueError(f"height multiplier {height_multiplier} is not among the published "
                             f"permitted values {sorted(permitted)} for edition {edition}")
        cp *= height_multiplier
    return cp


# --- riser-nipple screening -------------------------------------------------

_EQ_RE = re.compile(
    r"^\s*(?:([0-9.]+)\s*\*\s*)?\(\s*Hr\s*\*\s*Wp\s*\*\s*Cp\s*\)\s*/\s*S\s*(>=|<=)\s*Fy\s*$")


def riser_nipple_screening(edition, *, wp_lb, cp, hr_in, s_in3, fy_psi):
    """Evaluate the edition's screening equation exactly as printed.
    Returns {'value_psi', 'fy_psi', 'triggered', 'acceptance', 'provenance'}.
    'triggered' means: individual longitudinal branch-line evaluation and
    bracing IS required."""
    slot = load_slot("equation_18_5_9_6_2.json", edition=edition)
    expr = str(slot.get("expression", ""))
    m = _EQ_RE.match(expr)
    if not m:
        raise ValueError(f"stored expression shape changed for {edition}: {expr!r}")
    if min(wp_lb, cp, hr_in, s_in3, fy_psi) <= 0:
        raise ValueError("all screening inputs must be positive")
    k = float(m.group(1)) if m.group(1) else 1.0
    value = k * (hr_in * wp_lb * cp) / s_in3
    if m.group(2) == ">=":
        triggered = value >= fy_psi          # printed trigger condition
    else:
        triggered = not (value <= fy_psi)    # printed PASS condition (2019)
    return {"value_psi": value, "fy_psi": fy_psi, "triggered": triggered,
            "multiplier": k, "comparator": m.group(2),
            "acceptance": slot.get("acceptance", ""),
            "provenance": f"Equation 18.5.9.6.2 [{EDITION_LABELS[edition]}]: {expr}"}


def edition_info(edition):
    """Summary for the UI/report header."""
    if edition not in EDITION_DIRS:
        raise ValueError(f"unknown edition {edition!r}")
    info = {"edition": edition, "label": EDITION_LABELS[edition]}
    try:
        cp = load_slot("cp_determination.json", edition=edition)
        info["cp_method"] = cp.get("method")
        info["cp_input"] = "SDS" if cp.get("method") == "formula" else "Ss"
    except Exception:
        info["cp_method"] = "unavailable"
    if edition == "2022-post-tia":
        try:
            manifest = load_slot("tia_manifest.json", edition="2022-pre-tia")
            tias = manifest.get("tias", [])
            info["tia"] = ", ".join(f"{t.get('official_number')} (issued {t.get('issue_date')})"
                                    for t in tias)
        except Exception:
            pass
    return info
