# -*- coding: utf-8 -*-
"""Hangers and fasteners subject to earthquakes (18.7 cluster)."""
from .traceability import rule

rule("SB-HANG-001", nfpa=["18.7", "18.7.3", "18.7.4", "18.7.5", "18.7.6"], kind="checklist",
     title="Seismic hanger detailing (retaining straps, C-clamp restraint, rod details)",
     status="report_only")
rule("SB-HANG-002", nfpa=["18.7.1", "18.7.1.1", "18.7.2", "18.7.7"], kind="validation",
     title="Hanger eligibility conditions and listed alternatives under earthquake loads",
     status="condition_pending_prose")
rule("SB-HANG-003", nfpa=["18.7.8", "18.7.9"], kind="validation",
     title="Hanger concrete anchors / inserts prequalification",
     status="delegated",
     note="ACI 355.2 and ICC-ES AC446 per the index external_standards.")
