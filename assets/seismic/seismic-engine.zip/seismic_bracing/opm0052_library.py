# -*- coding: utf-8 -*-
"""OPM-0052 seismic-brace CAD symbol library: manifest, selection, composition.

Data lives in data/seismic_bracing/opm0052/:
  source_manifest.json   provenance (URL, SHA-256, FP page map)
  symbols/*.json         EXTRACTED symbols (technical geometry from the HCAI
                         PDF, stamps/title blocks stripped; paper inches NTS)
  assemblies/assemblies.json  port-based assembly templates + approval scope

This module adds the PARAMETRIC symbols (pipe/brace/clamp glyphs drawn at true
outside diameters, following data/seismic_bracing/detail_standard.json) and a
composer that builds a complete brace detail scene from a template by joining
symbol ports - no hard-coded page coordinates.

APPROVAL RULE (enforced in select_template): a composed detail is labeled
"BASED ON HCAI OPM-0052 (2022 CBC)" only when every checked condition matches
the source sheets; otherwise it is labeled "REFERENCE GEOMETRY ONLY" and the
unresolved conditions are returned to the caller. No HCAI stamp, seal or
signature is ever reproduced. Never mix OPM-0043 (or any other OPM) symbols
into these assemblies.
"""
from __future__ import annotations

import json
import math
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parents[1] / "data" / "seismic_bracing"
OPM_DIR = DATA_DIR / "opm0052"

_CACHE = {}


def _load(path):
    key = str(path)
    if key not in _CACHE:
        _CACHE[key] = json.loads(Path(path).read_text(encoding="utf-8"))
    return _CACHE[key]


def load_source_manifest():
    return _load(OPM_DIR / "source_manifest.json")


def load_assemblies():
    return _load(OPM_DIR / "assemblies" / "assemblies.json")


def load_extracted_index():
    return _load(OPM_DIR / "symbols" / "extracted_index.json")


def load_symbol(symbol_id):
    """Load one extracted symbol JSON by id (or trailing short name)."""
    short = symbol_id.split(".")[-1]
    return _load(OPM_DIR / "symbols" / (short + ".json"))


def detail_standard():
    return _load(DATA_DIR / "detail_standard.json")


def pipe_od(nps_label, default=None):
    std = detail_standard()
    key = str(nps_label).replace('"', "").strip()
    od = std["pipeOdIn"].get(key)
    if od is None:
        if default is None:
            raise KeyError("unknown pipe size %r" % nps_label)
        return float(default)
    return float(od)


# --------------------------------------------------------------------------
# Parametric symbols. Each generator returns {"strokes": {layerkey: [poly..]},
# "ports": {name: {"at": (x,y), "dir": deg}}} in REAL inches, local frame with
# the primary port at the origin. Layer keys: object | dashed | center | text.
# --------------------------------------------------------------------------

def _arc(cx, cy, r, a0, a1, steps=24):
    return [(cx + r * math.cos(a0 + (a1 - a0) * i / steps),
             cy + r * math.sin(a0 + (a1 - a0) * i / steps))
            for i in range(steps + 1)]


def _circle(cx, cy, r, steps=32):
    return _arc(cx, cy, r, 0.0, 2 * math.pi, steps)


def gen_pipe_elevation(od, length, axis_deg=0.0):
    """Service pipe in elevation: double line at true OD, port at center."""
    a = math.radians(axis_deg)
    ux, uy = math.cos(a), math.sin(a)
    nx, ny = -uy, ux
    h = od / 2.0
    L = length / 2.0
    strokes = {"object": [
        [(-L * ux + h * nx, -L * uy + h * ny), (L * ux + h * nx, L * uy + h * ny)],
        [(-L * ux - h * nx, -L * uy - h * ny), (L * ux - h * nx, L * uy - h * ny)],
    ]}
    ports = {"pipe_center": {"at": (0.0, 0.0), "dir": axis_deg}}
    return {"strokes": strokes, "ports": ports}


def gen_pipe_section(od):
    """Service pipe section/end view: circle + S-swirl at true OD (same mark
    as the OPM sheets' grey pipe sections; cf. extracted pipe_section_swirl)."""
    r = od / 2.0
    swirl = (_arc(0, r / 2, r / 2, math.pi / 2, -math.pi / 2, 16)
             + _arc(0, -r / 2, r / 2, math.pi / 2, math.pi * 1.5, 16)[1:])
    return {"strokes": {"object": [_circle(0, 0, r)] + [swirl],
                        "center": [[(-r - 0.25, 0), (r + 0.25, 0)],
                                   [(0, -r - 0.25), (0, r + 0.25)]]},
            "ports": {"pipe_center": {"at": (0.0, 0.0), "dir": 0}}}


def gen_riser_elevation(od, height):
    g = gen_pipe_elevation(od, height, axis_deg=90.0)
    g["ports"]["pipe_center"]["dir"] = 90.0
    return g


def gen_hanger_rod(length, rod_dia=0.375):
    h = rod_dia / 2
    return {"strokes": {"object": [
        [(-h, 0), (-h, -length)], [(h, 0), (h, -length)],
        # hex nut at the structure end
        [(-2.2 * h, 0), (2.2 * h, 0)], [(-2.2 * h, -2.2 * h), (2.2 * h, -2.2 * h)],
        [(-2.2 * h, 0), (-2.2 * h, -2.2 * h)], [(2.2 * h, 0), (2.2 * h, -2.2 * h)],
    ]}, "ports": {"structure_connection": {"at": (0.0, 0.0), "dir": 90},
                  "hanger_connection": {"at": (0.0, -length), "dir": -90}}}


def gen_brace_member(od, length, axis_deg):
    """Rigid brace: double line at true OD along the true angle. Port
    brace_lower at (0,0), brace_upper at the far end."""
    a = math.radians(axis_deg)
    ux, uy = math.cos(a), math.sin(a)
    nx, ny = -uy, ux
    h = od / 2.0
    strokes = {"object": [
        [(h * nx, h * ny), (length * ux + h * nx, length * uy + h * ny)],
        [(-h * nx, -h * ny), (length * ux - h * nx, length * uy - h * ny)],
    ]}
    return {"strokes": strokes,
            "ports": {"brace_lower": {"at": (0.0, 0.0), "dir": axis_deg},
                      "brace_upper": {"at": (length * ux, length * uy), "dir": axis_deg},
                      "brace_axis": {"at": (length / 2 * ux, length / 2 * uy), "dir": axis_deg}}}


def gen_swivel_980_glyph(m_od, mount_deg=-90.0, brace_deg=None):
    """Fig. 980-style swivel glyph (detail_standard proportions): mounting
    plate face at origin, plate normal pointing along mount_deg; clevis toward
    brace_deg. Ports: upper_attachment (plate face), brace_upper (clevis)."""
    std = detail_standard()["glyphs"]["swivel"]
    plate_w = float(std["plateW"].rstrip("m")) * m_od
    plate_t = float(std["plateT"].rstrip("m")) * m_od
    clevis_l = float(std["clevisL"].rstrip("m")) * m_od
    if brace_deg is None:
        brace_deg = mount_deg
    am = math.radians(mount_deg)
    mux, muy = math.cos(am), math.sin(am)            # away from structure
    mnx, mny = -muy, mux
    ab = math.radians(brace_deg)
    bux, buy = math.cos(ab), math.sin(ab)
    bnx, bny = -buy, bux
    strokes = {"object": []}
    # plate
    p0 = (-plate_w / 2 * mnx, -plate_w / 2 * mny)
    p1 = (plate_w / 2 * mnx, plate_w / 2 * mny)
    strokes["object"].append([p0, (p0[0] + plate_t * mux, p0[1] + plate_t * muy),
                              (p1[0] + plate_t * mux, p1[1] + plate_t * muy), p1, p0])
    # clevis cheeks from plate toward the brace
    c0 = (plate_t * mux, plate_t * muy)
    half = 0.62 * m_od
    e = (c0[0] + clevis_l * bux, c0[1] + clevis_l * buy)
    strokes["object"].append([(c0[0] + half * bnx, c0[1] + half * bny),
                              (e[0] + half * bnx, e[1] + half * bny)])
    strokes["object"].append([(c0[0] - half * bnx, c0[1] - half * bny),
                              (e[0] - half * bnx, e[1] - half * bny)])
    strokes["object"].append(_circle(e[0] - 0.5 * m_od * bux, e[1] - 0.5 * m_od * buy,
                                     0.3 * m_od, 16))     # swivel pin
    return {"strokes": strokes,
            "ports": {"upper_attachment": {"at": (0.0, 0.0), "dir": mount_deg + 180},
                      "brace_upper": {"at": e, "dir": brace_deg}}}


def gen_fig1000_glyph(pipe_odv, m_od, brace_deg):
    """Fig. 1000 fast-clamp elevation glyph: strap loop around the pipe with
    the clamping jaw + break-off bolt on the brace side. Port clamp_center at
    the pipe center; brace_lower where the brace member starts."""
    r0 = pipe_odv / 2
    ab = math.radians(brace_deg)
    bux, buy = math.cos(ab), math.sin(ab)
    strokes = {"object": []}
    for band in (0.14, 0.26):
        r = r0 + band * m_od
        a_mid = ab
        strokes["object"].append(_arc(0, 0, r, a_mid - math.radians(235) / 2,
                                      a_mid + math.radians(235) / 2, 28))
    # jaw block on the brace side
    j0 = ((r0 + 0.26 * m_od) * bux, (r0 + 0.26 * m_od) * buy)
    bnx, bny = -buy, bux
    jw, jl = 0.75 * m_od, 0.9 * m_od
    strokes["object"].append([
        (j0[0] + jw * bnx, j0[1] + jw * bny),
        (j0[0] + jw * bnx + jl * bux, j0[1] + jw * bny + jl * buy),
        (j0[0] - jw * bnx + jl * bux, j0[1] - jw * bny + jl * buy),
        (j0[0] - jw * bnx, j0[1] - jw * bny),
        (j0[0] + jw * bnx, j0[1] + jw * bny)])
    bolt = (j0[0] + (jl + 0.35 * m_od) * bux, j0[1] + (jl + 0.35 * m_od) * buy)
    strokes["object"].append(_circle(bolt[0], bolt[1], 0.22 * m_od, 12))
    start = (j0[0] + jl * bux, j0[1] + jl * buy)
    return {"strokes": strokes,
            "ports": {"clamp_center": {"at": (0.0, 0.0), "dir": brace_deg},
                      "pipe_center": {"at": (0.0, 0.0), "dir": 0},
                      "brace_lower": {"at": start, "dir": brace_deg}}}


def gen_fig1001_glyph(pipe_odv, m_od, brace_deg):
    """Fig. 1001 glyph: like the fast clamp but with twin jaw blocks (U-bolt
    over the pipe, jaws both sides of the brace)."""
    g = gen_fig1000_glyph(pipe_odv, m_od, brace_deg)
    ab = math.radians(brace_deg)
    bux, buy = math.cos(ab), math.sin(ab)
    bnx, bny = -buy, bux
    r_jaw = pipe_odv / 2 + 0.26 * m_od
    for side in (+1.6, -1.6):
        j0 = (r_jaw * bux + side * m_od * bnx * 0.55,
              r_jaw * buy + side * m_od * bny * 0.55)
        jw, jl = 0.3 * m_od, 0.7 * m_od
        g["strokes"]["object"].append([
            (j0[0] + jw * bnx, j0[1] + jw * bny),
            (j0[0] + jw * bnx + jl * bux, j0[1] + jw * bny + jl * buy),
            (j0[0] - jw * bnx + jl * bux, j0[1] - jw * bny + jl * buy),
            (j0[0] - jw * bnx, j0[1] - jw * bny),
            (j0[0] + jw * bnx, j0[1] + jw * bny)])
    return g


def gen_fig4l_glyph(pipe_odv, m_od, brace_deg=90.0):
    """Fig. 4L in-line clamp glyph in longitudinal elevation: body plate along
    the pipe (seen from the side) + swivel jaw above; brace rises at
    brace_deg. clamp_center at the pipe centerline."""
    strokes = {"object": []}
    bw = 0.35 * pipe_odv + 0.35         # body width along pipe
    bh = pipe_odv / 2 + 0.28            # body reaches over the pipe top
    strokes["object"].append([(-bw / 2, -bh), (-bw / 2, bh), (bw / 2, bh),
                              (bw / 2, -bh), (-bw / 2, -bh)])
    for y in (-bh + 0.18, bh - 0.18):   # strap bolts top/bottom
        strokes["object"].append(_circle(0, y, 0.09, 10))
    ab = math.radians(brace_deg)
    e = (bh + 0.9 * m_od)
    strokes["object"].append([(-0.4 * m_od, bh), (-0.4 * m_od, bh + 0.55 * m_od),
                              (0.4 * m_od, bh + 0.55 * m_od), (0.4 * m_od, bh)])
    start = (0.0, bh + 0.55 * m_od)
    return {"strokes": strokes,
            "ports": {"clamp_center": {"at": (0.0, 0.0), "dir": 0},
                      "pipe_center": {"at": (0.0, 0.0), "dir": 0},
                      "brace_lower": {"at": start, "dir": brace_deg}}}


def gen_structure_concrete(width, thickness=0.9):
    """Concrete deck band: top structure line with hatch + speckle."""
    strokes = {"object": [[(-width / 2, 0), (width / 2, 0)],
                          [(-width / 2, thickness), (width / 2, thickness)]],
               "context": []}
    x = -width / 2 + 0.18
    import random
    rnd = random.Random(52)
    while x < width / 2 - 0.2:
        y = thickness * (0.25 + 0.5 * rnd.random())
        strokes["context"].append([(x, y), (x + 0.05, y + 0.06), (x + 0.09, y), (x, y)])
        x += 0.32
    return {"strokes": strokes,
            "ports": {"structure_connection": {"at": (0.0, 0.0), "dir": -90}}}


def gen_structure_steel_beam(depth=2.4, flange_w=2.2):
    """Wide-flange beam section, flange-down (elevation of a beam run)."""
    tf = 0.14
    strokes = {"object": [
        # bottom flange
        [(-flange_w / 2, 0), (flange_w / 2, 0)],
        [(-flange_w / 2, tf), (flange_w / 2, tf)],
        [(-flange_w / 2, 0), (-flange_w / 2, tf)], [(flange_w / 2, 0), (flange_w / 2, tf)],
        # web + top flange
        [(-0.07, tf), (-0.07, depth - tf)], [(0.07, tf), (0.07, depth - tf)],
        [(-flange_w / 2, depth - tf), (flange_w / 2, depth - tf)],
        [(-flange_w / 2, depth), (flange_w / 2, depth)],
        [(-flange_w / 2, depth - tf), (-flange_w / 2, depth)],
        [(flange_w / 2, depth - tf), (flange_w / 2, depth)],
    ]}
    return {"strokes": strokes,
            "ports": {"structure_connection": {"at": (0.0, 0.0), "dir": -90}}}


def gen_structure_bar_joist(width=3.4):
    """Open-web joist bottom chord: twin angles + web diagonals upward."""
    strokes = {"object": [[(-width / 2, 0), (width / 2, 0)],
                          [(-width / 2, 0.12), (width / 2, 0.12)]]}
    x = -width / 2
    up = True
    step = width / 6
    pts = []
    while x <= width / 2 - step + 1e-6:
        pts.append([(x, 0.12), (x + step / 2, 0.75), (x + step, 0.12)])
        x += step
    strokes["object"] += pts
    return {"strokes": strokes,
            "ports": {"structure_connection": {"at": (0.0, 0.0), "dir": -90}}}


def gen_structure_wood_beam(w=2.2, h=3.2):
    """Wood beam section: rectangle with X (as on FP-3-10/FP-3-11)."""
    strokes = {"object": [[(-w / 2, 0), (w / 2, 0), (w / 2, h), (-w / 2, h), (-w / 2, 0)]],
               "context": [[(-w / 2, 0), (w / 2, h)], [(-w / 2, h), (w / 2, 0)]]}
    return {"strokes": strokes,
            "ports": {"structure_connection": {"at": (0.0, 0.0), "dir": -90}}}


def gen_clevis_hanger(pipe_odv):
    """Clevis hanger glyph: U-strap over the pipe top + cross pin under the
    rod. Ports: hanger_connection (rod), pipe_center (below)."""
    r = pipe_odv / 2 + 0.12
    strokes = {"object": [_arc(0, 0, r, math.radians(15), math.radians(165), 16)]}
    y_top = r + 0.16
    strokes["object"].append([(-0.28, y_top), (0.28, y_top)])
    strokes["object"].append([(-0.28, y_top), (-r * 0.96, r * 0.28)])
    strokes["object"].append([(0.28, y_top), (r * 0.96, r * 0.28)])
    strokes["object"].append(_circle(0, y_top - 0.07, 0.055, 10))
    return {"strokes": strokes,
            "ports": {"hanger_connection": {"at": (0.0, y_top), "dir": 90},
                      "pipe_center": {"at": (0.0, 0.0), "dir": 0}}}


def gen_trapeze_member(length, depth=0.35):
    """Trapeze / supplemental support member: double line with closed ends.
    Ports: hanger_connection at both ends, pipe_connection mid-span."""
    L = length / 2
    strokes = {"object": [[(-L, 0), (L, 0)], [(-L, -depth), (L, -depth)],
                          [(-L, 0), (-L, -depth)], [(L, 0), (L, -depth)]]}
    return {"strokes": strokes,
            "ports": {"hanger_connection": {"at": (-L, 0.0), "dir": 90},
                      "hanger_connection_2": {"at": (L, 0.0), "dir": 90},
                      "pipe_connection": {"at": (0.0, 0.0), "dir": 90}}}


def gen_leader(tip, elbow, landing_dir=1, landing=None, text=None, text_h=None):
    """Leader arrow annotation: filled-arrow tip -> elbow -> horizontal
    landing; returns text anchor at the landing end."""
    std = detail_standard()
    landing = std["callout"]["leaderLandingIn"] if landing is None else landing
    text_h = std["text"]["calloutHeightIn"] if text_h is None else text_h
    dx, dy = elbow[0] - tip[0], elbow[1] - tip[1]
    d = math.hypot(dx, dy) or 1.0
    ux, uy = dx / d, dy / d
    aw, al = 0.033, 0.10
    a1 = (tip[0] + al * ux - aw * uy, tip[1] + al * uy + aw * ux)
    a2 = (tip[0] + al * ux + aw * uy, tip[1] + al * uy - aw * ux)
    end = (elbow[0] + landing_dir * landing, elbow[1])
    strokes = {"text": [[tip, elbow, end]]}
    arrow = [tip, a1, a2, tip]
    txt = []
    if text:
        gap = std["callout"]["gapIn"]
        tx = end[0] + landing_dir * gap
        if landing_dir < 0:
            tx -= len(str(text)) * text_h * 0.72
        txt.append({"t": text, "x": tx, "y": elbow[1] - text_h / 2, "h": text_h})
    return {"strokes": strokes, "arrow": arrow, "texts": txt,
            "ports": {"label_anchor": {"at": end, "dir": 0}}}


def gen_dimension(p0, p1, offset=0.45, text=None):
    """Dimension line with extension lines and tick marks; text above mid."""
    std = detail_standard()
    dx, dy = p1[0] - p0[0], p1[1] - p0[1]
    d = math.hypot(dx, dy) or 1.0
    ux, uy = dx / d, dy / d
    nx, ny = -uy, ux
    a0 = (p0[0] + nx * offset, p0[1] + ny * offset)
    a1 = (p1[0] + nx * offset, p1[1] + ny * offset)
    t = 0.07
    strokes = {"text": [
        [p0, (a0[0] + nx * 0.12, a0[1] + ny * 0.12)],
        [p1, (a1[0] + nx * 0.12, a1[1] + ny * 0.12)],
        [a0, a1],
        [(a0[0] - (ux + nx) * t, a0[1] - (uy + ny) * t),
         (a0[0] + (ux + nx) * t, a0[1] + (uy + ny) * t)],
        [(a1[0] - (ux + nx) * t, a1[1] - (uy + ny) * t),
         (a1[0] + (ux + nx) * t, a1[1] + (uy + ny) * t)],
    ]}
    texts = []
    if text:
        h = std["text"]["calloutHeightIn"]
        texts.append({"t": text, "x": (a0[0] + a1[0]) / 2 - len(str(text)) * h * 0.36,
                      "y": (a0[1] + a1[1]) / 2 + 0.06, "h": h})
    return {"strokes": strokes, "texts": texts,
            "ports": {"dimension_anchor": {"at": ((a0[0] + a1[0]) / 2,
                                                  (a0[1] + a1[1]) / 2), "dir": 0}}}


def gen_break_line(p0, p1, jog=0.12):
    """Break line: straight with a Z-jog at the middle."""
    mx, my = (p0[0] + p1[0]) / 2, (p0[1] + p1[1]) / 2
    dx, dy = p1[0] - p0[0], p1[1] - p0[1]
    d = math.hypot(dx, dy) or 1.0
    ux, uy = dx / d, dy / d
    nx, ny = -uy, ux
    pts = [p0, (mx - 0.12 * ux, my - 0.12 * uy),
           (mx - 0.04 * ux + jog * nx, my - 0.04 * uy + jog * ny),
           (mx + 0.04 * ux - jog * nx, my + 0.04 * uy - jog * ny),
           (mx + 0.12 * ux, my + 0.12 * uy), p1]
    return {"strokes": {"object": [pts]}, "ports": {}}


def gen_section_marker(at, label="1", leg=0.5):
    """Section/elevation indicator: corner legs + label (FP-2-4 style cuts)."""
    x, y = at
    strokes = {"text": [[(x - leg, y), (x - leg, y - 0.18)],
                        [(x - leg, y), (x, y)]]}
    return {"strokes": strokes,
            "texts": [{"t": label, "x": x - leg - 0.14, "y": y + 0.05,
                       "h": detail_standard()["text"]["calloutHeightIn"]}],
            "ports": {"label_anchor": {"at": (x - leg, y), "dir": 180}}}


def gen_flow_arrow(at, direction_deg=0.0, size=0.4):
    """Pipe-run direction indicator: open arrow along the run."""
    a = math.radians(direction_deg)
    ux, uy = math.cos(a), math.sin(a)
    nx, ny = -uy, ux
    tip = (at[0] + size * ux, at[1] + size * uy)
    strokes = {"text": [[at, tip],
                        [(tip[0] - 0.14 * ux + 0.08 * nx, tip[1] - 0.14 * uy + 0.08 * ny), tip],
                        [(tip[0] - 0.14 * ux - 0.08 * nx, tip[1] - 0.14 * uy - 0.08 * ny), tip]]}
    return {"strokes": strokes,
            "ports": {"label_anchor": {"at": tip, "dir": direction_deg}}}


def gen_component_callout(number, at):
    """Component-number callout: circled number with label anchor."""
    r = 0.14
    return {"strokes": {"text": [_circle(at[0], at[1], r, 16)]},
            "texts": [{"t": str(number), "x": at[0] - 0.045, "y": at[1] - 0.06,
                       "h": detail_standard()["text"]["calloutHeightIn"]}],
            "ports": {"label_anchor": {"at": at, "dir": 0}}}


def gen_anchor_bolt(dia=0.14, embed=0.6):
    """Wedge-anchor glyph: shank into the substrate + nut/washer below face."""
    h = dia / 2
    strokes = {"object": [
        [(-h, 0), (-h, embed)], [(h, 0), (h, embed)],
        [(-h, embed), (h, embed)],
        [(-2.6 * h, 0), (2.6 * h, 0)],
        [(-2.2 * h, -0.16), (2.2 * h, -0.16)],
        [(-2.2 * h, 0), (-2.2 * h, -0.16)], [(2.2 * h, 0), (2.2 * h, -0.16)],
    ]}
    return {"strokes": strokes,
            "ports": {"structure_connection": {"at": (0.0, 0.0), "dir": -90},
                      "fastener_axis": {"at": (0.0, 0.0), "dir": 90}}}


PARAMETRIC_SYMBOLS = {
    "opm0052.fp.parametric.pipe_elevation": {"generator": gen_pipe_elevation,
        "display_name": "Service pipe - elevation (double line, true OD)",
        "params": "od, length, axis_deg", "kind": "primitive"},
    "opm0052.fp.parametric.pipe_section": {"generator": gen_pipe_section,
        "display_name": "Service pipe - section/end view (circle + S-swirl, true OD)",
        "params": "od", "kind": "primitive"},
    "opm0052.fp.parametric.riser_elevation": {"generator": gen_riser_elevation,
        "display_name": "Vertical riser - elevation", "params": "od, height", "kind": "primitive"},
    "opm0052.fp.parametric.hanger_rod": {"generator": gen_hanger_rod,
        "display_name": "Hanger rod with structure nut", "params": "length, rod_dia", "kind": "primitive"},
    "opm0052.fp.parametric.brace_member": {"generator": gen_brace_member,
        "display_name": "Rigid brace member (double line, true OD, true angle)",
        "params": "od, length, axis_deg", "kind": "primitive"},
    "opm0052.fp.parametric.swivel_980_glyph": {"generator": gen_swivel_980_glyph,
        "display_name": "Fig. 980-style swivel attachment glyph (parametric)",
        "params": "m_od, mount_deg, brace_deg", "kind": "component_glyph",
        "represents": "TOLCO Fig. 980", "source_ref": "FP-4-1"},
    "opm0052.fp.parametric.fig1000_elev_glyph": {"generator": gen_fig1000_glyph,
        "display_name": "Fig. 1000 fast clamp glyph (parametric elevation)",
        "params": "pipe_od, m_od, brace_deg", "kind": "component_glyph",
        "represents": "TOLCO Fig. 1000", "source_ref": "FP-4-3"},
    "opm0052.fp.parametric.fig1001_elev_glyph": {"generator": gen_fig1001_glyph,
        "display_name": "Fig. 1001 attachment glyph (parametric elevation)",
        "params": "pipe_od, m_od, brace_deg", "kind": "component_glyph",
        "represents": "TOLCO Fig. 1001", "source_ref": "FP-4-4"},
    "opm0052.fp.parametric.fig4l_elev_glyph": {"generator": gen_fig4l_glyph,
        "display_name": "Fig. 4L in-line clamp glyph (parametric longitudinal elevation)",
        "params": "pipe_od, m_od, brace_deg", "kind": "component_glyph",
        "represents": "TOLCO Fig. 4L", "source_ref": "FP-4-2"},
    "opm0052.fp.parametric.structure_concrete": {"generator": gen_structure_concrete,
        "display_name": "Concrete deck substrate band", "params": "width, thickness", "kind": "substrate"},
    "opm0052.fp.parametric.structure_steel_beam": {"generator": gen_structure_steel_beam,
        "display_name": "Wide-flange steel beam (flange-down elevation)", "params": "depth, flange_w", "kind": "substrate"},
    "opm0052.fp.parametric.structure_bar_joist": {"generator": gen_structure_bar_joist,
        "display_name": "Bar joist / open-web truss bottom chord", "params": "width", "kind": "substrate"},
    "opm0052.fp.parametric.structure_wood_beam": {"generator": gen_structure_wood_beam,
        "display_name": "Wood beam section (crossed rectangle)", "params": "w, h", "kind": "substrate"},
    "opm0052.fp.parametric.clevis_hanger": {"generator": gen_clevis_hanger,
        "display_name": "Clevis hanger glyph at pipe top", "params": "pipe_od", "kind": "primitive"},
    "opm0052.fp.parametric.trapeze_member": {"generator": gen_trapeze_member,
        "display_name": "Trapeze / supplemental support member", "params": "length, depth", "kind": "primitive"},
    "opm0052.fp.annotation.leader": {"generator": gen_leader,
        "display_name": "Leader arrow with landing + text anchor", "params": "tip, elbow, landing_dir, text", "kind": "annotation"},
    "opm0052.fp.annotation.dimension": {"generator": gen_dimension,
        "display_name": "Dimension line with extension lines", "params": "p0, p1, offset, text", "kind": "annotation"},
    "opm0052.fp.annotation.break_line": {"generator": gen_break_line,
        "display_name": "Break line (Z-jog)", "params": "p0, p1", "kind": "annotation"},
    "opm0052.fp.annotation.section_marker": {"generator": gen_section_marker,
        "display_name": "Section / elevation indicator", "params": "at, label", "kind": "annotation"},
    "opm0052.fp.annotation.flow_arrow": {"generator": gen_flow_arrow,
        "display_name": "Pipe-run direction indicator", "params": "at, direction_deg", "kind": "annotation"},
    "opm0052.fp.annotation.component_callout": {"generator": gen_component_callout,
        "display_name": "Component-number callout (circled)", "params": "number, at", "kind": "annotation"},
    "opm0052.fp.parametric.anchor_bolt": {"generator": gen_anchor_bolt,
        "display_name": "Wedge anchor glyph", "params": "dia, embed", "kind": "component_glyph",
        "represents": "Hilti KB-TZ2 (CS)", "source_ref": "FP-3-1"},
}


# --------------------------------------------------------------------------
# Manifest
# --------------------------------------------------------------------------

def manifest():
    """Full library manifest: extracted symbols + parametric symbols +
    assembly templates, with provenance and approval scope."""
    src = load_source_manifest()
    asm = load_assemblies()
    ext = load_extracted_index()
    parametric = [
        {"id": sid, "display_name": meta["display_name"], "kind": meta["kind"],
         "geometry": {"format": "parametric", "generator": sid.split(".")[-1],
                      "params": meta["params"], "units": "in"},
         "represents": meta.get("represents"),
         "source": ({"document": "HCAI OPM-0052", "printed_sheet": meta["source_ref"],
                     "pdf_sha256": src["pdf_sha256"], "role": "graphical reference"}
                    if meta.get("source_ref") else
                    {"document": "SprinkFlow detail standard",
                     "file": "data/seismic_bracing/detail_standard.json"}),
         "approval_scope": {"opm": "OPM-0052", "code_cycle": "2022 CBC",
                            "status": "basis_of_design_only"} if meta.get("source_ref")
                           else {"status": "sprinkflow_owned_primitive"}}
        for sid, meta in PARAMETRIC_SYMBOLS.items()]
    return {"dataset": "opm0052-symbol-library-manifest",
            "datasetVersion": "2026-07-19",
            "source": {k: src[k] for k in ("document", "opm", "approval_date",
                                           "code_cycle", "source_url", "pdf_url",
                                           "pdf_sha256", "retrieved")},
            "approval_scope": asm["approval_scope"],
            "extracted_symbols": ext["symbols"],
            "parametric_symbols": parametric,
            "templates": [t["id"] for t in asm["templates"]],
            "upper_attachments": list(asm["upper_attachments"].keys()),
            "lower_attachments": list(asm["lower_attachments"].keys())}


# --------------------------------------------------------------------------
# Selection interface
# --------------------------------------------------------------------------

_STRUCTURE_TO_UPPER = {
    "concrete_deck": ["kbtz2_concrete_deck", "kbtz2_lightweight_deck"],
    "concrete_wall": ["kbtz2_concrete_wall"],
    "steel_beam": ["welded_steel", "bolted_steel", "f828_steel_beam", "f800_steel_beam"],
    "bar_joist": ["f825_bar_joist"],
    "wood_beam": ["wood_thru_bolt_perpendicular", "wood_thru_bolt_parallel"],
    "supplemental_steel": ["supplemental_steel"],
}

_FRAC = {"1": 1.0, "1 1/4": 1.25, "1-1/4": 1.25, "1 1/2": 1.5, "1-1/2": 1.5,
         "2": 2.0, "2 1/2": 2.5, "2-1/2": 2.5, "3": 3.0, "3 1/2": 3.5, "4": 4.0,
         "5": 5.0, "6": 6.0, "8": 8.0}


def _size_val(label):
    return _FRAC.get(str(label).replace('"', "").strip(),
                     None if not str(label).strip() else None)


def select_template(criteria):
    """Select the assembly template for the detail generator.

    criteria: {brace_direction, service_pipe_orientation, lower_attachment,
    upper_attachment, brace_member, structure_type, horizontal_brace,
    vertical_brace, angle_degrees, pipe_size, approval_basis}

    Returns {template, upper_attachment, symbols, sources,
    unresolved_conditions, approval: {status, label}}."""
    asm = load_assemblies()
    direction = criteria.get("brace_direction", "transverse")
    vertical = bool(criteria.get("vertical_brace"))
    horizontal = criteria.get("horizontal_brace", True)
    lower = criteria.get("lower_attachment")

    # template choice
    if direction == "four_way_riser" or criteria.get("service_pipe_orientation") == "vertical":
        tid = "opm0052.fp.assembly.riser_r1"
    elif direction == "longitudinal":
        tid = "opm0052.fp.assembly.longitudinal_2l"
    elif vertical and horizontal:
        tid = "opm0052.fp.assembly.horizontal_plus_vertical"
    elif horizontal and criteria.get("double_bracing"):
        tid = "opm0052.fp.assembly.single_horizontal"
    else:
        pipe_v = _size_val(criteria.get("pipe_size", "")) or 0
        if lower == "fig1001" or (lower is None and pipe_v > 4):
            tid = "opm0052.fp.assembly.transverse_1g_b"
        else:
            tid = "opm0052.fp.assembly.transverse_1g_a"
    template = next(t for t in asm["templates"] if t["id"] == tid)

    # upper attachment
    structure = criteria.get("structure_type", "concrete_deck")
    upper_key = criteria.get("upper_attachment")
    if not upper_key:
        options = _STRUCTURE_TO_UPPER.get(structure, [])
        if not options:
            raise ValueError("no OPM-0052 upper attachment for structure_type %r" % structure)
        upper_key = options[0]
    upper = asm["upper_attachments"][upper_key]

    lower_key = template.get("lower_attachment") if template.get("lower_attachment") else lower
    if criteria.get("lower_attachment"):
        lower_key = criteria["lower_attachment"]
    lower_info = asm["lower_attachments"].get(lower_key, {})

    unresolved = list(template.get("conditions_to_verify", []))
    unresolved += ["upper attachment: " + c for c in upper.get("conditions", [])]

    # approval-status checks the library can adjudicate itself
    exact = True
    angle = criteria.get("angle_degrees")
    lo, hi = template.get("angle_range_deg_from_vertical", [30, 90])
    if angle is not None and not (lo <= float(angle) <= hi):
        exact = False
        unresolved.append("brace angle %.1f deg outside the %g-%g deg sheet range"
                          % (float(angle), lo, hi))
    size_rng = template.get("pipe_size_range_in")
    ps = _size_val(criteria.get("pipe_size", ""))
    if size_rng and ps is not None:
        lo_v, hi_v = _size_val(size_rng[0]), _size_val(size_rng[1])
        if not (lo_v <= ps <= hi_v):
            exact = False
            unresolved.append("pipe size %s outside detail range %s-%s in."
                              % (criteria.get("pipe_size"), size_rng[0], size_rng[1]))
    rng = lower_info.get("pipe_range_in")
    if rng and ps is not None:
        if not (_size_val(rng[0]) <= ps <= _size_val(rng[1])):
            exact = False
            unresolved.append("pipe size outside %s range %s-%s in."
                              % (lower_info.get("display", lower_key), rng[0], rng[1]))
    if criteria.get("approval_basis") not in (None, "OPM-0052"):
        exact = False
        unresolved.append("approval basis %r is not OPM-0052; do not mix OPM approvals"
                          % criteria.get("approval_basis"))
    if str(criteria.get("brace_member", "")).strip() and \
            "sch" not in str(criteria.get("brace_member", "")).lower().replace("edule", ""):
        unresolved.append("brace member must be Schedule 40 steel pipe (FP-4-1 note 5)")

    status = "based_on_opm0052" if exact else "reference_geometry_only"
    label = ("BASED ON HCAI OPM-0052 (2022 CBC) - CONDITIONS APPLY" if exact
             else "REFERENCE GEOMETRY ONLY - NOT AN OPM-0052 CONFIGURATION")

    symbol_ids = list(upper.get("symbols", [])) + list(lower_info.get("symbols", []))
    if lower_info.get("parametric_glyph"):
        symbol_ids.append(lower_info["parametric_glyph"])
    symbol_ids += ["opm0052.fp.parametric.brace_member",
                   "opm0052.fp.parametric.swivel_980_glyph",
                   "opm0052.fp.parametric.pipe_section"
                   if criteria.get("service_pipe_orientation") != "vertical"
                   else "opm0052.fp.parametric.riser_elevation"]

    sources = [{"printed_sheet": template["detail_basis"]["printed_sheet"],
                "detail_id": template["detail_basis"].get("detail_id")}]
    sources += [{"printed_sheet": s} for s in upper.get("printed_sheets", [])]
    sources += [{"printed_sheet": s} for s in lower_info.get("printed_sheets", [])]

    return {"template": template, "upper_attachment_key": upper_key,
            "upper_attachment": upper, "lower_attachment_key": lower_key,
            "lower_attachment": lower_info, "symbols": symbol_ids,
            "sources": sources, "unresolved_conditions": unresolved,
            "approval": {"status": status, "label": label,
                         "opm": "OPM-0052", "code_cycle": "2022 CBC"}}


# --------------------------------------------------------------------------
# Composer: template + params -> scene (port-joined), scene -> R12 DXF
# --------------------------------------------------------------------------

def _place(scene, sym_geo, at, rotate_deg=0.0, port=None):
    """Place a generated symbol into the scene so that `port` (or its local
    origin) lands on `at` after rotation. Records the port joint for QA."""
    a = math.radians(rotate_deg)
    c, s = math.cos(a), math.sin(a)
    off = (0.0, 0.0)
    if port and port in sym_geo["ports"]:
        px, py = sym_geo["ports"][port]["at"]
        off = (px, py)

    def xf(pt):
        x, y = pt[0] - off[0], pt[1] - off[1]
        return (at[0] + x * c - y * s, at[1] + x * s + y * c)

    for layer, polys in sym_geo["strokes"].items():
        scene["layers"].setdefault(layer, []).extend([[xf(p) for p in poly]
                                                      for poly in polys])
    placed_ports = {}
    for name, p in sym_geo["ports"].items():
        placed_ports[name] = {"at": xf(p["at"]), "dir": p["dir"] + rotate_deg}
    scene["joints"].append({"at": list(at), "port": port, "ports": placed_ports})
    return placed_ports


def compose(selection, params):
    """Compose the selected template into a 2D scene (real inches).

    params: {pipe_size, brace_size, angle_degrees, vertical_brace}
    Returns {"layers": {...}, "texts": [...], "joints": [...]}
    All positions derive from port joins - no page coordinates."""
    std = detail_standard()
    template = selection["template"]
    scene = {"layers": {}, "texts": [], "joints": []}
    p_od = pipe_od(params.get("pipe_size", "4"), 4.5)
    m_od = pipe_od(params.get("brace_size", "1"), 1.315)
    angle = float(params.get("angle_degrees", 45.0))
    a_from_vert = math.radians(angle)
    scene_kind = template.get("scene", "elevation")
    structure = selection["upper_attachment"].get("structure_type", "concrete_deck")

    def substrate(width):
        if structure in ("concrete_deck", "concrete_deck_metal_form"):
            return gen_structure_concrete(width)
        if structure in ("steel_beam", "supplemental_steel"):
            return gen_structure_steel_beam()
        if structure == "bar_joist":
            return gen_structure_bar_joist()
        if structure == "wood_beam":
            return gen_structure_wood_beam()
        if structure == "concrete_wall":
            g = gen_structure_concrete(width)   # wall band, rotated on placement
            return g
        return gen_structure_concrete(width)

    if scene_kind == "riser_plan":
        # plan: riser section at origin; two clamps/braces 90 deg apart
        sec = gen_pipe_section(p_od)
        _place(scene, sec, (0.0, 0.0), 0.0, "pipe_center")
        for plan_deg in (135.0, 45.0):
            clamp = gen_fig1000_glyph(p_od, m_od, plan_deg)
            ports = _place(scene, clamp, (0.0, 0.0), 0.0, "clamp_center")
            b0 = ports["brace_lower"]["at"]
            blen = max(2.6, p_od * 0.9 + 1.8)
            brace = gen_brace_member(m_od, blen, plan_deg)
            bports = _place(scene, brace, b0, 0.0, "brace_lower")
            sw = gen_swivel_980_glyph(m_od, mount_deg=plan_deg - 180,
                                      brace_deg=plan_deg - 180)
            _place(scene, sw, (bports["brace_upper"]["at"][0] + 0.9 * m_od * math.cos(math.radians(plan_deg)),
                               bports["brace_upper"]["at"][1] + 0.9 * m_od * math.sin(math.radians(plan_deg))),
                   0.0, "upper_attachment")
        scene["texts"].append({"t": "PLAN VIEW", "x": -0.8, "y": -p_od - 2.2,
                               "h": std["text"]["subTitleHeightIn"]})
        return scene

    # elevation family: pipe section at origin, structure above
    rise = max(6.0, p_od * 1.6 + 4.0)
    brace_dir = 90.0 - angle          # measured from vertical -> scene angle
    run = rise * math.tan(a_from_vert)

    if scene_kind == "elevation_longitudinal":
        pipe = gen_pipe_elevation(p_od, max(7.0, p_od * 2.2 + 5.0))
        _place(scene, pipe, (0.0, 0.0), 0.0, "pipe_center")
        clamp = gen_fig4l_glyph(p_od, m_od, 90.0 - 0.0)
        cports = _place(scene, clamp, (0.0, 0.0), 0.0, "clamp_center")
        b0 = cports["brace_lower"]["at"]
    else:
        sec = gen_pipe_section(p_od)
        _place(scene, sec, (0.0, 0.0), 0.0, "pipe_center")
        lower_key = selection.get("lower_attachment_key")
        gen = gen_fig1001_glyph if lower_key == "fig1001" else gen_fig1000_glyph
        clamp = gen(p_od, m_od, brace_dir)
        cports = _place(scene, clamp, (0.0, 0.0), 0.0, "clamp_center")
        b0 = cports["brace_lower"]["at"]

    # HSB from the clamp to the structure
    dx = math.cos(math.radians(brace_dir))
    dy = math.sin(math.radians(brace_dir))
    clevis_l = 1.6 * m_od
    blen = (rise - b0[1]) / dy if dy > 1e-6 else rise
    blen -= clevis_l
    brace = gen_brace_member(m_od, blen, brace_dir)
    bports = _place(scene, brace, b0, 0.0, "brace_lower")
    top = bports["brace_upper"]["at"]

    # swivel at the structure, then the substrate band above it
    sw = gen_swivel_980_glyph(m_od, mount_deg=-90.0, brace_deg=brace_dir + 180.0)
    anchor_at = (top[0] + clevis_l * dx, top[1] + clevis_l * dy)
    _place(scene, sw, anchor_at, 0.0, "upper_attachment")
    if structure in ("concrete_deck", "concrete_deck_metal_form"):
        sub_w = max(6.0, anchor_at[0] + 5.0)
        sub = substrate(sub_w)
        _place(scene, sub, (anchor_at[0] + 2.5 - sub_w / 2, anchor_at[1]),
               0.0, None)
        _place(scene, gen_anchor_bolt(), anchor_at, 0.0, "structure_connection")
        rod = gen_hanger_rod(anchor_at[1] - p_od / 2 - 0.12)
        _place(scene, rod, (0.0, anchor_at[1]), 0.0, "structure_connection")
    else:
        sub = substrate(max(6.0, run + 4.0))
        _place(scene, sub, anchor_at, 0.0, "structure_connection")

    # optional VSB
    if scene_kind == "elevation_with_vsb" or params.get("vertical_brace"):
        v0 = (b0[0] + 1.1 * m_od, b0[1])
        vlen = rise - v0[1] - clevis_l
        vb = gen_brace_member(m_od, vlen, 90.0)
        vports = _place(scene, vb, v0, 0.0, "brace_lower")
        vtop = vports["brace_upper"]["at"]
        vsw = gen_swivel_980_glyph(m_od, mount_deg=-90.0, brace_deg=-90.0)
        _place(scene, vsw, (vtop[0], vtop[1] + clevis_l), 0.0, "upper_attachment")

    if scene_kind == "elevation_double_horizontal":
        # opposed second brace, mirrored
        b0m = (-b0[0], b0[1])
        clamp2 = gen_fig1000_glyph(p_od, m_od, 180.0 - brace_dir)
        _place(scene, clamp2, (0.0, 0.0), 0.0, "clamp_center")
        brace2 = gen_brace_member(m_od, blen, 180.0 - brace_dir)
        b2 = _place(scene, brace2, b0m, 0.0, "brace_lower")
        top2 = b2["brace_upper"]["at"]
        sw2 = gen_swivel_980_glyph(m_od, mount_deg=-90.0, brace_deg=180.0 - brace_dir)
        _place(scene, sw2, (top2[0] - clevis_l * dx, top2[1] + clevis_l * dy),
               0.0, "upper_attachment")

    # standard component callouts (leader annotation primitives)
    def add_callout(tip, elbow, side, label):
        led = gen_leader(tip, elbow, landing_dir=side, text=label)
        for lay, ps in led["strokes"].items():
            scene["layers"].setdefault(lay, []).extend(ps)
        scene["layers"].setdefault("text", []).append(led["arrow"])
        scene["texts"].extend(led["texts"])

    lower_lbl = {"fig1000": "TOLCO FIG. 1000 FAST CLAMP (FP-4-3)",
                 "fig1001": "TOLCO FIG. 1001 (FP-4-4)",
                 "fig4l": 'TOLCO FIG. 4L "IN-LINE" CLAMP (FP-4-2)'}.get(
                     selection.get("lower_attachment_key"), "PIPE ATTACHMENT")
    if scene_kind != "riser_plan":
        add_callout((b0[0], b0[1]), (b0[0] + 1.6, b0[1] - 1.2), 1, lower_lbl)
        add_callout((anchor_at[0] - 0.5 * m_od, anchor_at[1] - 0.4 * m_od),
                    (anchor_at[0] - 2.6, anchor_at[1] - 1.5), -1,
                    "TOLCO FIG. 980 SWAY BRACE ATTACHMENT (FP-4-1)")
        mid = ((b0[0] + top[0]) / 2, (b0[1] + top[1]) / 2)
        add_callout((mid[0] - 0.5 * m_od * dy, mid[1] + 0.5 * m_od * dx),
                    (mid[0] - 1.8, mid[1] + 1.4), -1,
                    "%s IN. SCH. 40 STEEL BRACE (FP-4-6)"
                    % str(params.get("brace_size", "1")).upper())
        add_callout((0.0, -p_od / 2), (1.8, -p_od / 2 - 1.2), 1,
                    "%s IN. BRACED PIPE" % str(params.get("pipe_size", "")).upper())
        scene["texts"].append({"t": selection["upper_attachment"]["display"].upper(),
                               "x": anchor_at[0] - 3.2, "y": anchor_at[1] + 1.35,
                               "h": std["text"]["calloutHeightIn"]})

    # angle arc + reference vertical (annotation primitives)
    arc_r = 1.5
    scene["layers"].setdefault("center", []).append(
        [(anchor_at[0], anchor_at[1]), (anchor_at[0], anchor_at[1] - 2.4)])
    arc = [(anchor_at[0] - arc_r * math.sin(a_from_vert * i / 10),
            anchor_at[1] - arc_r * math.cos(a_from_vert * i / 10))
           for i in range(11)]
    scene["layers"].setdefault("text", []).append(arc)
    scene["texts"].append({"t": "%g DEG" % angle, "x": anchor_at[0] - arc_r - 0.9,
                           "y": anchor_at[1] - 1.9, "h": std["text"]["calloutHeightIn"]})
    return scene


def scene_to_dxf(scene, title="SEISMIC BRACE DETAIL", approval_label=""):
    """Scene -> R12/AC1009 DXF text (POLYLINE/TEXT, no handles), using the
    detail_standard layer scheme. Verified by read-back in the tests."""
    std = detail_standard()
    L = std["layers"]
    layer_map = {"object": L["detail"]["name"], "context": L["detail"]["name"],
                 "dashed": L["center"]["name"], "center": L["center"]["name"],
                 "text": L["text"]["name"]}
    out = []
    w = lambda code, v: (out.append(str(code)), out.append(str(v)))
    n = lambda v: "%.4f" % float(v)
    w(0, "SECTION"); w(2, "HEADER"); w(9, "$ACADVER"); w(1, "AC1009")
    w(9, "$INSUNITS"); w(70, 1); w(0, "ENDSEC")
    w(0, "SECTION"); w(2, "TABLES"); w(0, "TABLE"); w(2, "LAYER"); w(70, 3)
    for key in ("detail", "text", "center"):
        w(0, "LAYER"); w(2, L[key]["name"]); w(70, 0); w(62, L[key]["aci"]); w(6, "CONTINUOUS")
    w(0, "ENDTAB"); w(0, "ENDSEC"); w(0, "SECTION"); w(2, "ENTITIES")
    for layer_key, polys in scene["layers"].items():
        lname = layer_map.get(layer_key, L["detail"]["name"])
        for poly in polys:
            if len(poly) < 2:
                continue
            w(0, "POLYLINE"); w(8, lname); w(66, 1); w(70, 0)
            for (x, y) in poly:
                w(0, "VERTEX"); w(8, lname); w(10, n(x)); w(20, n(y)); w(30, 0)
            w(0, "SEQEND")
    texts = list(scene.get("texts", []))
    if title:
        ys = min((pt[1] for polys in scene["layers"].values()
                  for poly in polys for pt in poly), default=0.0)
        texts.append({"t": title, "x": -2.0, "y": ys - 1.2,
                      "h": std["text"]["titleHeightIn"]})
        if approval_label:
            texts.append({"t": approval_label, "x": -2.0, "y": ys - 1.55,
                          "h": std["text"]["subTitleHeightIn"]})
    for t in texts:
        w(0, "TEXT"); w(8, L["text"]["name"])
        w(10, n(t["x"])); w(20, n(t["y"])); w(30, 0)
        w(40, n(t.get("h", 0.11))); w(1, str(t["t"]).upper())
    w(0, "ENDSEC"); w(0, "EOF")
    return "\n".join(out)


def generate_detail(criteria, params=None):
    """One-call API for the calculator: criteria -> selection + composed DXF.
    The approval label composed into the drawing NEVER claims HCAI approval."""
    sel = select_template(criteria)
    params = dict(params or {})
    params.setdefault("pipe_size", criteria.get("pipe_size", "4"))
    params.setdefault("brace_size", criteria.get("brace_member", "1"))
    params.setdefault("angle_degrees", criteria.get("angle_degrees", 45))
    params.setdefault("vertical_brace", criteria.get("vertical_brace", False))
    scene = compose(sel, params)
    title = sel["template"]["display_name"].upper()
    dxf = scene_to_dxf(scene, title=title, approval_label=sel["approval"]["label"])
    return {"selection": sel, "scene": scene, "dxf": dxf}
