# -*- coding: utf-8 -*-
"""Applicability, engineered alternatives, and the differential-movement
prohibition (18.1 cluster + 18.5.1.6 + 18.5.13)."""
from .traceability import rule

rule("SB-APPL-001", nfpa=["18.1", "18.1.1"], kind="validation",
     title="Chapter 18 applicability gate (seismic protection required for this system?)",
     status="condition_pending_prose",
     note="18.1.1 carries an 'unless' condition; the tool takes applicability as a project-level input meanwhile.")
rule("SB-APPL-002", nfpa=["18.1.2"], kind="exception",
     title="Engineered alternative to prescriptive seismic design (ASCE 7-based, PE-sealed)",
     status="delegated")
rule("SB-APPL-003", nfpa=["18.1.3"], kind="checklist",
     title="Seismic protection must not create obstructions to sprinklers",
     status="report_only")
rule("SB-APPL-004", nfpa=["18.5.1.6"], kind="exception",
     title="Sway-bracing not-apply carve-out",
     status="condition_pending_prose")
rule("SB-APPL-005", nfpa=["18.5.13"], kind="validation",
     title="Braces must not attach piping to two structures with differential movement",
     status="report_only",
     note="Surfaced as a hard checklist question on every brace (attachment structure identity).")
