# -*- coding: utf-8 -*-
"""Pipe stands subject to earthquakes (18.8 cluster)."""
from .traceability import rule

rule("SB-STAND-001", nfpa=["18.8", "18.8.1"], kind="validation",
     title="Pipe-stand seismic design (PE-engineered)",
     status="delegated")
rule("SB-STAND-002", nfpa=["18.8.2"], kind="validation",
     title="Pipe-stand concrete anchors prequalification",
     status="delegated",
     note="ACI 355.2 per the index external_standards.")
