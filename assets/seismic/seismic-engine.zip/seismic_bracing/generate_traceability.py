# -*- coding: utf-8 -*-
"""Generate docs/SEISMIC_TRACEABILITY.md - the complete requirements matrix.

Joins the rule registry against the pinned Chapter 18 index so that EVERY
identifier (169 sections, 37 tables, 1 figure, 1 equation) receives a
disposition. Auto-disposition precedence for identifiers not cited by any rule:
delegated (external standards / PE / AHJ) > condition_pending_prose (in
condition_index) > deferred (phase-2/3 routing).

Run:  python -m seismic_bracing.generate_traceability
"""
from __future__ import annotations

from collections import defaultdict
from pathlib import Path

import seismic_bracing  # noqa: F401  - registers all rules
from .traceability import (all_rules, condition_sections, delegated_sections,
                           index_identifiers, load_index)

OUT_PATH = Path(__file__).resolve().parent.parent / "docs" / "SEISMIC_TRACEABILITY.md"


def build_matrix():
    idx = load_index()
    rules = all_rules()
    conditions = condition_sections()
    delegated = delegated_sections()

    cited = defaultdict(list)           # identifier -> [rule_id]
    for r in rules.values():
        for nid in r.nfpa_ids:
            cited[nid].append(r.rule_id)

    rows = []
    # sections
    for s in idx["sections"]:
        sid = s["section"]
        rule_ids = cited.get(sid, [])
        if rule_ids:
            statuses = {rules[rid].status for rid in rule_ids}
            disposition = sorted(statuses)[0] if len(statuses) == 1 else "; ".join(sorted(statuses))
        elif sid in delegated:
            disposition = "delegated(auto: " + ", ".join(delegated[sid]) + ")"
        elif sid in conditions:
            disposition = "condition_pending_prose(auto: " + ",".join(conditions[sid]) + ")"
        else:
            disposition = "deferred(phase-2)"
        rows.append({
            "id": sid, "type": "section",
            "title": s.get("explicit_title") or ",".join(s.get("keyword_tags") or []) or "-",
            "conditions": ",".join(conditions.get(sid, [])) or "-",
            "rules": ", ".join(rule_ids) or "-",
            "disposition": disposition,
        })
    # tables / figure / equation
    for t in idx["tables"]:
        tid = "Table " + t["table"]
        rule_ids = cited.get(tid, [])
        rows.append({"id": tid, "type": "table", "title": (t.get("title") or "")[:70],
                     "conditions": "-", "rules": ", ".join(rule_ids) or "-",
                     "disposition": (rules[rule_ids[0]].status if rule_ids else "source_data_required")})
    for f in idx["figures"]:
        fid = "Figure " + f["figure"]
        rule_ids = cited.get(fid, [])
        rows.append({"id": fid, "type": "figure", "title": f.get("title", "")[:70],
                     "conditions": "-", "rules": ", ".join(rule_ids) or "-",
                     "disposition": (rules[rule_ids[0]].status if rule_ids else "source_data_required")})
    for e in idx["equations"]:
        eid = "Equation " + e["equation_label"]
        rule_ids = cited.get(eid, [])
        rows.append({"id": eid, "type": "equation", "title": e.get("implementation_purpose", "")[:70],
                     "conditions": "-", "rules": ", ".join(rule_ids) or "-",
                     "disposition": (rules[rule_ids[0]].status if rule_ids else "source_data_required")})
    return rows


def write_matrix(rows=None):
    rows = rows or build_matrix()
    counts = defaultdict(int)
    for r in rows:
        counts[r["disposition"].split("(")[0]] += 1
    lines = [
        "# NFPA 13 (2025) Chapter 18 - Seismic Bracing Traceability Matrix",
        "",
        "**GENERATED - do not edit.** `python -m seismic_bracing.generate_traceability`",
        "regenerates this file from the rule registry + the pinned index",
        "(`data/seismic_bracing/nfpa13_2025/ch18_index.json`).",
        "",
        "Disposition summary: " + ", ".join(f"{k}: {v}" for k, v in sorted(counts.items())),
        "",
        "| Identifier | Type | Title/tags | Condition signals | Rules | Disposition |",
        "|---|---|---|---|---|---|",
    ]
    for r in rows:
        lines.append(f"| {r['id']} | {r['type']} | {r['title']} | {r['conditions']} | {r['rules']} | {r['disposition']} |")
    OUT_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return OUT_PATH, len(rows), dict(counts)


if __name__ == "__main__":
    path, n, counts = write_matrix()
    print(f"wrote {path} ({n} identifiers)")
    for k, v in sorted(counts.items()):
        print(f"  {k}: {v}")
