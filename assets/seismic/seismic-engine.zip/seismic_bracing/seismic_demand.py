# -*- coding: utf-8 -*-
"""Horizontal seismic demand (18.5.9 cluster).

Implemented: zone-of-influence weight aggregation and Fpw = Cp x Wp (the symbols
Fpw, Cp, Wp are the calculation symbols the index records for 18.5.9.5).
Cp itself is either user-supplied (like TOLBrace's G-factor entry) or resolved
from the cp_determination dataset once that is filled from 18.5.9.3.x
(SOURCE_DATA_REQUIRED until then). The weight allowance factor applied to Wp is
dataset-backed (zoi_allowance, 18.5.9.5) - it is NOT hardcoded.

Riser-nipple / branch-line screening (Equation 18.5.9.6.2) is a separate
calculation per instruction #8; its expression is not in the index and is
SOURCE_DATA_REQUIRED - the function raises until the equation dataset is filled.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .datasets import SourceDataRequired, load_slot
from .traceability import rule
from .units import IMPERIAL, Qty, require_same_system

rule("SB-DEMAND-001", nfpa=["18.5.9.5"], kind="formula",
     title="Horizontal seismic force on brace: Fpw = Cp x Wp",
     status="implemented",
     note="Symbols per index calculation_symbols for 18.5.9.5; Wp assembled from the zone of influence.")
rule("SB-DEMAND-002", nfpa=["18.5.1.5", "18.5.5.2.3", "18.5.5.2.4", "18.5.9.7"], kind="input",
     title="Zone-of-influence pipe inventory (main + branch lines + drops) feeding Wp",
     status="implemented",
     note="Aggregation machinery; the normative ZOI boundary definitions surface as report checklist items until prose-backed.")
rule("SB-DEMAND-003", nfpa=["18.5.9.2"], kind="table_lookup",
     title="Wp = 1.15 x weight of water-filled piping (allowance factor)",
     status="implemented",
     note="FILLED zoi_allowance dataset. Actual source is 18.5.9.2 (the scaffold's 18.5.9.5 guess was corrected during extraction); explicit override still accepted and recorded.")
rule("SB-DEMAND-004", nfpa=["18.5.9.3", "18.5.9.3.1", "18.5.9.3.2", "18.5.9.3.3", "18.5.9.3.4"],
     kind="formula", title="Seismic coefficient Cp = 0.754 x SDS (with permitted height-based multipliers)",
     status="implemented",
     condition_resolution="The 18.5.9.3.1/.3.2 conditions (SDS from AHJ or the ASCE 7 Hazard Tool; "
                          "default site soil class unless the 18.5.9.3.2.1 site-class permission is "
                          "used) govern how SDS is DETERMINED - upstream of this engine, which takes "
                          "SDS as an explicit recorded input. The .3.3/.3.4 height-based multiplier "
                          "permissions are opt-in arguments validated against the published values, "
                          "never applied automatically.",
     note="FILLED cp_determination dataset - 2025 uses SDS (not Ss).")
rule("SB-DEMAND-005", nfpa=["18.5.9.1", "18.5.9.2", "18.5.9.4"], kind="validation",
     title="Alternative seismic-load determinations (ASCE 7 / AHJ-approved methods)",
     status="delegated",
     note="Surfaced on the report as an outside-input line item; never auto-passed.")
rule("SB-DEMAND-006", nfpa=["Equation 18.5.9.6.2", "18.5.9.6", "18.5.9.6.1", "18.5.9.6.2"],
     kind="formula", title="Riser-nipple / individual branch-line screening: 1.65*(Hr*Wp*Cp)/S vs Fy",
     status="implemented",
     condition_resolution="The except/unless structure of 18.5.9.6/.6.1 IS this screening: the "
                          "equation's published acceptance criterion decides whether individual "
                          "longitudinal branch-line evaluation and bracing is triggered. The "
                          "evaluator returns triggered=true/false with the published acceptance "
                          "text and never skips the branch-line requirement silently - the "
                          "applies_when trigger from the FILLED dataset is reported alongside.",
     note="Separate screening calc (instruction #8); the evaluator verifies the stored expression's structure before computing.")


@dataclass(frozen=True)
class PipeRun:
    """One piping contribution to a brace's zone of influence."""
    label: str
    weight_per_ft: Qty       # water-filled, lb/ft (imperial) or kg/m (metric)
    length_ft: float         # length attributed to this brace's ZOI


@dataclass
class ZoneOfInfluence:
    runs: list = field(default_factory=list)
    concentrated_lb: float = 0.0   # valves etc., same system as runs

    def add(self, label, weight_per_ft: Qty, length_ft: float):
        self.runs.append(PipeRun(label, weight_per_ft, length_ft))
        return self


def zone_weight(zoi: ZoneOfInfluence, allowance_factor: float | None = None,
                edition: str = "2025") -> Qty:
    """Wp for the zone of influence. allowance_factor=None means: resolve from
    the edition's zoi_allowance dataset (raises SourceDataRequired if unfilled).
    Pass an explicit factor to override (recorded by the caller for the report)."""
    if not zoi.runs:
        raise ValueError("zone of influence has no pipe runs")
    require_same_system(*[r.weight_per_ft for r in zoi.runs])
    system = zoi.runs[0].weight_per_ft.system
    base = sum(r.weight_per_ft.value * r.length_ft for r in zoi.runs) + zoi.concentrated_lb
    if allowance_factor is None:
        slot = load_slot("zoi_allowance.json", edition=edition)
        allowance_factor = float(slot["factor"])
    unit = "lb" if system == IMPERIAL else "kg"
    return Qty(base * allowance_factor, unit, system)


def horizontal_seismic_force(cp: float, wp: Qty) -> Qty:
    """Fpw = Cp x Wp (18.5.9.5)."""
    if cp <= 0:
        raise ValueError("Cp must be positive")
    unit = "lb" if wp.system == IMPERIAL else "N-equivalent-mass"
    if wp.system == IMPERIAL and wp.unit != "lb":
        raise ValueError(f"imperial Wp must be lb, got {wp.unit}")
    return Qty(cp * wp.value, unit, wp.system)


import re as _re

_CP_FORMULA_RE = _re.compile(r"Cp\s*=\s*([0-9.]+)\s*\*\s*SDS", _re.IGNORECASE)


def seismic_coefficient(sds: float, height_multiplier: float | None = None) -> float:
    """Cp per the FILLED cp_determination dataset (2025: Cp = 0.754 x SDS).
    height_multiplier, if given, must be one of the published permitted values
    (attachment-height reductions) - anything else is rejected."""
    slot = load_slot("cp_determination.json")
    m = _CP_FORMULA_RE.search(str(slot.get("formula", "")))
    if not m:
        raise SourceDataRequired("18.5.9.3",
                                 f"cp_determination formula shape changed: {slot.get('formula')!r}")
    if sds <= 0:
        raise ValueError("SDS must be positive")
    cp = float(m.group(1)) * sds
    if height_multiplier is not None:
        permitted = {float(x) for x in _re.findall(r"0\.\d+", str(slot.get("floors_ceilings", "")))}
        if height_multiplier not in permitted:
            raise ValueError(f"height multiplier {height_multiplier} is not among the "
                             f"published permitted values {sorted(permitted)}")
        cp *= height_multiplier
    return cp


# Back-compat alias from the scaffold phase (2025 actually uses SDS, not Ss).
seismic_coefficient_from_ss = seismic_coefficient

_EQ_RE = _re.compile(
    r"^\s*([0-9.]+)\s*\*\s*\(\s*Hr\s*\*\s*Wp\s*\*\s*Cp\s*\)\s*/\s*S\s*>=\s*Fy\s*$")


def riser_nipple_screening(wp_lb: float, cp: float, hr_in: float, s_in3: float,
                           fy_psi: float) -> dict:
    """Equation 18.5.9.6.2 screening (instruction #8), evaluated from the FILLED
    equation dataset. The evaluator verifies the stored expression matches the
    expected structure before computing - a changed expression raises rather
    than silently computing the wrong thing."""
    slot = load_slot("equation_18_5_9_6_2.json")
    m = _EQ_RE.match(str(slot.get("expression", "")))
    if not m:
        raise SourceDataRequired("Equation 18.5.9.6.2",
                                 f"stored expression shape changed: {slot.get('expression')!r}")
    if min(wp_lb, cp, hr_in, s_in3, fy_psi) <= 0:
        raise ValueError("all screening inputs must be positive")
    value = float(m.group(1)) * (hr_in * wp_lb * cp) / s_in3
    return {
        "value_psi": value,
        "fy_psi": fy_psi,
        "triggered": value >= fy_psi,
        "acceptance": slot.get("acceptance", ""),
        "provenance": f"Equation 18.5.9.6.2 ({slot.get('expression')})",
    }
