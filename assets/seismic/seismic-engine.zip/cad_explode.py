"""Explode every block reference in a DWG/DXF into its primitive entities and
save a plain DXF - a no-AutoCAD equivalent of AutoCAD's XPLODE.

DWG input is converted to DXF first with the free ODA File Converter (no
AutoCAD, no Autodesk license). DXF input needs no external tool at all. Block
references are then exploded recursively (nested blocks included) with ezdxf,
so the result contains only lines, arcs, polylines, text, hatches, etc.
"""
from __future__ import annotations

import glob
import os
from collections import Counter
from pathlib import Path

# raised (as ValueError) when a DWG is dropped but the ODA File Converter isn't
# installed - the server turns this into a friendly "install the free converter"
# message. DXF input never hits this path.
ODA_MISSING = "ODA_MISSING"

_ODA_CACHE = {"path": None, "checked": False}


def locate_oda(force: bool = False) -> str | None:
    """Find the ODA File Converter exe in the usual install locations.

    A POSITIVE result is cached for the life of the process - the exe is not
    going to move mid-session. A NEGATIVE result is deliberately NOT cached:
    the user is very often installing the converter *right now*, in response to
    our own "install this" prompt, and re-probing costs ~0.1 ms.

    Caching the miss is what made installing ODA appear to do nothing: the app
    kept reporting DXF-only until the whole process restarted, because the
    Reload button only reloads the web view, not this Python process.
    """
    if not force and _ODA_CACHE["checked"] and _ODA_CACHE["path"]:
        return _ODA_CACHE["path"]
    found: list[str] = []
    for base in (r"C:\Program Files\ODA", r"C:\Program Files (x86)\ODA"):
        found += glob.glob(base + r"\*\ODAFileConverter.exe")
    found.sort(reverse=True)   # newest version folder first
    _ODA_CACHE["path"] = found[0] if found else None
    _ODA_CACHE["checked"] = True
    return _ODA_CACHE["path"]


def reset_oda_cache() -> None:
    """Forget the cached lookup so the next call probes the disk again."""
    _ODA_CACHE["path"] = None
    _ODA_CACHE["checked"] = False


def oda_available(force: bool = False) -> bool:
    return bool(locate_oda(force=force))


def _configure_odafc() -> bool:
    exe = locate_oda()
    if not exe:
        return False
    import ezdxf
    ezdxf.options.set("odafc-addon", "win_exec_path", exe)
    return True


def source_dxf_path(path: Path) -> Path | None:
    """The plain-DXF file that backs `path` for RAW tag parsing (annotative
    context data etc. that ezdxf drops on load): the file itself for DXF
    input, the ODA-written cache for DWG. Call _load_doc first for DWGs so
    the cache exists."""
    path = Path(path)
    if path.suffix.lower() == ".dwg":
        cached = path.with_name(path.stem + ".oda2.dxf")
        return cached if cached.exists() else None
    return path if path.exists() else None


def _load_doc(path: Path):
    """Load an ezdxf Document from a DWG (via ODA, cached) or DXF file.

    The cache is ODA's own DXF output kept verbatim (suffix .oda2.dxf) — the
    old flow re-serialized through ezdxf (doc.saveas), which silently dropped
    objects ezdxf doesn't model (annotative SCALE context data, etc.). Old
    .oda.dxf caches are ignored."""
    import ezdxf
    suffix = path.suffix.lower()
    if suffix == ".dwg":
        cached = path.with_name(path.stem + ".oda2.dxf")
        if cached.exists():
            return ezdxf.readfile(str(cached))
        exe = locate_oda()
        if not exe:
            raise ValueError(ODA_MISSING)
        import shutil
        import subprocess
        import tempfile
        scratch = Path(tempfile.mkdtemp(prefix="sprinkflow-oda-"))
        in_dir = scratch / "in"
        out_dir = scratch / "out"
        in_dir.mkdir()
        out_dir.mkdir()
        try:
            shutil.copy2(path, in_dir / path.name)
            startupinfo = None
            creationflags = 0
            if os.name == "nt":   # no console window flash from the converter
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                creationflags = subprocess.CREATE_NO_WINDOW
            subprocess.run([exe, str(in_dir), str(out_dir), "ACAD2018", "DXF", "0", "1"],
                           capture_output=True, timeout=600,
                           startupinfo=startupinfo, creationflags=creationflags)
            produced = out_dir / (path.stem + ".dxf")
            if not produced.exists():
                raise ValueError("ODA File Converter did not produce a DXF.")
            try:
                shutil.copy2(produced, cached)   # keep ODA's DXF verbatim as the cache
                return ezdxf.readfile(str(cached))
            except OSError:
                return ezdxf.readfile(str(produced))   # read-only source folder: no cache
        finally:
            shutil.rmtree(scratch, ignore_errors=True)
    try:
        return ezdxf.readfile(str(path))
    except Exception:
        from ezdxf import recover
        doc, _auditor = recover.readfile(str(path))
        return doc


def _xref_blocks(doc) -> list:
    """Every block layout that is an attached XREF (not yet bound)."""
    out = []
    for block in doc.blocks:
        try:
            if block.block_record.is_xref:
                out.append(block)
        except Exception:
            continue
    return out


def _xref_load_fn(target: Path):
    """Loader for one xref target file - _load_doc handles DXF directly and
    DWG through ODA with the .oda2.dxf cache, so re-binding the same xrefs
    (analyze, then generate) converts each DWG only once."""
    return _load_doc(target)


def _resolve_xref_target(xref_path: str, search_dirs: list[Path]) -> Path | None:
    """Find the actual file an xref_path points at: absolute as-is, else by
    path/basename relative to each search dir (host folder first). Also tries
    the sibling .dxf for a .dwg reference so an ODA-less machine can still
    bind when a converted copy sits next to the host."""
    raw = Path(str(xref_path).strip().strip('"'))
    candidates = []
    if raw.is_absolute():
        candidates.append(raw)
    for base in search_dirs:
        candidates.append(base / raw)
        candidates.append(base / raw.name)
    more = []
    for cand in candidates:
        if cand.suffix.lower() == ".dwg":
            more.append(cand.with_suffix(".dxf"))
    for cand in candidates + more:
        try:
            if cand.exists():
                return cand
        except OSError:
            continue
    return None


def xref_search_dirs(path: Path) -> list[Path]:
    """Folders to look in when resolving xref paths: the drawing's own folder,
    its immediate subfolders (eTransmit drops references in 'SUPPORT FILES'),
    and the parent folder. Nested xrefs store paths relative to the file that
    references them, so the subfolders matter."""
    base = Path(path).parent
    dirs = [base]
    try:
        dirs += sorted(d for d in base.iterdir() if d.is_dir())
    except OSError:
        pass
    if base.parent != base:
        dirs.append(base.parent)
    return dirs


def bind_xrefs(doc, search_dirs: list[Path], include=None) -> dict:
    """Bind (embed) every attached XREF so its geometry becomes part of the
    drawing as a NORMAL block - the AutoCAD "XREF Bind" step - so the explode
    pass flattens xref content instead of dropping the references. Repeats
    because bound content can itself attach further xrefs.

    `include`: optional set of top-level xref names to bind (None = all).
    Nested references (ezdxf mangles their names to parent$0$child) always
    follow their parent - they only appear once the parent is embedded, and
    AutoCAD can't show a nested ref without its parent either."""
    from ezdxf.xref import embed
    bound: list[str] = []
    missing: list[dict] = []
    reported = set()
    for _round in range(8):
        todo = [b for b in _xref_blocks(doc)
                if b.name not in reported
                and (include is None or b.name in include or "$0$" in b.name)]
        if not todo:
            break
        for block in todo:
            name = block.name
            reported.add(name)
            xref_path = block.block.dxf.get("xref_path", "") or ""
            target = _resolve_xref_target(xref_path, search_dirs)
            if target is None:
                missing.append({"name": name, "path": xref_path,
                                "reason": "file not found next to the drawing"})
                continue
            try:
                # embed() re-resolves xref_path itself (and raises before
                # calling load_fn if it can't find it) - point it straight at
                # our RESOLVED absolute target, then load that same target.
                block.block.dxf.xref_path = str(target)
                embed(block, load_fn=lambda _fname, t=target: _xref_load_fn(t))
                bound.append(name)
            except ValueError as error:
                if str(error) == ODA_MISSING:
                    missing.append({"name": name, "path": xref_path,
                                    "reason": "DWG xref needs the free ODA File Converter"})
                else:
                    missing.append({"name": name, "path": xref_path, "reason": str(error)[:120]})
            except Exception as error:
                missing.append({"name": name, "path": xref_path, "reason": str(error)[:120]})
    return {"xrefsBound": bound, "xrefsMissing": missing}


def analyze(path: Path) -> dict:
    """Report what's in the drawing before exploding anything."""
    doc = _load_doc(path)
    msp = doc.modelspace()
    inserts = list(msp.query("INSERT"))
    names = Counter((i.dxf.name or "?") for i in inserts)
    top = [{"name": name, "count": count} for name, count in names.most_common(15)]
    xrefs = []
    for block in _xref_blocks(doc):
        xref_path = block.block.dxf.get("xref_path", "") or ""
        resolvable = _resolve_xref_target(xref_path, [path.parent]) is not None
        xrefs.append({"name": block.name, "path": xref_path, "resolvable": resolvable})
    return {
        "isDwg": path.suffix.lower() == ".dwg",
        "blockRefs": len(inserts),
        "uniqueBlocks": len(names),
        "entities": len(list(msp)),
        "topBlocks": top,
        "dxfVersion": doc.dxfversion,
        "xrefs": xrefs,
    }


def _explode_all(doc) -> dict:
    """Recursively explode every INSERT in model space into primitives."""
    msp = doc.modelspace()
    before = len(list(msp))
    ref_count = len(msp.query("INSERT"))
    rounds = 0
    exploded = 0
    dropped = 0
    while True:
        inserts = list(msp.query("INSERT"))
        if not inserts:
            break
        rounds += 1
        for ins in inserts:
            try:
                ins.explode()   # applies position/scale/rotation; ATTRIB -> TEXT
                exploded += 1
            except Exception:
                # xref references and unresolved blocks can't explode - drop the
                # reference so the loop still converges (AutoCAD's XPLODE can't
                # explode an xref either).
                try:
                    msp.delete_entity(ins)
                    dropped += 1
                except Exception:
                    pass
        if rounds > 60:   # safety valve against a pathological cycle
            break
    return {
        "before": before,
        "after": len(list(msp)),
        "blockRefs": ref_count,
        "exploded": exploded,
        "dropped": dropped,
        "remaining": len(msp.query("INSERT")),
        "rounds": rounds,
    }


def convert(path: Path):
    """Load, bind every resolvable xref, explode every block, and return
    (ezdxf_doc, stats). The caller picks a save location and calls
    ``doc.saveas``."""
    doc = _load_doc(path)
    bind_stats = bind_xrefs(doc, xref_search_dirs(path))
    stats = _explode_all(doc)
    stats.update(bind_stats)
    return doc, stats
