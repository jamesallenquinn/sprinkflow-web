"""Local fire-sprinkler plan scanning - text extraction, project-info
inference, and catalog-term matching. Extracted from server.py so the SAME
code runs on desktop AND in the browser (Pyodide). Pure text processing:
pypdf + regex only - NO cloud, NO AI, NO OS access.

The OCR fallback for scanned/raster plans stays desktop-side; callers inject
it through analyze_plan_core(ocr_hooks=...). KEEP THIS MODULE PURE.
"""
from __future__ import annotations

import re
from pathlib import Path

from pypdf import PdfReader


# Copied verbatim from tools/build_datasheet_catalog.py so the web bundle
# doesn't drag in the catalog build tooling. Keep in sync (they are stable).
def clean_text(value: str) -> str:
    value = value.replace("®", "").replace("™", "").replace("°", " Degree ")
    value = re.sub(r"[_]+", " ", value)
    value = re.sub(r"\s+", " ", value)
    return value.strip(" .-_")


def title_case(value: str) -> str:
    keep_upper = {"CPVC", "UL", "FM", "FDC", "IPS", "NPT", "OSY", "AOSY", "RPDA"}
    words = []
    for word in value.split():
        clean = word.strip()
        if clean.upper() in keep_upper:
            words.append(clean.upper())
        elif re.fullmatch(r"[A-Z0-9-]+", clean):
            words.append(clean)
        else:
            words.append(clean[:1].upper() + clean[1:].lower())
    return " ".join(words)

def extract_pdf_text(path: Path, max_pages: int = 3) -> tuple[str, int]:
    try:
        reader = PdfReader(str(path))
        chunks = []
        for page in reader.pages[:max_pages]:
            chunks.append(page.extract_text() or "")
        return "\n".join(chunks), len(reader.pages)
    except Exception:
        return "", 0

def choose_plan_project(title_project: dict, full_project: dict) -> dict:
    if title_project.get("name") and title_project.get("addressLooksValid"):
        return title_project
    if full_project.get("labelEvidence") and (full_project.get("name") or full_project.get("address")):
        return full_project
    if title_project.get("name") or title_project.get("address"):
        project = dict(title_project)
        if not project.get("name") and full_project.get("name"):
            project["name"] = full_project["name"]
        if not project.get("address") and full_project.get("address"):
            project["address"] = full_project["address"]
        if not project.get("projectNameCandidates") and full_project.get("projectNameCandidates"):
            project["projectNameCandidates"] = full_project["projectNameCandidates"]
        return project
    return full_project

def normalize_plan_scan_options(scan_options: dict | None) -> dict:
    incoming = scan_options if isinstance(scan_options, dict) else {}
    return {
        "sprinklers": incoming.get("sprinklers") is not False,
        "piping": incoming.get("piping") is not False,
        "hangers": incoming.get("hangers") is not False,
        "bracing": incoming.get("bracing") is not False,
        "valves": incoming.get("valves") is not False,
        "miscellaneous": incoming.get("miscellaneous") is not False,
    }

def correct_detected_project_name(name: str, file_name: str) -> str:
    clean_name = name or ""
    filename_guess = project_name_from_filename(file_name)
    if re.search(r"standard plumbing addition", file_name, re.IGNORECASE):
        return "Standard Plumbing Addition"
    if re.search(r"riverbank\s+fire\s+pump", file_name, re.IGNORECASE):
        return "Riverbank Fire Pump"
    if re.search(r"plaza hotel", file_name, re.IGNORECASE) and re.search(r"\baza\s+hotel\b", clean_name, re.IGNORECASE):
        return "Plaza Hotel Remodel"
    if (
        is_meaningful_filename_project_name(filename_guess)
        and clean_name
        and filename_similarity_score(clean_name, filename_guess) == 0
        and re.search(r"\b(victaulic|flange|adapter|coupling|grooved|pipe|piping|valve|fitting|hanger|brace|bracing)\b", clean_name, re.IGNORECASE)
    ):
        return filename_guess
    if is_meaningful_filename_project_name(filename_guess) and not clean_name:
        return filename_guess
    return clean_name

def looks_like_encoded_pdf_text(text: str) -> bool:
    if not text:
        return False
    encoded_tokens = re.findall(r"/\d{1,4}\b", text)
    cid_tokens = re.findall(r"\(cid:\d+\)", text)
    readable_words = re.findall(r"\b[A-Za-z]{3,}\b", text)
    encoded_count = len(encoded_tokens) + len(cid_tokens)
    return encoded_count > 120 and encoded_count > max(80, len(readable_words) * 4)

def infer_plan_contractor(text: str) -> dict:
    lines = normalize_plan_lines(text)
    best = ({}, -100)
    contractor_pattern = re.compile(r"\b([A-Z][A-Za-z0-9&.' -]{1,70}?\s+(?:Fire Protection|Fire Systems|Fire Services|Fire Suppression))\b", re.IGNORECASE)
    for index, line in enumerate(lines):
        match = contractor_pattern.search(line)
        if not match:
            continue
        name = " ".join(match.group(1).split())
        if re.search(r"\b(sole property|property of|reproduction|drawings?|attachments?)\b", name, re.IGNORECASE):
            continue
        nearby = lines[index : min(len(lines), index + 8)]
        block = "\n".join(nearby)
        phone_match = re.search(r"(?:\+?1[\s.-]?)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}", block)
        license_match = re.search(r"\b(?:C[-\s]?16|LIC(?:ENSE)?\.?\s*#?|LIC(?:ENSE)?\s*NO\.?)\s*[:#-]?\s*([A-Z]{0,3}\d{5,8})\b", block, re.IGNORECASE)
        address = find_best_plan_address(nearby) or find_plan_address(block)
        if address and not (phone_match or license_match):
            address = ""
        score = 5
        if phone_match:
            score += 2
        if license_match:
            score += 2
        if address:
            score += 2
        if score > best[1]:
            best = (
                {
                    "name": format_company_name(name),
                    "address": address,
                    "license": license_match.group(1) if license_match else "",
                    "phone": phone_match.group(0) if phone_match else "",
                    "source": "plans",
                    "confidence": "high" if score >= 9 else "medium",
                },
                score,
            )
    for index, line in enumerate(lines):
        if not re.search(r"\b(?:license|lic\.?|phone|\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4})\b", line, re.IGNORECASE):
            continue
        nearby = lines[max(0, index - 5) : min(len(lines), index + 5)]
        block = "\n".join(nearby)
        phone_match = re.search(r"(?:\+?1[\s.-]?)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}", block)
        license_match = re.search(
            r"\b(?:[A-Za-z]+\s+)?(?:C[-\s]?16|LIC(?:ENSE)?\.?\s*(?:NUMBER|NO\.?)?|LIC(?:ENSE)?\s*#?)\s*[:#-]?\s*([A-Z]{2,6}[-\s]?\d{2,8}|[A-Z]{0,3}\d{5,8})\b",
            block,
            re.IGNORECASE,
        )
        address = find_best_plan_address(nearby) or find_plan_address(block)
        score = 0
        if phone_match:
            score += 2
        if license_match:
            score += 3
        if address:
            score += 3
        if score > best[1] and score >= 5:
            best = (
                {
                    "name": "",
                    "address": address,
                    "license": license_match.group(1).replace(" ", "-").upper() if license_match else "",
                    "phone": phone_match.group(0) if phone_match else "",
                    "source": "plans contact block",
                    "confidence": "medium",
                },
                score,
            )
    return best[0]

def format_company_name(value: str) -> str:
    value = re.sub(r"\s+", " ", value or "").strip(" -:")
    if value and value.upper() == value:
        return title_case(value)
    return value

def infer_plan_sprinkler_legend(text: str) -> list[dict]:
    lines = normalize_plan_lines(text, dedupe=False)
    records = parse_sprinkler_legend_tables(lines)
    for line in lines:
        if not looks_like_sprinkler_legend_line(line):
            continue
        record = sprinkler_record_from_line(line)
        if record:
            records.append(record)
    return prune_loose_sprinkler_records(dedupe_sprinkler_records(records))[:30]

def looks_like_sprinkler_legend_line(line: str) -> bool:
    return bool(
        re.search(r"\b(sprinkler|viking|victaulic|tyco|reliable|senju|globe|vk\d+|ra\d+|f1fr\d+|ty[-\w]+|v\d{3,4}|qr|sr|fr|upright|pendent|sidewall|esfr|coin|k[- ]?fac)\b", line, re.IGNORECASE)
        and not re.search(r"\b(detail|general note|hydraulic|calculation|sheet index)\b", line, re.IGNORECASE)
    )

def sprinkler_record_from_line(line: str) -> dict:
    if re.fullmatch(r"(?:automatic\s+fire\s+)?sprinkler\s+legend|project total sprinkler schedule", line.strip(), re.IGNORECASE):
        return {}
    if re.search(r"\bsymbol\b.*\b(model|sin|k[- ]?factor|k[- ]?fac|response|resp)\b", line, re.IGNORECASE):
        return {}
    manufacturer = infer_plan_sprinkler_manufacturer(line)
    model = infer_plan_sprinkler_model(line)
    k_factor = infer_plan_k_factor(line)
    response = infer_plan_response(line)
    orientation = infer_plan_orientation(line)
    sprinkler_type = infer_plan_sprinkler_type(line)
    if not any([model, k_factor, response, orientation, sprinkler_type]):
        return {}
    confidence = "exact" if model else "criteria"
    return {
        "manufacturer": manufacturer,
        "model": model,
        "kFactor": k_factor,
        "response": response,
        "orientation": orientation,
        "type": sprinkler_type,
        "sourceLine": line[:220],
        "confidence": confidence,
    }

def infer_plan_sprinkler_manufacturer(line: str) -> str:
    aliases = {
        "Viking": [r"Viking"],
        "Victaulic": [r"Victaulic"],
        "Tyco": [r"Tyco"],
        "Reliable": [r"Reliable"],
        "Senju": [r"Senju(?:\s+Sprinkler)?"],
        "Globe": [r"Globe"],
    }
    for manufacturer, patterns in aliases.items():
        if any(re.search(rf"\b{pattern}\b", line, re.IGNORECASE) for pattern in patterns):
            return manufacturer
    return ""

def canonical_plan_sprinkler_manufacturer(value: str) -> str:
    return infer_plan_sprinkler_manufacturer(value) or format_company_name(value)

def is_plan_sprinkler_manufacturer(value: str) -> bool:
    return bool(infer_plan_sprinkler_manufacturer(value))

def infer_plan_sprinkler_model(line: str) -> str:
    patterns = [
        r"\bVK\d{2,5}[A-Z0-9/-]*\b",
        r"\bR[A-Z]?\d{4}\b",
        r"\bRA\d{3,5}[A-Z0-9/-]*\b",
        r"\bF\dFR\d+[A-Z0-9/-]*\b",
        r"\bRFC\d+[A-Z0-9/-]*\b",
        r"\bTY\d{3,5}[A-Z0-9/-]*\b",
        r"\bTY-[A-Z0-9/-]+(?:\s*[A-Z0-9/-]+)?\b",
        r"\bV\d{3,4}[A-Z0-9/-]*\b",
        r"\bSS\d{3,5}\b",
        r"\bRC[-A-Z0-9/]+",
        r"\bFL-[A-Z0-9/]+",
    ]
    for pattern in patterns:
        match = re.search(pattern, line, re.IGNORECASE)
        if match:
            model = match.group(0).upper().replace(" ", "")
            if model in {"TYPESIZE", "SYMBOL", "MODEL"}:
                continue
            return model
    return ""

def parse_sprinkler_legend_tables(lines: list[str]) -> list[dict]:
    records = []
    header_pattern = re.compile(
        r"^(?:symbol|symb\.?|manufacturer|mfr|sin|model|model\s*/\s*s\.?i\.?n\.?|quantity|quant\.?|qty\.?|count|k[- ]?factor|k[- ]?fac|type|style|size|response|resp\.?|finish|temperature|temp\.?|note|sprinkler orientation)$",
        re.IGNORECASE,
    )
    stop_pattern = re.compile(r"^(?:total\b|revision\b|drawing index\b|project design data\b|job number\b|scale\b|building section\b)", re.IGNORECASE)

    for index, line in enumerate(lines):
        if not re.fullmatch(r"(?:automatic\s+fire\s+)?sprinkler\s+legend|project total sprinkler schedule", line.strip(), re.IGNORECASE):
            continue
        tokens = []
        for candidate in lines[index + 1 : index + 120]:
            if stop_pattern.search(candidate) and tokens:
                break
            if header_pattern.fullmatch(candidate.strip()):
                continue
            if candidate.strip() in {"˝", "½", "1/2", "1", "~"}:
                continue
            if re.fullmatch(r"\d{1,3}(?:°F?)?", candidate.strip(), re.IGNORECASE) and not tokens:
                continue
            tokens.append(candidate.strip())

        cursor = 0
        while cursor < len(tokens):
            if not is_plan_sprinkler_manufacturer(tokens[cursor]):
                cursor += 1
                continue
            start = cursor
            manufacturer = canonical_plan_sprinkler_manufacturer(tokens[cursor])
            cursor += 1
            row = [manufacturer]
            while cursor < len(tokens) and not is_plan_sprinkler_manufacturer(tokens[cursor]):
                if stop_pattern.search(tokens[cursor]):
                    break
                row.append(tokens[cursor])
                cursor += 1
            record = sprinkler_record_from_table_row(row)
            if record:
                records.append(record)
            if cursor == start:
                cursor += 1
    return records

def sprinkler_record_from_table_row(row: list[str]) -> dict:
    if len(row) < 4:
        return {}
    manufacturer = infer_plan_sprinkler_manufacturer(" ".join(row)) or row[0]
    model_candidates = []
    for value in row[1:]:
        model = infer_plan_sprinkler_model(value)
        if model and model not in model_candidates:
            model_candidates.append(model)
    model = model_candidates[0] if model_candidates else ""
    k_factor = next((infer_plan_k_factor(value) for value in row if infer_plan_k_factor(value)), "")
    response = next((infer_plan_response(value) for value in row if infer_plan_response(value)), "")
    orientation = infer_plan_orientation(" ".join(row))
    sprinkler_type = infer_plan_sprinkler_type(" ".join(row))
    if not any([model, k_factor, response, orientation, sprinkler_type]):
        return {}
    return {
        "manufacturer": manufacturer,
        "model": model,
        "modelCandidates": model_candidates,
        "kFactor": k_factor,
        "response": response,
        "orientation": orientation,
        "type": sprinkler_type,
        "sourceLine": " ".join(row)[:220],
        "confidence": "exact" if model else "criteria",
    }

def infer_plan_k_factor(line: str) -> str:
    match = re.search(r"\bK(?:-?FAC(?:TOR)?|[-\s])?\s*[:=]?\s*(\d{1,2}(?:\.\d+)?)\b", line, re.IGNORECASE)
    if not match:
        match = re.search(r"(?<![\d.])(2\.8|3\.7|4\.2|4\.9|5\.6|8\.0|8\.1|11\.2|14\.0|16\.8|19\.6|22\.4|25\.2)(?![\d.])", line)
    return match.group(1) if match else ""

def infer_plan_response(line: str) -> str:
    if re.search(r"\b(quick response|quick|qr)\b", line, re.IGNORECASE):
        return "Quick"
    if re.search(r"\b(fast response|fast|fr)\b", line, re.IGNORECASE):
        return "Fast"
    if re.search(r"\b(standard response|standard|sr)\b", line, re.IGNORECASE):
        return "Standard"
    return ""

def infer_plan_orientation(line: str) -> str:
    text = line.lower()
    terms = []
    checks = [
        ("horizontal sidewall", ["horizontal sidewall", "hsw", "sdwl"]),
        ("vertical sidewall", ["vertical sidewall", "vsw"]),
        ("sidewall", ["sidewall"]),
        ("concealed pendent", ["concealed pendent", "concealed dry-pendent", "rdp", "fdp"]),
        ("dry pendent", ["dry pendent", "dry-pendent"]),
        ("dry upright", ["dry upright", "dry-upright"]),
        ("pendent", ["pendent", "ssp", "rdp", "fdp"]),
        ("upright", ["upright", "ssu"]),
        ("recessed", ["recessed"]),
        ("concealed", ["concealed", "coin"]),
    ]
    for label, needles in checks:
        if any(re.search(rf"\b{re.escape(needle)}\b", text) for needle in needles):
            terms.append(title_case(label))
    return ", ".join(dict.fromkeys(terms))

def infer_plan_sprinkler_type(line: str) -> str:
    text = line.lower()
    if re.search(r"\besfr\b", text):
        return "ESFR"
    if re.search(r"\bextended coverage\b|\bec\b", text):
        return "Extended Coverage"
    if re.search(r"\bresidential\b|\b[A-Z]{2,4}-RES\b|\bRFC\d+", line, re.IGNORECASE):
        return "Residential"
    if re.search(r"\battic\b|\bcoin\b|\bspecial application\b|\bspecific application\b", text):
        return "Special Application"
    if re.search(r"\bcmsa\b", text):
        return "CMSA"
    return "Standard Coverage" if re.search(r"\bupright|pendent|sidewall|sprinkler\b", text) else ""

def dedupe_sprinkler_records(records: list[dict]) -> list[dict]:
    seen = set()
    result = []
    for record in records:
        key = tuple(normalize_text(record.get(field, "")) for field in ["manufacturer", "model", "kFactor", "response", "orientation", "type"])
        if key in seen:
            continue
        seen.add(key)
        result.append(record)
    return result

def prune_loose_sprinkler_records(records: list[dict]) -> list[dict]:
    contextual_models = {
        normalize_text(record.get("model", ""))
        for record in records
        if record.get("model") and record.get("manufacturer") and record.get("kFactor") and (record.get("orientation") or record.get("response"))
    }
    result = []
    for record in records:
        model_key = normalize_text(record.get("model", ""))
        has_context = bool(record.get("manufacturer") and record.get("kFactor") and (record.get("orientation") or record.get("response")))
        if model_key in contextual_models and not has_context:
            continue
        if is_broad_plan_sprinkler_family(record.get("model", "")) and not has_context:
            continue
        result.append(record)
    return result

def is_broad_plan_sprinkler_family(value: str) -> bool:
    return bool(re.fullmatch(r"(?:FL|RC)[-/A-Z0-9]*", value or "", re.IGNORECASE))

def infer_plan_pipe_types(text: str) -> list[dict]:
    checks = [
        ("CPVC", r"\bcpvc\b|\bblazemaster\b|\bflameguard\b"),
        ("C900", r"\bc[-\s]?900\b|\bblue brute\b"),
        ("Ductile Iron", r"\bductile iron\b|\bd\.?i\.?\b"),
        ("Sch. 10", r"\bsch(?:edule)?\.?\s*10\b"),
        ("Sch. 40", r"\bsch(?:edule)?\.?\s*40\b"),
        ("Sch. 10 / Sch. 40 Steel", r"\b(?:black\s+)?steel pipes?\b|\bsteel sprinkler pipes?\b"),
        ("Mega-Flow", r"\bmega[-\s]?flow\b"),
        ("Mega-Thread", r"\bmega[-\s]?thread\b"),
        ("Eddy-Flow", r"\beddy[-\s]?flow\b"),
        ("Eddy-Thread", r"\beddy[-\s]?thread\b"),
    ]
    results = []
    for label, pattern in checks:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            results.append({"pipeType": label, "sourceText": match.group(0)})
    return results

def infer_plan_catalog_terms(text: str, category: str) -> list[dict]:
    checks_by_category = {
        "Fittings": [
            ("Grooved Flexible Couplings", r"\b(?:grooved\s+)?flex(?:ible)?\s+couplings?\b|\bflex\s+couplings?\b"),
            ("Grooved Rigid Couplings - Push-On", r"\bpush[-\s]?on\b.{0,40}\bcouplings?\b|\bcouplings?\b.{0,40}\bpush[-\s]?on\b"),
            ("Grooved Rigid Couplings", r"\b(?:grooved\s+)?rigid\s+couplings?\b|\bcouplings?\b.{0,40}\brigid\b"),
            ("Grooved Fittings", r"\bgrooved fittings?\b|\bgrooved couplings?\b"),
            ("Mechanical Tee", r"\bmechanical tees?\b"),
            ("Threaded Fittings", r"\bthreaded fittings?\b|\b(?:ductile|cast|malleable)\s+iron\b.{0,50}\bthreaded\b|\bthreaded\b.{0,50}\b(?:ductile|cast|malleable)\s+iron\b"),
        ],
        "Hangers": [
            ("Beam Clamp", r"\bbeam clamps?\b"),
            ("All Thread Hanger", r"\ball[-\s]?thread\b.{0,40}\bhangers?\b"),
            ("Hanger Rod", r"\bhanger rods?\b|\bthreaded rods?\b"),
            ("Fig. 200", r"\bring hangers?\b"),
            ("Clevis Hanger", r"\bclevis hangers?\b"),
            ("Sammy", r"\bsammy\b"),
        ],
        "Bracing": [
            ("Lateral Brace", r"\blateral braces?\b|\blateral earthquake brac(?:e|ing)\b"),
            ("Longitudinal Brace", r"\blongitudinal braces?\b|\blongitudinal earthquake brac(?:e|ing)\b"),
            ("4-Way Brace", r"\b4[-\s]?way braces?\b|\bfour[-\s]?way braces?\b"),
            ("Branch Line Restraint", r"\bbranch line restraints?\b|\bblr\b"),
            ("Sway Brace", r"\bsway braces?\b"),
        ],
        "Valves": [
            ("Victaulic UMC Riser", r"\b(?:victaulic\s+)?umc\b|\buniversal manifold check\b"),
            ("Viking EasyPac Riser", r"\b(?:viking\s+)?easypac\b"),
            ("Riser Assembly", r"\briser assembl(?:y|ies)\b|\briser manifold\b"),
            ("Tamper Switch", r"\btamper switch(?:es)?\b|\bsupervisory switch(?:es)?\b"),
            ("Butterfly Valve", r"\bbutterfly valves?\b"),
            ("Check Valve", r"\bcheck valves?\b"),
            ("Gate Valve", r"\bgate valves?\b|\bos\s*&\s*y\b|\bosy\b|\bnrs\b"),
            ("Dry Pipe Valve", r"\bdry pipe valves?\b"),
            ("Deluge Valve", r"\bdeluge valves?\b"),
            ("Backflow", r"\bbackflow\b|\bdouble check\b|\brp(?:z)?\b"),
            ("Test N Drain", r"\btest\s*(?:and|n|&)\s*drain\b"),
            ("Air Vent", r"\bair vents?\b|\bautomatic air vents?\b"),
            ("Pressure Relief Valve", r"\bpressure relief valves?\b"),
        ],
        "Miscellaneous": [
            ("Alarm Bell", r"\balarm bells?\b|\bfire bells?\b|\bgong\b|\belectric bells?\b|\bwater motor gong\b"),
            ("Horn Strobe", r"\bhorn strobes?\b|\bstrobes?\b"),
            ("Head Cabinet", r"\bhead cabinets?\b|\bsprinkler cabinets?\b|\bspare sprinkler\b.{0,40}\bcabinets?\b"),
            ("Head Guard", r"\bhead guards?\b|\bsprinkler guards?\b"),
            ("Identification Signs", r"\bidentification signs?\b|\bsigns?\b"),
        ],
    }
    results = []
    seen = set()
    source = re.sub(r"\s+", " ", text or "")

    def add_result(label: str, source_text: str) -> None:
        key = normalize_text(label)
        if key in seen:
            return
        seen.add(key)
        results.append({
            "category": category,
            "term": label,
            "sourceText": source_text[:180],
        })

    if category in {"Hangers", "Bracing"}:
        fig_pattern = re.compile(r"\b(?:tolco\s+)?fig(?:ure)?\.?\s*([0-9]{1,4}[A-Z]?)\b", re.IGNORECASE)
        hanger_figs = {"2", "22", "23", "25", "28", "29", "51", "58", "65", "66", "67SS", "68SS", "69", "69R", "78", "130", "200", "200C", "200F", "200H", "200S", "B3033", "B3034", "B3037", "B3042T"}
        bracing_figs = {"4", "4A", "4L", "4LA", "6", "131", "800", "825", "825A", "828", "909", "906", "980", "980H", "1001", "3000"}
        target_figs = hanger_figs if category == "Hangers" else bracing_figs
        for match in fig_pattern.finditer(source):
            model = match.group(1).upper()
            if model in target_figs:
                add_result(f"Fig. {model}", match.group(0))
        if category == "Hangers":
            for match in re.finditer(r"\bB30(?:33|34|37|42T)\b", source, re.IGNORECASE):
                add_result(match.group(0).upper(), match.group(0))
        else:
            for match in re.finditer(r"\bAF0\d{2,3}\b", source, re.IGNORECASE):
                add_result(match.group(0).upper(), match.group(0))

    for label, pattern in checks_by_category.get(category, []):
        match = re.search(pattern, source, re.IGNORECASE)
        if not match:
            continue
        add_result(label, match.group(0))
    return results[:12]

def extract_title_block_text(path: Path) -> str:
    try:
        reader = PdfReader(str(path))
    except Exception:
        return ""

    chunks = []
    for page in reader.pages[:2]:
        try:
            box = page.mediabox
            width = float(box.width)
            height = float(box.height)
            fragments = []

            def visitor(text, cm, tm, font_dict, font_size):
                clean = " ".join((text or "").split())
                if not clean:
                    return
                x = float(tm[4])
                y = float(tm[5])
                in_title_zone = (x >= width * 0.88 and y <= height * 0.75) or (x >= width * 0.45 and y <= height * 0.22)
                if in_title_zone:
                    fragments.append((round(y, 1), round(x, 1), clean))

            page.extract_text(visitor_text=visitor)
            fragments.sort(key=lambda item: (-item[0], item[1]))
            chunks.append("\n".join(fragment[2] for fragment in fragments))
        except Exception:
            continue
    return "\n".join(chunks)

def hydratec_project_fields(lines: list[str]) -> dict:
    """HydraCalc/Hydratec calc sheets label project fields differently: "Job Name"
    is the project name and "Location" is the project address — with the CONTRACTOR'S
    letterhead above them, which the generic address finder latches onto. Only
    engages when a "Job Name" label is present (the Hydratec fingerprint)."""
    def labeled(label_pattern):
        pat = re.compile(r"^\s*" + label_pattern + r"\s*[:=\-]?\s*(.*)$", re.I)
        for index, line in enumerate(lines):
            match = pat.match(line)
            if not match:
                continue
            value = match.group(1).strip(" :-_|\t")
            if value:
                return re.sub(r"\s+", " ", value)
            for next_line in lines[index + 1:index + 3]:
                candidate = next_line.strip()
                if not candidate.startswith(":") and pat.match(candidate):
                    continue
                candidate = candidate.lstrip(" :=-").strip()
                if candidate and not re.match(r"^(?:drawing|contract|data\s+file|remote\s+area)\b", candidate, re.I):
                    return re.sub(r"\s+", " ", candidate)
                break
        return ""
    name = labeled(r"JOB\s+NAME")
    if not name:
        return {}
    return {"name": name, "address": labeled(r"LOCATION")}

def infer_project_info(text: str, source: str, pages: int, file_name: str = "") -> dict:
    cleaned = text or ""
    lines = normalize_plan_lines(cleaned)
    address = find_best_plan_address(lines) or find_labeled_plan_address(lines) or find_address_near_project_label(lines) or find_plan_address(cleaned) or find_city_state_plan_address(lines)
    name_candidates = rank_project_name_candidates(lines, address, file_name)
    labeled_name = next((entry["name"] for entry in name_candidates if "labeled field" in entry.get("reasons", [])), "")
    name = name_candidates[0]["name"] if name_candidates else ""
    hydratec = hydratec_project_fields(lines)
    if hydratec.get("name"):
        name = hydratec["name"]
        labeled_name = name
    if hydratec.get("address"):
        address = hydratec["address"]

    address_check = validate_plan_address(address)
    confidence_score = 0
    if name:
        confidence_score += 1
    if address_check["ok"]:
        confidence_score += 2
    elif address:
        confidence_score += 1
    if source == "title block":
        confidence_score += 1
    confidence = "high" if confidence_score >= 4 else "medium" if confidence_score >= 2 else "low"

    notes = []
    if address_check["message"]:
        notes.append(address_check["message"])
    if not name:
        notes.append("Project name was not confidently detected.")
    if not address:
        notes.append("Project address was not detected.")

    return {
        "name": name,
        "address": address,
        "addressLooksValid": address_check["ok"],
        "confidence": confidence,
        "source": source,
        "labelEvidence": bool(labeled_name),
        "projectNameCandidates": name_candidates[:6],
        "pagesScanned": min(pages or 0, 4),
        "notes": notes,
        "textPreview": "\n".join(lines[:18]),
    }

def normalize_plan_lines(text: str, dedupe: bool = True) -> list[str]:
    seen = set()
    lines = []
    for raw in text.splitlines():
        line = re.sub(r"\s+", " ", raw).strip(" -:\t")
        if len(line) < 2:
            continue
        key = normalize_text(line)
        if not key or (dedupe and key in seen):
            continue
        seen.add(key)
        lines.append(line)
    return lines

def find_labeled_plan_address(lines: list[str]) -> str:
    for index, line in enumerate(lines):
        if re.search(r"\b(project\s*)?(address|location|site address)\b", line, flags=re.IGNORECASE):
            inline = find_plan_address(line)
            if inline:
                return inline
            for candidate in lines[index + 1 : index + 4]:
                address = find_plan_address(candidate)
                if address:
                    return address
    return ""

def find_address_near_project_label(lines: list[str]) -> str:
    for index, line in enumerate(lines):
        if re.fullmatch(r"project|project name|project title|job name|site name", line, flags=re.IGNORECASE):
            for candidate in lines[index + 1 : index + 7]:
                address = find_plan_address(candidate)
                if address:
                    return address
    return ""

def rank_project_name_candidates(lines: list[str], address: str, file_name: str = "") -> list[dict]:
    candidates: dict[str, dict] = {}
    line_counts: dict[str, int] = {}
    line_first_index: dict[str, int] = {}
    file_candidate = project_name_from_filename(file_name)
    file_key = normalize_text(file_candidate)

    def add(raw_value: str, reason: str, base_score: int = 0, index: int | None = None) -> None:
        value = format_project_name(raw_value)
        if not is_project_name_candidate(value):
            return
        key = normalize_text(value)
        if not key:
            return
        entry = candidates.setdefault(
            key,
            {
                "name": value,
                "score": 0,
                "reasons": [],
                "count": 0,
                "firstIndex": index if index is not None else 9999,
            },
        )
        entry["score"] += base_score + score_project_name_candidate(value)
        entry["count"] += 1
        if reason not in entry["reasons"]:
            entry["reasons"].append(reason)
        if index is not None:
            entry["firstIndex"] = min(entry.get("firstIndex", 9999), index)

    for index, line in enumerate(lines):
        value = clean_plan_project_name(line)
        if not is_project_name_candidate(value):
            continue
        key = normalize_text(format_project_name(value))
        line_counts[key] = line_counts.get(key, 0) + 1
        line_first_index.setdefault(key, index)

    if file_candidate:
        add(file_candidate, "PDF filename", 44 if is_meaningful_filename_project_name(file_candidate) else 10, 0)

    for index, line in enumerate(lines):
        labeled = project_name_from_labeled_line(line)
        if labeled:
            add(labeled, "labeled field", 24, index)
        if re.fullmatch(r"project|project name|project title|job name|site name", line.rstrip(":"), flags=re.IGNORECASE):
            for offset, candidate in enumerate(lines[index + 1 : index + 5], start=1):
                add(candidate, "labeled field", 24 - offset, index + offset)

    for candidate in project_names_near_address(lines, address):
        add(candidate["name"], "near address", candidate["score"], candidate["index"])

    for candidate in project_names_near_sheet_title(lines):
        add(candidate["name"], "title sheet heading", candidate["score"], candidate["index"])

    for key, count in line_counts.items():
        if count < 2:
            continue
        name = next((line for line in lines if normalize_text(format_project_name(clean_plan_project_name(line))) == key), "")
        add(name, "repeated on sheets", min(18, count * 4), line_first_index.get(key, 9999))

    for index, line in enumerate(lines[:80]):
        add(line, "early title block text", max(0, 8 - index // 10), index)

    for entry in candidates.values():
        entry["score"] += filename_similarity_score(entry["name"], file_candidate)
        if file_candidate and filename_similarity_score(entry["name"], file_candidate) >= 8 and "matches filename" not in entry["reasons"]:
            entry["reasons"].append("matches filename")
        if entry.get("count", 0) >= 2:
            entry["score"] += min(12, entry["count"] * 2)
        if entry.get("firstIndex", 9999) <= 40:
            entry["score"] += 4
        if file_key and normalize_text(entry["name"]) == file_key:
            entry["score"] += 8
        if file_key and file_key in normalize_text(entry["name"]) and "near address" in entry.get("reasons", []):
            entry["score"] += 16

    ranked = sorted(candidates.values(), key=lambda item: (-item["score"], item.get("firstIndex", 9999), item["name"]))
    top_score = ranked[0]["score"] if ranked else 0
    ranked = [entry for entry in ranked if entry["score"] >= max(18, top_score - 30)]
    return [
        {
            "name": format_project_name(entry["name"]),
            "score": int(entry["score"]),
            "reasons": entry["reasons"][:4],
        }
        for entry in ranked[:10]
    ]

def project_name_from_labeled_line(line: str) -> str:
    match = re.match(r"^(?:project\s*name|project\s*title|job\s*name|site\s*name|project)\s*[:#-]\s*(.+)$", line, re.IGNORECASE)
    return clean_plan_project_name(match.group(1)) if match else ""

def project_names_near_address(lines: list[str], address: str) -> list[dict]:
    if not address:
        return []
    address_key = normalize_text(address)
    street_match = re.match(
        r"\d{1,6}(?:-\d{1,6})?\s+(?:[NSEW]\.?\s+)?[A-Za-z0-9.'#& -]+?\s+"
        r"(?:Street|St\.?|Avenue|Ave\.?|Road|Rd\.?|Drive|Dr\.?|Lane|Ln\.?|Boulevard|Blvd\.?|Way|Court|Ct\.?|Place|Pl\.?|Highway|Hwy\.?|Parkway|Pkwy\.?|Circle|Cir\.?|Loop|Terrace|Ter\.?|Trail|Trl\.?)(?:\s+\d{1,4})?(?=\W|$)",
        address,
        flags=re.IGNORECASE,
    )
    street_key = normalize_text(street_match.group(0) if street_match else address)
    results = []
    for index, line in enumerate(lines):
        line_key = normalize_text(line)
        if not line_key or (street_key not in line_key and not (len(line_key) > 8 and line_key in address_key)):
            continue
        before_candidates = []
        for offset, candidate in enumerate(reversed(lines[max(0, index - 8) : index]), start=1):
            value = clean_plan_project_name(candidate)
            if not is_project_name_candidate(value):
                continue
            before_candidates.append((value, index - offset, max(10, 26 - offset * 2)))
            if len(before_candidates) >= 4:
                break
        after_candidates = []
        for offset, candidate in enumerate(lines[index + 1 : index + 20], start=1):
            if re.fullmatch(r"revisions?", candidate.strip(), re.IGNORECASE):
                break
            value = clean_plan_project_name(candidate)
            if not is_project_name_candidate(value):
                continue
            after_candidates.append((value, index + offset, max(8, 22 - offset)))
            if len(after_candidates) >= 4:
                break
        before_values = [value for value, _, _ in reversed(before_candidates)]
        after_values = [value for value, _, _ in after_candidates]
        multiline = compose_multiline_project_name(before_values, after_values)
        if multiline:
            results.append({"name": multiline, "index": index, "score": 48})
        for value, candidate_index, score in [*before_candidates, *after_candidates]:
            results.append({"name": value, "index": candidate_index, "score": score})
        for group in [
            clean_plan_project_name(" ".join(before_values)),
            clean_plan_project_name(" ".join(after_values)),
        ]:
            if group and len(group.split()) <= 8:
                results.append({"name": group, "index": index, "score": 18})
    return results

def project_names_near_sheet_title(lines: list[str]) -> list[dict]:
    results = []
    for index, line in enumerate(lines[:100]):
        if not re.search(r"\b(?:(?:fire\s+)?sprinkler|fire\s+service\s+underground|fire\s+protection|fire\s+pump)\s+plans?\b", line, re.IGNORECASE):
            continue
        options = []
        for candidate_index, candidate in enumerate(lines[max(0, index - 12) : index], start=max(0, index - 12)):
            value = clean_plan_project_name(candidate)
            if not is_project_name_candidate(value):
                continue
            if re.search(r"\b(symbol|legend|notes?|materials?|installations?|automatic fire|coupling|valve|grooved|rigid|flexible|wagner\s+fire|true\s+north\s+fire)\b", value, re.IGNORECASE):
                continue
            score = score_project_name_candidate(value) + max(0, 8 - (index - candidate_index))
            options.append({"name": value, "index": candidate_index, "score": 46 + score})
        if options:
            results.append(max(options, key=lambda item: item["score"]))
    return results

def compose_multiline_project_name(before_candidates: list[str], after_candidates: list[str]) -> str:
    candidates = [candidate for candidate in after_candidates if candidate]
    if len(candidates) < 2:
        return ""
    descriptor = next((candidate for candidate in candidates if is_project_descriptor_line(candidate)), "")
    if not descriptor:
        return ""
    name = next(
        (
            candidate
            for candidate in candidates
            if normalize_text(candidate) != normalize_text(descriptor)
            and not is_project_descriptor_line(candidate)
        ),
        "",
    )
    if not name:
        return ""
    return clean_plan_project_name(f"{name}, {descriptor}")

def is_project_descriptor_line(value: str) -> bool:
    return bool(re.search(r"\b\d+[- ]?story\b|\b\d+\s+suites?\b|\bbuilding\b|\bphase\b|\baddition\b|\bgarage\b", value, re.IGNORECASE))

def find_best_plan_address(lines: list[str]) -> str:
    best = ("", -1000)
    for index in range(len(lines)):
        address = assemble_plan_address(lines, index)
        if not address:
            continue
        has_street_address = bool(
            re.search(
                r"\b\d{1,6}(?:-\d{1,6})?\s+.+\s(?:Street|St\.?|Avenue|Ave\.?|Road|Rd\.?|Drive|Dr\.?|Lane|Ln\.?|Boulevard|Blvd\.?|Way|Court|Ct\.?|Place|Pl\.?|Highway|Hwy\.?|Parkway|Pkwy\.?|Circle|Cir\.?|Loop|Terrace|Ter\.?|Trail|Trl\.?)(?:\s+\d{1,4})?(?=\W|$)",
                address,
                re.IGNORECASE,
            )
        )
        nearby = lines[max(0, index - 5) : min(len(lines), index + 7)]
        score = 0
        if validate_plan_address(address)["ok"]:
            score += 8
        if has_street_address:
            score += 10
        else:
            score -= 15
        if re.search(r"\b\d{5}(?:-\d{4})?\b", address):
            score += 4
        if any(is_project_name_candidate(clean_plan_project_name(line)) for line in nearby):
            score += 5
        if any(re.search(r"\b(apartments?|restaurant|hotel|school|tenant|improvement|center|building|residence|residential|company|warehouse)\b", line, re.IGNORECASE) for line in nearby):
            score += 3
        if any(re.search(r"\b(owner|architect|engineer|civil|structural|m/p|electrical|principal|manager|contact|phone|email|responsible entity)\b", line, re.IGNORECASE) for line in nearby):
            score -= 5
        if any(re.search(r"\b(lic\.?|license|c[-\s]?16|phone|1-\(?\d{3}\)?|\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4})\b", line, re.IGNORECASE) for line in nearby):
            score -= 9
        if any(re.search(r"\b(nfpa code|system type|design criteria|fire prevention|phone number)\b", line, re.IGNORECASE) for line in nearby):
            score -= 6
        if index < 30:
            score -= 2
        if score > best[1]:
            best = (address, score)
    return best[0]

def assemble_plan_address(lines: list[str], index: int) -> str:
    address = find_plan_address(lines[index])
    if not address:
        return find_city_state_zip(lines[index])
    if not address:
        return ""
    if re.search(r",\s*[A-Za-z .'-]+,\s*[A-Z]{2}\b", address):
        return address
    best_city_state = ""
    for candidate in lines[index + 1 : index + 13]:
        city_state = re.match(city_state_zip_pattern(), candidate.strip(), re.IGNORECASE)
        if city_state:
            formatted = format_city_state_zip(city_state.group(0))
            if re.search(r"\b\d{5}(?:-\d{4})?\b", formatted):
                return format_plan_address(f"{address.rstrip(' ,.')}, {formatted}")
            if not best_city_state:
                best_city_state = formatted
    if best_city_state:
        return format_plan_address(f"{address.rstrip(' ,.')}, {best_city_state}")
    return format_plan_address(address)

def find_plan_address(text: str) -> str:
    pattern = re.compile(
        r"\b\d{1,6}(?:-\d{1,6})?\s+(?:[NSEW]\.?\s+)?[A-Za-z0-9.'#& -]+?\s+"
        r"(?:Street|St\.?|Avenue|Ave\.?|Road|Rd\.?|Drive|Dr\.?|Lane|Ln\.?|Boulevard|Blvd\.?|Way|Court|Ct\.?|Place|Pl\.?|Highway|Hwy\.?|Parkway|Pkwy\.?|Circle|Cir\.?|Loop|Terrace|Ter\.?|Trail|Trl\.?)(?:\s+\d{1,4})?(?=\W|$)"
        r"(?:\s+(?:Suite|Ste\.?|Unit|#)\s*[A-Za-z0-9-]+)?"
        r"(?:[,\s]+[A-Za-z .'-]+,?\s+[A-Z]{2}\.?,?)?(?:\s*\d{5}(?:-\d{4})?)?",
        re.IGNORECASE,
    )
    match = pattern.search(text)
    if not match:
        return ""
    address = re.sub(r"\s+", " ", match.group(0)).strip(" ,")
    address = re.sub(r"\b(St|Ave|Blvd|Rd|Dr|Ln|Ct|Pl|Hwy|Pkwy|Cir|Ter|Trl)\.\s+([A-Za-z .'-]+,\s*[A-Z]{2})\b", r"\1, \2", address, flags=re.IGNORECASE)
    address = re.sub(
        r"\b(Street|St\.?|Avenue|Ave\.?|Road|Rd\.?|Drive|Dr\.?|Lane|Ln\.?|Boulevard|Blvd\.?|Way|Court|Ct\.?|Place|Pl\.?|Highway|Hwy\.?|Parkway|Pkwy\.?|Circle|Cir\.?|Loop|Terrace|Ter\.?|Trail|Trl\.?)\s+([A-Za-z .'-]+),\s*([A-Z]{2})\b",
        r"\1, \2, \3",
        address,
        flags=re.IGNORECASE,
    )
    address = re.sub(r",\s*([A-Z]{2}),\s*(\d{5})\b", r", \1 \2", address)
    address = re.sub(r",\s*([A-Z]{2})\.\s*(\d{5})\b", r", \1 \2", address, flags=re.IGNORECASE)
    address = re.sub(r"\s+([A-Z]{2})\.?\s+(\d{5})\b", r", \1 \2", address)
    return format_plan_address(address)

def format_plan_address(value: str) -> str:
    value = re.sub(r"\s+", " ", value or "").strip(" ,")
    parts = [part.strip() for part in value.split(",") if part.strip()]
    if len(parts) >= 3 and re.match(r"^[A-Z]{2}\.?(?:\s+\d{5}(?:-\d{4})?)?$", parts[-1], re.IGNORECASE):
        state_zip = parts[-1].replace(".", "").upper()
        street = project_title_case(parts[0])
        city = project_title_case(" ".join(parts[1:-1]))
        return f"{street}, {city}, {state_zip}"
    if len(parts) == 2 and re.match(r"^[A-Z]{2}\.?(?:\s+\d{5}(?:-\d{4})?)?$", parts[1], re.IGNORECASE):
        return format_city_state_zip(value)
    return project_title_case(value) if value.upper() == value else value

def city_state_zip_pattern() -> str:
    return r"^[A-Za-z .'-]+,?\s+[A-Z]{2}\.?\s*,?\s*\d{5}(?:-\d{4})?$|^[A-Za-z .'-]+,\s*[A-Z]{2}\.?\s*,?\s*$"

def find_city_state_zip(value: str) -> str:
    value = re.sub(r"\s+", " ", value or "").strip(" ,")
    match = re.match(city_state_zip_pattern(), value, re.IGNORECASE)
    return format_city_state_zip(match.group(0)) if match else ""

def find_city_state_plan_address(lines: list[str]) -> str:
    for line in lines:
        address = find_city_state_zip(line)
        if address:
            return address
    return ""

def format_city_state_zip(value: str) -> str:
    value = re.sub(r"\s+", " ", value or "").strip(" ,")
    match = re.match(r"^(.+?),?\s+([A-Z]{2})\.?\s*,?\s*(\d{5}(?:-\d{4})?)?$", value, re.IGNORECASE)
    if not match:
        return value
    city = match.group(1).strip(" ,")
    state = match.group(2).upper()
    zip_code = match.group(3) or ""
    return f"{project_title_case(city)}, {state}{f' {zip_code}' if zip_code else ''}"

def validate_plan_address(address: str) -> dict:
    if not address:
        return {"ok": False, "message": "No address was detected."}
    has_street = bool(
        re.search(
            r"\b\d{1,6}(?:-\d{1,6})?\s+.+\s(?:Street|St\.?|Avenue|Ave\.?|Road|Rd\.?|Drive|Dr\.?|Lane|Ln\.?|Boulevard|Blvd\.?|Way|Court|Ct\.?|Place|Pl\.?|Highway|Hwy\.?|Parkway|Pkwy\.?|Circle|Cir\.?|Loop|Terrace|Ter\.?|Trail|Trl\.?)(?=\W|$)",
            address,
            re.IGNORECASE,
        )
    )
    has_city_state = bool(re.search(r",\s*[A-Za-z .'-]+,\s*[A-Z]{2}\.?\b", address))
    has_zip = bool(re.search(r"\b\d{5}(?:-\d{4})?\b", address))
    is_city_state_zip = bool(re.fullmatch(r"[A-Za-z .'-]+,\s*[A-Z]{2}\s+\d{5}(?:-\d{4})?", address))
    if has_street and has_city_state and has_zip:
        return {"ok": True, "message": ""}
    if has_street and has_city_state:
        return {"ok": True, "message": "Address looks usable, but no ZIP code was detected."}
    if is_city_state_zip:
        return {"ok": True, "message": "Only city/state/ZIP was detected; confirm whether a street address is needed."}
    if has_street:
        return {"ok": False, "message": "Address has a street, but city/state/ZIP may be missing."}
    return {"ok": False, "message": "Detected address does not look like a complete street address."}

def clean_plan_project_name(value: str) -> str:
    value = re.sub(r"^(?:project\s*name|project\s*title|job\s*name|site\s*name|project)\s*[:#-]\s*", "", value, flags=re.IGNORECASE)
    value = re.sub(r"\s+", " ", value).strip(" -:")
    value = re.sub(r"^(?:area of work|underground connection\s*\(for reference only\)|site location)\s*,\s*", "", value, flags=re.IGNORECASE)
    value = re.sub(
        r"^\d{1,3}\s+(?=[A-Za-z&.' -]+(?:addition|residence|apartments?|center|building|market|retail|winery|cheese|drywall|hotel|hall|terminal|pump|seminary)\b)",
        "",
        value,
        flags=re.IGNORECASE,
    )
    if len(value.split()) > 10:
        return ""
    return value if 4 <= len(value) <= 100 and re.search(r"[A-Za-z]", value) else ""

def format_project_name(value: str) -> str:
    value = clean_plan_project_name(value)
    if value and value.upper() == value and re.search(r"[A-Z]", value):
        return project_title_case(value)
    return format_mixed_project_name(value)

def detected_project_caps(value: str) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip()).upper()

def format_mixed_project_name(value: str) -> str:
    keep_upper = {"AFB", "UCSF", "UCLA", "UC", "CSU", "B14", "LLC", "QOZB"}
    words = []
    for word in value.split():
        prefix = re.match(r"^\W*", word).group(0)
        suffix = re.search(r"\W*$", word).group(0)
        core = word[len(prefix) : len(word) - len(suffix) if suffix else len(word)]
        bare = re.sub(r"[^A-Za-z0-9]", "", core)
        if bare.upper() in keep_upper or re.fullmatch(r"(?:[A-Za-z]\.){2,}[A-Za-z]?\.?", core) or re.search(r"\d", bare) or not core.isupper():
            words.append(word)
        else:
            words.append(f"{prefix}{core[:1].upper()}{core[1:].lower()}{suffix}")
    return " ".join(words)

def project_title_case(value: str) -> str:
    keep_upper = {"AFB", "UCSF", "UCLA", "UC", "CSU", "B14"}
    words = []
    for word in value.split():
        clean = word.strip()
        bare = re.sub(r"[^A-Za-z0-9]", "", clean)
        if bare.upper() in keep_upper or re.search(r"\d", bare):
            words.append(clean.upper())
        elif re.fullmatch(r"(?:[A-Za-z]\.){2,}[A-Za-z]?\.?", clean):
            words.append(clean.upper())
        else:
            words.append(clean[:1].upper() + clean[1:].lower())
    return " ".join(words)

def is_project_name_candidate(value: str) -> bool:
    if not value:
        return False
    if normalize_text(value) in {"studio", "firstsubmit", "artifexwest"}:
        return False
    bad_key = normalize_text(value)
    bad_fragments = {
        "aterialsshall",
        "isprinklersystem",
        "attendedlocation",
        "referencekey",
        "ofcall",
        "areaofproject",
        "siteworkarea",
        "actualbuildingheight",
        "poweringbusiness",
        "powesingbusiness",
        "poweningbusiness",
        "businessworldwide",
        "aiciadd",
        "iconstructiontype",
        "vsttoconfgrmtokfpafts",
        "watersupplyinformation",
        "undergroundshownforreferenceonly",
        "sector2aloadoutareaplans",
        "seatingareas",
        "indicatedonplanallpipingabovegradetobeductile",
        "eofcale",
        "20tshalpetheresponsiltyofhevinertokantan",
        "rooremaproved",
        "fthevtrawlaracopyofhfpazes",
        "responsilty",
        "heviner",
        "kantan",
        "hfpazes",
        "roore",
        "nsfortu",
        "vtrawlar",
        "aproved",
        "braceidentification",
        "jrwagner",
        "lrwagner",
        "irwagner",
        "wagnerfre",
        "wagnerfire",
        "mtaned",
    }
    if any(fragment in bad_key for fragment in bad_fragments):
        return False
    if len(value.split()) > 10:
        return False
    if value.count(")") > value.count("(") or re.search(r"^\s*(?:by|designed|drawn)\s*:", value, re.IGNORECASE):
        return False
    tokens_for_quality = meaningful_name_token_list(value)
    has_compact_acronym = bool(re.search(r"\b[A-Z]\d+\b|\b[A-Z](?:\.[A-Z]){1,}\.?\b", value))
    if len(tokens_for_quality) <= 1 and not has_compact_acronym:
        return False
    if not any(len(token) >= 3 for token in tokens_for_quality) and not has_compact_acronym:
        return False
    if re.match(r"^\d+\.\s*", value) or re.search(r"\s=\s|=", value):
        return False
    if re.fullmatch(r"system\.?|staff|typical|remarks?|n\.?t\.?s\.?|p\.?o\.?c\.?|n\.?l\.?c\.?|u\.?n\.?o\.?|no\.?\s*a\.?s\.?|osfm stamp|brace identification|vertical pipe|ductile iron|fire underground|fire pump plan|applicable codes|action codes|disclaimer|hazard|stubs?-?up|plan|location\.?|site location|fully sprinklered:?\s*yes|reference site|commodity classification", value, re.IGNORECASE):
        return False
    if re.match(r"^\(?[EN]\)?\s+", value, re.IGNORECASE) and re.search(r"\b(pipe|piping|riser|discharge|suction)\b", value, re.IGNORECASE):
        return False
    if re.search(r"\b[A-Z]/FS\d+\b|THRU\s+[A-Z]/FS\d+", value, re.IGNORECASE):
        return False
    if re.fullmatch(r"(?:FP|FS|F)-?\d+(?:\.\d+)?[A-Z]?|PROJECT\s+NO\.?|SHEET\s+NO\.?|SHEET\s+NAME|PAGE\s+NO\.?|\d+\s+OF\s+\d+", value, re.IGNORECASE):
        return False
    if re.search(r"\b(lic\.?|license|c[-\s]?16|phone|address|date signed|date issued|designed by|drawn by|checked by|job number|job id|project no\.?|sheet no\.?|sheet name|page no\.?|drawing scale|plot size|as shown|as noted|as-built|issued for|revised|revision|revisiondate|comments?|ahj|authority having jurisdiction|requirements?|required|attachment|materials?|aterial|installations?|automatic fire|building structure|building areas?|description|render|connection point|point of connection|flow test|water flow|water supply|water\s*f\s*l_?ow|remote area|hydraulic information|hydraulic calcs?|construction type|occupancy|nfpa|total|thread rod|branch lines?|ordinances?|perspective|section|indoor fire pump|buildings shall|buildings on the same lot|same lot|physically separated|brass|temperature|finish|parcel|square footage|sq\.?\s*ft|s\.?\s*f\.?|riser|exp\.?|coupling|grooved|valve|earthquake bracing|hydraulic reference|key note|location map|site map|vicinity map|install plan|job info|project location|building footing|cut base|base lgth|pop-out|eave ht|verify in field|unless noted otherwise|reference only|tenant improvement|pendent sprinklers|seating areas|acceptance of these plans|subject to field|not\s*in\s*contract|no automatic sprinklers|no\.?\s*stories|stories|blocking|by others|alterations?|instruction manuals?|upkeep|shall bear this notice|any part of these|express written consent|area of work|loadout area|i?applicable codes|action codes|fire\s*prevention|firei?prevention|fire department|department|departmi?ent|design criteria|ordinary hazard|commodity classification|approx|exposure|freezing|adequately protected|hydrant location|clg:|pipe type|available|separate permit|custom lengths|existing|milking|rankler|rinkler|discharge piping|suction piping|victaulic|flange adapter)\b", value, re.IGNORECASE):
        return False
    if re.search(r"(?:\+?1[\s.-]?)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}", value):
        return False
    if re.search(r"\b\d{5,}\b", value):
        return False
    if is_plan_noise_line(value) or find_plan_address(value) or find_city_state_zip(value):
        return False
    if re.fullmatch(r"[\d\s.,#/-]+", value):
        return False
    alpha_chars = re.findall(r"[A-Za-z]", value)
    if alpha_chars and len(alpha_chars) < max(3, len(value) * 0.35):
        return False
    if re.search(r"[{}\\|]", value):
        return False
    if re.search(r"[§#]", value):
        return False
    if re.search(r"\b\d{2,3}\s*°\s*f\b", value, re.IGNORECASE):
        return False
    if re.fullmatch(r"(?:quick|fast|standard)(?:\s+response)?", value, re.IGNORECASE):
        return False
    if re.search(r"@|www\.|\.com\b|\b(owner|architect|engineer|principal|manager|contact|phone|email|civil|structural|m/p|electrical|inc\.?|llc|corporation|sternco|jrs|james quinn|ernst flores|j\.?\s*r\.?\s*wagner|l\.?\s*r\.?\s*wagner|i\.?\s*r\.?\s*wagner|lr\s+wagner|ir\s+wagner|wagner fire|true north fire|dan thacker|wharnen)\b", value, re.IGNORECASE):
        return False
    if len(value) > 10:
        letters = re.findall(r"[A-Za-z]", value)
        vowels = re.findall(r"[AEIOUaeiou]", value)
        if letters and len(vowels) / len(letters) < 0.14:
            return False
    return True

def project_name_from_filename(file_name: str) -> str:
    stem = Path(file_name or "").stem
    stem = re.sub(r"[_+]+", " ", stem)
    stem = re.sub(r"^Fire\s+Approval[-\s]*", " ", stem, flags=re.IGNORECASE)
    stem = re.sub(r"\[[^\]]*\]", " ", stem)
    stem = re.sub(r"\((?:\d+|james rev|in rack approved plans|fire sprinkler approved plans)\)", " ", stem, flags=re.IGNORECASE)
    stem = re.sub(r"^\s*(?:\d{6,}[A-Z]?(?:-[A-Z]{1,3})?|BLD\d{2,4}-?\d+|FDPR\d+-?\d+|24F-\d+-\d+AP|4LEAF)\s*[-_ ]*", " ", stem, flags=re.IGNORECASE)
    stem = re.sub(r"^\s*\d{3,6}\s*[-_ ]*", " ", stem)
    stem = re.sub(r"\b(?:FS|FP|FA|FD|Fire Sprinkler|Sprinklers?|Fire Plans?|Plans?|Submittals?|AHJ|GC|DATE|DSA|OSFM|BPR|Stamped|Shop Drawings?|Hydraulic Calcs?|Signed|Parsons Response|Full Pkg|Draft Stop Detail|with|REV(?:ISION)?\s*\d*|REVISED|APPROVED|APRV|Approval)\b", " ", stem, flags=re.IGNORECASE)
    stem = re.sub(r"\b\d{1,2}[.-]\d{1,2}[.-]\d{2,4}\b", " ", stem)
    stem = re.sub(r"\bFP\d+_?\d*\b", " ", stem, flags=re.IGNORECASE)
    stem = re.sub(r"\b\d+\b$", " ", stem)
    stem = re.sub(r"\s+", " ", stem).strip(" -_")
    stem = re.sub(r"\(\s*\)", " ", stem)
    stem = re.sub(r"\s+-\s+", " - ", stem).strip(" -_")
    if not stem or len(stem) < 4:
        return ""
    return format_project_name(stem)

def is_meaningful_filename_project_name(value: str) -> bool:
    key = normalize_text(value)
    if not key:
        return False
    if re.fullmatch(r"(?:bld|fdpr|si|aprv|dsa|osfm|bpr|xpo|rtp|delta|underground|asbuilt|firepump|plans?|approved|ap)\w*(?:\s+\w+){0,2}", key):
        return False
    if re.search(r"\b(?:as-built|delta|underground delta|fire approval|approved|plans?|shop drawings?|full pkg)\b", value, re.IGNORECASE):
        return False
    if re.search(r"\b\d{5,}\b", value):
        return False
    tokens = meaningful_name_token_list(value)
    alpha_tokens = [token for token in tokens if re.search(r"[a-z]", token)]
    if len(alpha_tokens) >= 2:
        return True
    return bool(alpha_tokens and re.search(r"\b(XPO|WPWMA|RTP|M\.?A\.?C)\b", value, re.IGNORECASE))

def filename_similarity_score(candidate: str, file_candidate: str) -> int:
    if not candidate or not file_candidate:
        return 0
    candidate_key = normalize_text(candidate)
    file_key = normalize_text(file_candidate)
    if not candidate_key or not file_key:
        return 0
    if candidate_key == file_key:
        return 18
    if candidate_key in file_key or file_key in candidate_key:
        return 12
    candidate_token_list = meaningful_name_token_list(candidate_key)
    file_token_list = meaningful_name_token_list(file_key)
    candidate_tokens = set(candidate_token_list)
    file_tokens = set(file_token_list)
    if not candidate_tokens or not file_tokens:
        return 0
    overlap = candidate_tokens & file_tokens
    score = len(overlap) * 6
    candidate_acronym = "".join(token[:1] for token in candidate_token_list if token)
    file_acronym = "".join(token[:1] for token in file_token_list if token)
    if file_acronym and candidate_acronym and (file_acronym in candidate_acronym or candidate_acronym in file_acronym):
        score += 8
    for token in file_tokens:
        if len(token) >= 2 and token == candidate_acronym[: len(token)]:
            score += 8
    return min(score, 18)

def meaningful_name_token_list(value: str) -> list[str]:
    stop = {
        "fs",
        "fp",
        "fire",
        "sprinkler",
        "sprinklers",
        "plan",
        "plans",
        "project",
        "job",
        "rev",
        "revision",
        "revised",
        "set",
        "pdf",
    }
    return [token for token in re.findall(r"[a-z0-9]+", value.lower()) if len(token) > 1 and token not in stop and not token.isdigit()]

def score_project_name_candidate(value: str) -> int:
    score = 0
    if re.search(r"\b(apartments?|restaurant|hotel|school|tenant|improvement|center|building|residence|residential|childcare|daycare|company|warehouse|base|garage|plaza|pavilion|remodeling|addition|store|suites?|facility)\b", value, re.IGNORECASE):
        score += 5
    if "," in value and is_project_descriptor_line(value):
        score += 4
    if is_project_descriptor_line(value) and not re.match(r"^\d", value.strip()):
        score += 5
    if re.match(r"^\d+[- ]?story\b", value.strip(), re.IGNORECASE):
        score -= 5
    if value.isupper():
        score += 2
    words = value.split()
    if 2 <= len(words) <= 7:
        score += 2
    if len(set(words)) <= max(1, len(words) // 2):
        score -= 4
    return score

def is_plan_noise_line(value: str) -> bool:
    return bool(
        re.search(
            r"\b(sheet|sheet title|sheet no|page no|drawing|drawing scale|as noted|issued for|scale|date|revision|revisions|revised|comments?|ahj|approved|checked|drawn|title block|legend|detail|details|symbol|north|sprinkler|fire protection|fire prevention|architect|engineer|contractor|consultant|code|deferred|submittal|cover sheet|cover plate|white cover|floor plan|site plan|piping plan|reflected ceiling plan|building sections?|vicinity|index|notes?|scope of work|project team|project info|project data|project design data|design data|abbreviations?|exclusions?|city water main|water main)\b",
            value,
            re.IGNORECASE,
        )
    )

def normalize_text(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", value.lower())

def analyze_plan_core(pdf_path: Path, file_name: str = "", scan_options: dict | None = None, ocr_hooks: dict | None = None) -> dict:
    _ocr = ocr_hooks or {}
    scan_options = normalize_plan_scan_options(scan_options)
    file_name = file_name or pdf_path.name
    title_block_text = extract_title_block_text(pdf_path)
    full_text, pages = extract_pdf_text(pdf_path, max_pages=12)
    used_ocr_fallback = False
    ocr_note = ""
    if _ocr and _ocr["should_use"](title_block_text, full_text):
        ocr_text, ocr_note = _ocr["extract"](pdf_path, max_pages=min(max(pages or 1, 1), 4))
        if ocr_text:
            title_block_text = ocr_text
            full_text = ocr_text
            used_ocr_fallback = True
    title_project = infer_project_info(title_block_text, source="title block", pages=pages)
    full_project = infer_project_info(full_text, source="first plan pages", pages=pages, file_name=file_name)
    project = choose_plan_project(title_project, full_project)

    if _ocr and not used_ocr_fallback and _ocr["should_retry"](project, file_name):
        ocr_text, ocr_note = _ocr["extract"](pdf_path, max_pages=min(max(pages or 1, 1), 4))
        if ocr_text:
            title_block_text = ocr_text
            full_text = ocr_text
            title_project = infer_project_info(title_block_text, source="title block", pages=pages)
            full_project = infer_project_info(full_text, source="first plan pages", pages=pages, file_name=file_name)
            project = choose_plan_project(title_project, full_project)
            used_ocr_fallback = True

    notes = project.get("notes") or []
    if not title_block_text.strip():
        notes.append("No selectable title-block text was found; scanned plans may need an image crop or OCR.")
    elif project.get("source") == "title block":
        notes.append("Title block was checked first.")
    if used_ocr_fallback:
        notes.append("OCR fallback was used because the PDF text was selectable but encoded.")
    elif ocr_note:
        notes.append(ocr_note)
    project["notes"] = notes
    project["fileName"] = file_name
    combined_text = "\n".join([title_block_text, full_text])
    if looks_like_encoded_pdf_text(combined_text):
        project["notes"].append("Plan text appears encoded, so some title-block and legend details may require OCR or a clearer plan export.")
    project["contractor"] = infer_plan_contractor(combined_text)
    project["sprinklers"] = infer_plan_sprinkler_legend(combined_text) if scan_options["sprinklers"] else []
    project["pipeTypes"] = infer_plan_pipe_types(combined_text) if scan_options["piping"] else []
    project["fittings"] = infer_plan_catalog_terms(combined_text, "Fittings") if scan_options["piping"] else []
    project["hangers"] = infer_plan_catalog_terms(combined_text, "Hangers") if scan_options["hangers"] else []
    project["bracing"] = infer_plan_catalog_terms(combined_text, "Bracing") if scan_options["bracing"] else []
    project["valves"] = infer_plan_catalog_terms(combined_text, "Valves") if scan_options["valves"] else []
    project["miscellaneous"] = infer_plan_catalog_terms(combined_text, "Miscellaneous") if scan_options["miscellaneous"] else []
    project["scanTextSample"] = clean_text(combined_text[:24000])
    project["scanOptions"] = scan_options
    project["name"] = detected_project_caps(correct_detected_project_name(project.get("name"), file_name))
    project["address"] = detected_project_caps(project.get("address"))
    for candidate in project.get("projectNameCandidates") or []:
        candidate["name"] = detected_project_caps(candidate.get("name"))
    return project

