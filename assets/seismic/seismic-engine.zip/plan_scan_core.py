"""Local fire-sprinkler plan scanning - text extraction, project-info
inference, and catalog-term matching. Extracted from server.py so the SAME
code runs on desktop AND in the browser (Pyodide). Pure text processing:
pypdf + regex only - NO cloud, NO AI, NO OS access.

The OCR fallback for scanned/raster plans stays desktop-side; callers inject
it through analyze_plan_core(ocr_hooks=...). KEEP THIS MODULE PURE.
"""
from __future__ import annotations

import re
from pathlib import Path

from pypdf import PdfReader

# Pure-Python sibling (no filesystem, no OS), so the browser edition keeps
# importing this module unchanged.
import plan_bracing_vocab as _bracing_vocab


# Copied verbatim from tools/build_datasheet_catalog.py so the web bundle
# doesn't drag in the catalog build tooling. Keep in sync (they are stable).
def clean_text(value: str) -> str:
    value = value.replace("®", "").replace("™", "").replace("°", " Degree ")
    value = re.sub(r"[_]+", " ", value)
    value = re.sub(r"\s+", " ", value)
    return value.strip(" .-_")


def title_case(value: str) -> str:
    keep_upper = {"CPVC", "UL", "FM", "FDC", "IPS", "NPT", "OSY", "AOSY", "RPDA"}
    words = []
    for word in value.split():
        clean = word.strip()
        if clean.upper() in keep_upper:
            words.append(clean.upper())
        elif re.fullmatch(r"[A-Z0-9-]+", clean):
            words.append(clean)
        else:
            words.append(clean[:1].upper() + clean[1:].lower())
    return " ".join(words)

def extract_pdf_text(path: Path, max_pages: int = 3) -> tuple[str, int]:
    try:
        reader = PdfReader(str(path))
        chunks = []
        for page in reader.pages[:max_pages]:
            chunks.append(page.extract_text() or "")
        return "\n".join(chunks), len(reader.pages)
    except Exception:
        return "", 0

def choose_plan_project(title_project: dict, full_project: dict) -> dict:
    if title_project.get("name") and title_project.get("addressLooksValid"):
        return title_project
    if full_project.get("labelEvidence") and (full_project.get("name") or full_project.get("address")):
        return full_project
    if title_project.get("name") or title_project.get("address"):
        project = dict(title_project)
        if not project.get("name") and full_project.get("name"):
            project["name"] = full_project["name"]
        if not project.get("address") and full_project.get("address"):
            project["address"] = full_project["address"]
            project["addressSignals"] = full_project.get("addressSignals") or []
        if not project.get("projectNameCandidates") and full_project.get("projectNameCandidates"):
            project["projectNameCandidates"] = full_project["projectNameCandidates"]
        return project
    return full_project

def normalize_plan_scan_options(scan_options: dict | None) -> dict:
    incoming = scan_options if isinstance(scan_options, dict) else {}
    return {
        "sprinklers": incoming.get("sprinklers") is not False,
        "piping": incoming.get("piping") is not False,
        "hangers": incoming.get("hangers") is not False,
        "bracing": incoming.get("bracing") is not False,
        "valves": incoming.get("valves") is not False,
        "miscellaneous": incoming.get("miscellaneous") is not False,
    }

def correct_detected_project_name(name: str, file_name: str) -> str:
    # No per-job special cases live here. Three used to ("standard plumbing
    # addition", "riverbank fire pump", "plaza hotel"); each fixed one
    # customer's file and was invisible to every other job, which is the
    # signature of tuning without a test set. The title-block reader and the
    # labelled-field ranker are expected to earn those names on merit.
    clean_name = name or ""
    filename_guess = project_name_from_filename(file_name)
    if (
        is_meaningful_filename_project_name(filename_guess)
        and clean_name
        and filename_similarity_score(clean_name, filename_guess) == 0
        and re.search(r"\b(victaulic|flange|adapter|coupling|grooved|pipe|piping|valve|fitting|hanger|brace|bracing)\b", clean_name, re.IGNORECASE)
    ):
        return filename_guess
    if is_meaningful_filename_project_name(filename_guess) and not clean_name:
        return filename_guess
    return clean_name

def looks_like_encoded_pdf_text(text: str) -> bool:
    if not text:
        return False
    encoded_tokens = re.findall(r"/\d{1,4}\b", text)
    cid_tokens = re.findall(r"\(cid:\d+\)", text)
    readable_words = re.findall(r"\b[A-Za-z]{3,}\b", text)
    encoded_count = len(encoded_tokens) + len(cid_tokens)
    return encoded_count > 120 and encoded_count > max(80, len(readable_words) * 4)

_PROJECT_SIDE_LINE_RE = re.compile(
    # LOCATION / PROJECT ADDRESS / SITE ADDRESS / JOB ADDRESS labels mark the
    # PROJECT's address even when they sit inside a firm's contact block, and
    # OCR loves misreading LOCATION (LOGATION, L0CATION). An address harvested
    # off such a line must never be attributed to the contractor.
    r"(?<![A-Z0-9])(?:L[O0Q][CG]ATI[O0]N|PR[O0]JECT\s*(?:ADDRESS|INF[O0]|L[O0]CATI[O0]N)?|SITE\s*ADDRESS|JOB\s*ADDRESS)\s*[:#-]",
    re.IGNORECASE,
)


def _contractor_address_lines(lines: list[str]) -> list[str]:
    return [line for line in lines if not _PROJECT_SIDE_LINE_RE.search(line)]


#: A line that names a FIRM or an AUTHORITY - the contractor, the engineer, the
#: architect, the fire department. Whatever address sits in the few lines under
#: one of these is that party's own office, never the project's.
#:
#: "fire\s*protection" (not "fire sprinkler") is deliberate: title blocks are
#: full of "AUTOMATIC FIRE SPRINKLER SYSTEM" prose, and matching that would
#: blacklist half the sheet. "\s*" rather than "\s+" is also deliberate - the
#: title-block glyph assembler collapses inter-word spacing on stylised
#: letterheads, so J.R. Wagner's logo arrives as "J.R.WagnerFireProtection".
_FIRM_ANCHOR_RE = re.compile(
    r"(?:fire\s*(?:protection|prevention|department|district|marshal)"
    r"|engineers?\b|engineering\b|architects?\b|architecture\b"
    r"|design\s*group|consultants?\b)",
    re.IGNORECASE,
)

#: A licence number, phone number, website or email: the rest of a letterhead's
#: contact block. These extend a zone that a NAME already opened; they never
#: open one themselves. STERNCO's sheet is why - its only line carrying the
#: word "engineers" is the URL www.sterncoengineers.com, and anchoring on that
#: zoned out the project's own address two lines below it.
_CONTACT_ANCHOR_RE = re.compile(
    r"(?:\bLIC(?:ENSE)?\.?\s*#|\bC[-\s]?16\b|\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}|\b1-\(?\d{3}\)?"
    r"|\bwww\.|https?://|\.com\b|\.net\b|\.org\b|@)",
    re.IGNORECASE,
)

#: A web address or an email is contact detail, not a company NAME.
_CONTACT_ONLY_LINE_RE = re.compile(r"(?:\bwww\.|https?://|@|\.(?:com|net|org|us)\b)", re.IGNORECASE)

#: How far a letterhead's own address can sit from the name that owns it.
#: Measured on the corpus: name, licence, phone, street, city/state/ZIP - five
#: lines at most, with a little slack for a logo line above the name.
_LETTERHEAD_LOOKBACK = 2
_LETTERHEAD_LOOKAHEAD = 6


def _is_firm_anchor_line(line: str) -> bool:
    """True for a short, name-shaped line that carries a firm/authority word.

    The word count gate is what keeps notes prose out: "THE CONTRACTOR SHALL
    PROVIDE THE OWNER WITH INSTRUCTION MANUALS..." carries firm words too, and
    zoning it out would blacklist the whole notes column."""
    text = re.sub(r"\s+", " ", line or "").strip()
    if not text or len(text.split()) > 8:
        return False
    if _PROJECT_SIDE_LINE_RE.search(text) or _CONTACT_ONLY_LINE_RE.search(text):
        return False
    return bool(_FIRM_ANCHOR_RE.search(text))


def letterhead_line_indices(lines: list[str]) -> set:
    """Indices whose address belongs to a firm or an authority, not the project.

    The zone needs a NAME anchor: a bare phone number is not enough on its own
    (plenty of title blocks print the project address a couple of lines from an
    emergency contact number), but a phone or licence line adjacent to a firm
    name extends that firm's zone downward through its whole contact block.

    Lines the document itself labels as the project's (LOCATION:, PROJECT
    ADDRESS:) are never zoned, and neither are the three lines under such a
    label - an explicit label outranks any neighbourhood guess."""
    if not lines:
        return set()
    firm_anchors = [index for index, line in enumerate(lines) if _is_firm_anchor_line(line)]
    if not firm_anchors or len(firm_anchors) * 4 > len(lines):
        # Prose-heavy text where "engineering"/"architects" appears everywhere:
        # the neighbourhood signal is noise, so claim nothing.
        return set()

    contact = {index for index, line in enumerate(lines) if _CONTACT_ANCHOR_RE.search(line)}
    zoned: set = set()
    for anchor in firm_anchors:
        stop = anchor + _LETTERHEAD_LOOKAHEAD
        # A contact line inside the zone means the block is still running, so
        # let the zone reach past it (logo, name, lic, phone, street, city).
        for index in sorted(i for i in contact if anchor <= i <= stop + 2):
            stop = max(stop, index + 3)
        zoned.update(range(max(0, anchor - _LETTERHEAD_LOOKBACK), min(len(lines), stop + 1)))

    protected: set = set()
    for index, line in enumerate(lines):
        if _PROJECT_SIDE_LINE_RE.search(line):
            protected.update(range(index, min(len(lines), index + 4)))
    return zoned - protected


#: Tokens too common to prove that an address belongs to a project of the same
#: name. "CHANNEL" in "517 Channel St" vs "Channel St Apartments" is evidence;
#: "MAIN" in "683 N Main St" vs "Main Street Lofts" is a coincidence waiting to
#: happen, and every street suffix matches everything.
_GENERIC_NAME_TOKENS = {
    "STREET", "AVENUE", "ROAD", "DRIVE", "BOULEVARD", "LANE", "COURT", "PLACE",
    "HIGHWAY", "PARKWAY", "CIRCLE", "TERRACE", "TRAIL", "LOOP", "SUITE", "UNIT",
    "NORTH", "SOUTH", "EAST", "WEST", "CENTRAL", "MAIN", "FIRST", "SECOND",
    "THIRD", "FOURTH", "FIFTH", "SIXTH", "BROADWAY", "MARKET", "CHURCH", "HIGH",
    "PARK", "LAKE", "RIVER", "HILL", "VALLEY", "SPRING", "UNION", "COLLEGE",
    "SCHOOL", "BUILDING", "PROJECT", "FIRE", "SPRINKLER", "SPRINKLERS", "PLANS",
    "SYSTEM", "TENANT", "IMPROVEMENT", "PHASE", "AREA", "SITE", "NEW", "THE",
    "AND", "OF", "AT", "BLDG", "APARTMENTS", "APARTMENT", "RESIDENCE",
    "CENTER", "CENTRE", "PLAZA", "COMPANY", "GROUP", "INC", "LLC",
}


def distinctive_name_tokens(name: str) -> set:
    """The parts of a project name that could identify an address as its own."""
    tokens = set(re.findall(r"[A-Z][A-Z0-9]{3,}", (name or "").upper()))
    return {token for token in tokens if token not in _GENERIC_NAME_TOKENS}


def name_token_affinity(address: str, project_name: str) -> bool:
    """True when the address carries a distinctive token of the project name."""
    tokens = distinctive_name_tokens(project_name)
    if not tokens:
        return False
    address_tokens = set(re.findall(r"[A-Z][A-Z0-9]{3,}", (address or "").upper()))
    return bool(tokens & address_tokens)


def project_name_line_indices(lines: list[str], project_name: str) -> list:
    """Where the project name shows up, so an address can be measured against it."""
    key = normalize_text(project_name or "")
    if not key or len(key) < 4:
        return []
    return [index for index, line in enumerate(lines) if key in normalize_text(line)]


#: How far BELOW the project name its address may sit and still count as near.
_NAME_PROXIMITY_REACH = 4


def address_is_near_project_name(index: int, name_indices) -> bool:
    """Proximity looks DOWNWARD only.

    A title block reads name-then-address, and the line assembler interleaves
    the two columns of small print, so an address a line or two ABOVE the
    project name generally belongs to whoever owns the block the name landed
    in - on the 4049 sheet that is STERNCO's suite number, sitting two lines
    over the project title."""
    return any(0 <= index - n <= _NAME_PROXIMITY_REACH for n in name_indices)


def vouched_letterhead_indices(lines: list[str], project_name: str = "") -> set:
    """The letterhead zone, minus any line the project NAME vouches for.

    A title block is two columns of small print, and the line assembler reads
    them interleaved - on the 615 W Magnolia sheet the project's own address
    lands four lines into Alpine Fire Protection's contact block:

        Magnolia St Residence          <- project name
        Alpine Fire Protection Inc.    <- firm name, opens the zone
        DESIGN INSTALLATION AND REPAIRS
        615 W Magnolia St              <- the PROJECT's address, inside the zone
        P.O BOX 9305                   <- the firm's

    So the zone cannot be the last word. Only AFFINITY vouches, though: sharing
    a distinctive token with the project name is specific evidence about this
    address, while mere proximity is an accident of reading order and is not
    strong enough to pull an address out of a letterhead. Proximity stays what
    it is - a scoring bonus among addresses that were never excluded."""
    zoned = letterhead_line_indices(lines)
    tokens = distinctive_name_tokens(project_name)
    if not zoned or not tokens:
        return zoned
    vouched = {
        index
        for index in sorted(zoned)
        if tokens & set(re.findall(r"[A-Z][A-Z0-9]{3,}", (assemble_plan_address(lines, index) or "").upper()))
    }
    return zoned - vouched


def project_vouched_address_keys(texts, project_name: str = "") -> set:
    """Normalised keys for every address the project NAME vouches for.

    Same evidence as the zone vouch, aimed at the other exclusion: the
    contractor sniffer reads a firm's address out of the lines beneath its
    name, and on an interleaved title block those lines include the PROJECT's
    address. Alpine Fire Protection was credited with 615 W Magnolia St - the
    job's own address - which then excluded it from the project slot and left
    the scan answering with the fire department's address instead.

    Affinity only, for the same reason the zone vouch is affinity only: 107
    Conversion's title block prints the contractor's own "425 W Yosemite Dr"
    one line under the project name, and vouching on proximity handed it the
    project slot."""
    keys: set = set()
    tokens = distinctive_name_tokens(project_name)
    if not tokens:
        return keys
    for text in texts:
        lines = normalize_plan_lines(text or "")
        for index in range(len(lines)):
            address = assemble_plan_address(lines, index)
            if address and tokens & set(re.findall(r"[A-Z][A-Z0-9]{3,}", address.upper())):
                keys.add(normalize_text(address))
    keys.discard("")
    return keys


def project_labeled_address_keys(*texts: str) -> set:
    """Normalized street keys for every address the document itself labels as
    the PROJECT's (LOCATION: / PROJECT ADDRESS: / SITE ADDRESS: ...). If the
    contact-block heuristic harvested one of these as the firm address, the
    label wins and the exclusion must let go of it."""
    keys = set()
    for text in texts:
        lines = normalize_plan_lines(text or "")
        for index, line in enumerate(lines):
            if not _PROJECT_SIDE_LINE_RE.search(line):
                continue
            for candidate in [line] + lines[index + 1 : index + 4]:
                found = find_plan_address(candidate)
                if found:
                    keys.add(normalize_text(found))
                    break
    return keys


def drop_project_labeled_addresses(firm_addresses: list, labeled_keys: set) -> list:
    kept = []
    for firm_address in firm_addresses:
        key = normalize_text(firm_address or "")
        if key and any(key.startswith(k) or k.startswith(key) for k in labeled_keys):
            continue
        kept.append(firm_address)
    return kept


def _respace_collapsed_name(value: str) -> str:
    """Put the spaces back into a letterhead the glyph assembler ran together.

    Stylised logos are set with tight tracking, so the title-block reader emits
    "J.R.WagnerFireProtection" as one token - which matched no contractor
    pattern at all, so the firm-address exclusion had nothing to exclude and
    the letterhead won the project-address slot outright."""
    if re.search(r"\s", value or ""):
        return value or ""
    # Split at lowercase->uppercase, and after a run of initials ("J.R.Wagner"),
    # but never between the initials themselves.
    return re.sub(r"(?<=[a-z])(?=[A-Z])|(?<=\.)(?=[A-Z][a-z])", " ", value or "")


def infer_plan_contractor(text: str) -> dict:
    lines = normalize_plan_lines(text)
    best = ({}, -100)
    contractor_pattern = re.compile(r"\b([A-Z][A-Za-z0-9&.' -]{1,70}?\s*(?:Fire\s*Protection|Fire\s*Systems|Fire\s*Services|Fire\s*Suppression))\b", re.IGNORECASE)
    for index, line in enumerate(lines):
        match = contractor_pattern.search(line)
        if not match:
            continue
        name = " ".join(_respace_collapsed_name(match.group(1)).split())
        if re.search(r"\b(sole property|property of|reproduction|drawings?|attachments?)\b", name, re.IGNORECASE):
            continue
        nearby = lines[index : min(len(lines), index + 8)]
        block = "\n".join(nearby)
        phone_match = re.search(r"(?:\+?1[\s.-]?)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}", block)
        license_match = re.search(r"\b(?:C[-\s]?16|LIC(?:ENSE)?\.?\s*#?|LIC(?:ENSE)?\s*NO\.?)\s*[:#-]?\s*([A-Z]{0,3}\d{5,8})\b", block, re.IGNORECASE)
        address_lines = _contractor_address_lines(nearby)
        address = find_best_plan_address(address_lines) or find_plan_address(chr(10).join(address_lines))
        if address and not (phone_match or license_match):
            address = ""
        score = 5
        if phone_match:
            score += 2
        if license_match:
            score += 2
        if address:
            score += 2
        if score > best[1]:
            best = (
                {
                    "name": format_company_name(name),
                    "address": address,
                    "license": license_match.group(1) if license_match else "",
                    "phone": phone_match.group(0) if phone_match else "",
                    "source": "plans",
                    "confidence": "high" if score >= 9 else "medium",
                },
                score,
            )
    for index, line in enumerate(lines):
        if not re.search(r"\b(?:license|lic\.?|phone|\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4})\b", line, re.IGNORECASE):
            continue
        nearby = lines[max(0, index - 5) : min(len(lines), index + 5)]
        block = "\n".join(nearby)
        phone_match = re.search(r"(?:\+?1[\s.-]?)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}", block)
        license_match = re.search(
            r"\b(?:[A-Za-z]+\s+)?(?:C[-\s]?16|LIC(?:ENSE)?\.?\s*(?:NUMBER|NO\.?)?|LIC(?:ENSE)?\s*#?)\s*[:#-]?\s*([A-Z]{2,6}[-\s]?\d{2,8}|[A-Z]{0,3}\d{5,8})\b",
            block,
            re.IGNORECASE,
        )
        address_lines = _contractor_address_lines(nearby)
        address = find_best_plan_address(address_lines) or find_plan_address(chr(10).join(address_lines))
        score = 0
        if phone_match:
            score += 2
        if license_match:
            score += 3
        if address:
            score += 3
        if score > best[1] and score >= 5:
            best = (
                {
                    "name": "",
                    "address": address,
                    "license": license_match.group(1).replace(" ", "-").upper() if license_match else "",
                    "phone": phone_match.group(0) if phone_match else "",
                    "source": "plans contact block",
                    "confidence": "medium",
                },
                score,
            )
    return best[0]

def format_company_name(value: str) -> str:
    value = re.sub(r"\s+", " ", value or "").strip(" -:")
    if value and value.upper() == value:
        return title_case(value)
    return value

def infer_plan_sprinkler_legend(text: str) -> list[dict]:
    lines = normalize_plan_lines(text, dedupe=False)
    records = parse_sprinkler_legend_tables(lines)
    for line in lines:
        if not looks_like_sprinkler_legend_line(line):
            continue
        record = sprinkler_record_from_line(line)
        if record:
            records.append(record)
    return prune_loose_sprinkler_records(dedupe_sprinkler_records(records))[:30]

def looks_like_sprinkler_legend_line(line: str) -> bool:
    return bool(
        re.search(r"\b(sprinkler|viking|victaulic|tyco|reliable|senju|globe|vk\d+|ra\d+|f1fr\d+|ty[-\w]+|v\d{3,4}|qr|sr|fr|upright|pendent|sidewall|esfr|coin|k[- ]?fac)\b", line, re.IGNORECASE)
        and not re.search(r"\b(detail|general note|hydraulic|calculation|sheet index)\b", line, re.IGNORECASE)
    )

def sprinkler_record_from_line(line: str) -> dict:
    if re.fullmatch(r"(?:automatic\s+fire\s+)?sprinkler\s+legend|project total sprinkler schedule", line.strip(), re.IGNORECASE):
        return {}
    if re.search(r"\bsymbol\b.*\b(model|sin|k[- ]?factor|k[- ]?fac|response|resp)\b", line, re.IGNORECASE):
        return {}
    manufacturer = infer_plan_sprinkler_manufacturer(line)
    model = infer_plan_sprinkler_model(line)
    k_factor = infer_plan_k_factor(line)
    response = infer_plan_response(line)
    orientation = infer_plan_orientation(line)
    sprinkler_type = infer_plan_sprinkler_type(line)
    if not any([model, k_factor, response, orientation, sprinkler_type]):
        return {}
    # A line that only carries orientation/response/coverage words ("STANDARD-SPRAY
    # PENDENT SPRINKLER", "HORIZONTAL SIDEWALL SPRINKLER") is general-notes prose,
    # not a head on the schedule. Without a maker, model, or K-factor it cannot name
    # a product, and downstream it only ever matched the wrong manufacturer.
    if not model and not manufacturer and not k_factor:
        return {}
    confidence = "exact" if model else "criteria"
    return {
        "manufacturer": manufacturer,
        "model": model,
        "kFactor": k_factor,
        "response": response,
        "orientation": orientation,
        "type": sprinkler_type,
        "sourceLine": line[:220],
        "confidence": confidence,
    }

def infer_plan_sprinkler_manufacturer(line: str) -> str:
    aliases = {
        "Viking": [r"Viking"],
        "Victaulic": [r"Victaulic"],
        "Tyco": [r"Tyco"],
        "Reliable": [r"Reliable"],
        "Senju": [r"Senju(?:\s+Sprinkler)?"],
        "Globe": [r"Globe"],
    }
    for manufacturer, patterns in aliases.items():
        if any(re.search(rf"\b{pattern}\b", line, re.IGNORECASE) for pattern in patterns):
            return manufacturer
    return ""

def canonical_plan_sprinkler_manufacturer(value: str) -> str:
    return infer_plan_sprinkler_manufacturer(value) or format_company_name(value)

def is_plan_sprinkler_manufacturer(value: str) -> bool:
    return bool(infer_plan_sprinkler_manufacturer(value))

def infer_plan_sprinkler_model(line: str) -> str:
    patterns = [
        r"\bVK\d{2,5}[A-Z0-9/-]*\b",
        r"\bR[A-Z]?\d{4}\b",
        r"\bRA\d{3,5}[A-Z0-9/-]*\b",
        r"\bF\dFR\d+[A-Z0-9/-]*\b",
        r"\bRFC\d+[A-Z0-9/-]*\b",
        r"\bTY\d{3,5}[A-Z0-9/-]*\b",
        r"\bTY-[A-Z0-9/-]+(?:\s*[A-Z0-9/-]+)?\b",
        r"\bV\d{3,4}[A-Z0-9/-]*\b",
        r"\bSS\d{3,5}\b",
        r"\bRC[-A-Z0-9/]+",
        r"\bFL-[A-Z0-9/]+",
    ]
    for pattern in patterns:
        match = re.search(pattern, line, re.IGNORECASE)
        if match:
            model = match.group(0).upper().replace(" ", "")
            if model in {"TYPESIZE", "SYMBOL", "MODEL"}:
                continue
            return model
    return ""

def parse_sprinkler_legend_tables(lines: list[str]) -> list[dict]:
    records = []
    header_pattern = re.compile(
        r"^(?:symbol|symb\.?|manufacturer|mfr|sin|model|model\s*/\s*s\.?i\.?n\.?|quantity|quant\.?|qty\.?|count|k[- ]?factor|k[- ]?fac|type|style|size|response|resp\.?|finish|temperature|temp\.?|note|sprinkler orientation)$",
        re.IGNORECASE,
    )
    stop_pattern = re.compile(r"^(?:total\b|revision\b|drawing index\b|project design data\b|job number\b|scale\b|building section\b)", re.IGNORECASE)

    for index, line in enumerate(lines):
        if not re.fullmatch(r"(?:automatic\s+fire\s+)?sprinkler\s+legend|project total sprinkler schedule", line.strip(), re.IGNORECASE):
            continue
        tokens = []
        for candidate in lines[index + 1 : index + 120]:
            if stop_pattern.search(candidate) and tokens:
                break
            if header_pattern.fullmatch(candidate.strip()):
                continue
            if candidate.strip() in {"˝", "½", "1/2", "1", "~"}:
                continue
            if re.fullmatch(r"\d{1,3}(?:°F?)?", candidate.strip(), re.IGNORECASE) and not tokens:
                continue
            tokens.append(candidate.strip())

        cursor = 0
        while cursor < len(tokens):
            if not is_plan_sprinkler_manufacturer(tokens[cursor]):
                cursor += 1
                continue
            start = cursor
            manufacturer = canonical_plan_sprinkler_manufacturer(tokens[cursor])
            cursor += 1
            row = [manufacturer]
            while cursor < len(tokens) and not is_plan_sprinkler_manufacturer(tokens[cursor]):
                if stop_pattern.search(tokens[cursor]):
                    break
                row.append(tokens[cursor])
                cursor += 1
            record = sprinkler_record_from_table_row(row)
            if record:
                records.append(record)
            if cursor == start:
                cursor += 1
    return records

def sprinkler_record_from_table_row(row: list[str]) -> dict:
    if len(row) < 4:
        return {}
    manufacturer = infer_plan_sprinkler_manufacturer(" ".join(row)) or row[0]
    model_candidates = []
    for value in row[1:]:
        model = infer_plan_sprinkler_model(value)
        if model and model not in model_candidates:
            model_candidates.append(model)
    model = model_candidates[0] if model_candidates else ""
    k_factor = next((infer_plan_k_factor(value) for value in row if infer_plan_k_factor(value)), "")
    response = next((infer_plan_response(value) for value in row if infer_plan_response(value)), "")
    orientation = infer_plan_orientation(" ".join(row))
    sprinkler_type = infer_plan_sprinkler_type(" ".join(row))
    if not any([model, k_factor, response, orientation, sprinkler_type]):
        return {}
    return {
        "manufacturer": manufacturer,
        "model": model,
        "modelCandidates": model_candidates,
        "kFactor": k_factor,
        "response": response,
        "orientation": orientation,
        "type": sprinkler_type,
        "sourceLine": " ".join(row)[:220],
        "confidence": "exact" if model else "criteria",
    }

def infer_plan_k_factor(line: str) -> str:
    match = re.search(r"\bK(?:-?FAC(?:TOR)?|[-\s])?\s*[:=]?\s*(\d{1,2}(?:\.\d+)?)\b", line, re.IGNORECASE)
    if not match:
        match = re.search(r"(?<![\d.])(2\.8|3\.7|4\.2|4\.9|5\.6|8\.0|8\.1|11\.2|14\.0|16\.8|19\.6|22\.4|25\.2)(?![\d.])", line)
    return match.group(1) if match else ""

def infer_plan_response(line: str) -> str:
    if re.search(r"\b(quick response|quick|qr)\b", line, re.IGNORECASE):
        return "Quick"
    if re.search(r"\b(fast response|fast|fr)\b", line, re.IGNORECASE):
        return "Fast"
    if re.search(r"\b(standard response|standard|sr)\b", line, re.IGNORECASE):
        return "Standard"
    return ""

def infer_plan_orientation(line: str) -> str:
    text = line.lower()
    terms = []
    checks = [
        ("horizontal sidewall", ["horizontal sidewall", "hsw", "sdwl"]),
        ("vertical sidewall", ["vertical sidewall", "vsw"]),
        ("sidewall", ["sidewall"]),
        ("concealed pendent", ["concealed pendent", "concealed dry-pendent", "rdp", "fdp"]),
        ("dry pendent", ["dry pendent", "dry-pendent"]),
        ("dry upright", ["dry upright", "dry-upright"]),
        ("pendent", ["pendent", "ssp", "rdp", "fdp"]),
        ("upright", ["upright", "ssu"]),
        ("recessed", ["recessed"]),
        ("concealed", ["concealed"]),   # "coin" used to be an OCR alias and matched the real word
    ]
    for label, needles in checks:
        if any(re.search(rf"\b{re.escape(needle)}\b", text) for needle in needles):
            terms.append(title_case(label))
    return ", ".join(dict.fromkeys(terms))

def infer_plan_sprinkler_type(line: str) -> str:
    text = line.lower()
    if re.search(r"\besfr\b", text):
        return "ESFR"
    if re.search(r"\bextended coverage\b|\bec\b", text):
        return "Extended Coverage"
    if re.search(r"\bresidential\b|\b[A-Z]{2,4}-RES\b|\bRFC\d+", line, re.IGNORECASE):
        return "Residential"
    if re.search(r"\battic\b|\bcoin\b|\bspecial application\b|\bspecific application\b", text):
        return "Special Application"
    if re.search(r"\bcmsa\b", text):
        return "CMSA"
    return "Standard Coverage" if re.search(r"\bupright|pendent|sidewall|sprinkler\b", text) else ""

def dedupe_sprinkler_records(records: list[dict]) -> list[dict]:
    seen = set()
    result = []
    for record in records:
        key = tuple(normalize_text(record.get(field, "")) for field in ["manufacturer", "model", "kFactor", "response", "orientation", "type"])
        if key in seen:
            continue
        seen.add(key)
        result.append(record)
    return result

def prune_loose_sprinkler_records(records: list[dict]) -> list[dict]:
    contextual_models = {
        normalize_text(record.get("model", ""))
        for record in records
        if record.get("model") and record.get("manufacturer") and record.get("kFactor") and (record.get("orientation") or record.get("response"))
    }
    result = []
    for record in records:
        model_key = normalize_text(record.get("model", ""))
        has_context = bool(record.get("manufacturer") and record.get("kFactor") and (record.get("orientation") or record.get("response")))
        if model_key in contextual_models and not has_context:
            continue
        if is_broad_plan_sprinkler_family(record.get("model", "")) and not has_context:
            continue
        result.append(record)
    return result

def is_broad_plan_sprinkler_family(value: str) -> bool:
    return bool(re.fullmatch(r"(?:FL|RC)[-/A-Z0-9]*", value or "", re.IGNORECASE))

def infer_plan_pipe_types(text: str) -> list[dict]:
    checks = [
        ("CPVC", r"\bcpvc\b|\bblazemaster\b|\bflameguard\b"),
        ("C900", r"\bc[-\s]?900\b|\bblue brute\b"),
        ("Ductile Iron", r"\bductile iron\b|\bd\.?i\.?\b"),
        ("Sch. 10", r"\bsch(?:edule)?\.?\s*10\b"),
        ("Sch. 40", r"\bsch(?:edule)?\.?\s*40\b"),
        ("Sch. 10 / Sch. 40 Steel", r"\b(?:black\s+)?steel pipes?\b|\bsteel sprinkler pipes?\b"),
        ("Mega-Flow", r"\bmega[-\s]?flow\b"),
        ("Mega-Thread", r"\bmega[-\s]?thread\b"),
        ("Eddy-Flow", r"\beddy[-\s]?flow\b"),
        ("Eddy-Thread", r"\beddy[-\s]?thread\b"),
    ]
    results = []
    for label, pattern in checks:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            results.append({"pipeType": label, "sourceText": match.group(0)})
    return results

def infer_plan_catalog_terms(text: str, category: str) -> list[dict]:
    checks_by_category = {
        "Fittings": [
            ("Grooved Flexible Couplings", r"\b(?:grooved\s+)?flex(?:ible)?\s+couplings?\b|\bflex\s+couplings?\b"),
            ("Grooved Rigid Couplings - Push-On", r"\bpush[-\s]?on\b.{0,40}\bcouplings?\b|\bcouplings?\b.{0,40}\bpush[-\s]?on\b"),
            ("Grooved Rigid Couplings", r"\b(?:grooved\s+)?rigid\s+couplings?\b|\bcouplings?\b.{0,40}\brigid\b"),
            ("Grooved Fittings", r"\bgrooved fittings?\b|\bgrooved couplings?\b"),
            ("Mechanical Tee", r"\bmechanical tees?\b"),
            ("Threaded Fittings", r"\bthreaded fittings?\b|\b(?:ductile|cast|malleable)\s+iron\b.{0,50}\bthreaded\b|\bthreaded\b.{0,50}\b(?:ductile|cast|malleable)\s+iron\b"),
        ],
        "Hangers": [
            ("Beam Clamp", r"\bbeam clamps?\b"),
            ("All Thread Hanger", r"\ball[-\s]?thread\b.{0,40}\bhangers?\b"),
            ("Hanger Rod", r"\bhanger rods?\b|\bthreaded rods?\b"),
            ("Fig. 200", r"\bring hangers?\b"),
            ("Clevis Hanger", r"\bclevis hangers?\b"),
            ("Sammy", r"\bsammy\b"),
        ],
        "Bracing": [
            ("Lateral Brace", r"\blateral braces?\b|\blateral earthquake brac(?:e|ing)\b"),
            ("Longitudinal Brace", r"\blongitudinal braces?\b|\blongitudinal earthquake brac(?:e|ing)\b"),
            ("4-Way Brace", r"\b4[-\s]?way braces?\b|\bfour[-\s]?way braces?\b"),
            ("Branch Line Restraint", r"\bbranch line restraints?\b|\bblr\b"),
            ("Sway Brace", r"\bsway braces?\b"),
        ],
        "Valves": [
            ("Victaulic UMC Riser", r"\b(?:victaulic\s+)?umc\b|\buniversal manifold check\b"),
            ("Viking EasyPac Riser", r"\b(?:viking\s+)?easypac\b"),
            ("Riser Assembly", r"\briser assembl(?:y|ies)\b|\briser manifold\b"),
            ("Tamper Switch", r"\btamper switch(?:es)?\b|\bsupervisory switch(?:es)?\b"),
            ("Butterfly Valve", r"\bbutterfly valves?\b"),
            ("Check Valve", r"\bcheck valves?\b"),
            ("Gate Valve", r"\bgate valves?\b|\bos\s*&\s*y\b|\bosy\b|\bnrs\b"),
            ("Dry Pipe Valve", r"\bdry pipe valves?\b"),
            ("Deluge Valve", r"\bdeluge valves?\b"),
            ("Backflow", r"\bbackflow\b|\bdouble check\b|\brp(?:z)?\b"),
            ("Test N Drain", r"\btest\s*(?:and|n|&)\s*drain\b"),
            ("Air Vent", r"\bair vents?\b|\bautomatic air vents?\b"),
            ("Pressure Relief Valve", r"\bpressure relief valves?\b"),
        ],
        "Miscellaneous": [
            ("Alarm Bell", r"\balarm bells?\b|\bfire bells?\b|\bgong\b|\belectric bells?\b|\bwater motor gong\b"),
            ("Horn Strobe", r"\bhorn strobes?\b|\bstrobes?\b"),
            ("Head Cabinet", r"\bhead cabinets?\b|\bsprinkler cabinets?\b|\bspare sprinkler\b.{0,40}\bcabinets?\b"),
            ("Head Guard", r"\bhead guards?\b|\bsprinkler guards?\b"),
            ("Identification Signs", r"\bidentification signs?\b|\bsigns?\b"),
        ],
    }
    results = []
    seen = set()
    source = re.sub(r"\s+", " ", text or "")

    def add_result(label: str, source_text: str) -> None:
        key = normalize_text(label)
        if key in seen:
            return
        seen.add(key)
        results.append({
            "category": category,
            "term": label,
            "sourceText": source_text[:180],
        })

    if category in {"Hangers", "Bracing"}:
        fig_pattern = re.compile(r"\b(?:tolco\s+)?fig(?:ure)?\.?\s*([0-9]{1,4}[A-Z]?)\b", re.IGNORECASE)
        hanger_figs = {"2", "22", "23", "25", "28", "29", "51", "58", "65", "66", "67SS", "68SS", "69", "69R", "78", "130", "200", "200C", "200F", "200H", "200S", "B3033", "B3034", "B3037", "B3042T"}
        bracing_figs = {"4", "4A", "4L", "4LA", "6", "131", "800", "825", "825A", "828", "909", "906", "980", "980H", "1001", "3000"}
        target_figs = hanger_figs if category == "Hangers" else bracing_figs
        for match in fig_pattern.finditer(source):
            model = match.group(1).upper()
            if model in target_figs:
                add_result(f"Fig. {model}", match.group(0))
        if category == "Hangers":
            for match in re.finditer(r"\bB30(?:33|34|37|42T)\b", source, re.IGNORECASE):
                add_result(match.group(0).upper(), match.group(0))
        else:
            for match in re.finditer(r"\bAF0\d{2,3}\b", source, re.IGNORECASE):
                add_result(match.group(0).upper(), match.group(0))

    for label, pattern in checks_by_category.get(category, []):
        match = re.search(pattern, source, re.IGNORECASE)
        if not match:
            continue
        add_result(label, match.group(0))
    return results[:12]

# --- Rendered-detail detections ---------------------------------------------
#
# Everything below reads the text that came back from OCR'ing the plan's
# EMBEDDED RASTERS (see plan_detail_ocr.py). That text is a second, weaker
# source than the PDF's own glyphs, so it is kept on its own track:
#
#   * it feeds CATALOG TERM inference only - never the project name or address.
#     A tesseract guess must not be allowed to outvote the title block, and the
#     name/address accuracy bench has to stay bit-for-bit unchanged.
#   * every detection it produces is tagged with where it was read, so the
#     review dialog can show the customer the crop it came off.
#
# None of this runs in the browser edition: with no OCR hook there are no
# regions, every function here is handed an empty list, and the scan produces
# exactly what it produced before.

#: What a review row says about a detection's origin.
DETAIL_SOURCE_LABEL = "OCR of rendered detail"
BRACING_CALC_SOURCE_LABEL = "OCR of calc sheet"
PLAN_TEXT_SOURCE_LABEL = "plan text"

#: Ceiling on a merged (text + OCR) detection list for one category. The text
#: pass alone caps at 12; the OCR pass may legitimately add a few more, but a
#: review dialog with forty bracing rows helps nobody.
PLAN_CATALOG_TERM_LIMIT = 18


def detail_region_source(region: dict, label: str = DETAIL_SOURCE_LABEL) -> dict:
    """The provenance stamp carried by every detection read out of a region."""
    return {
        "kind": "detail-ocr",
        "label": label,
        "page": region.get("page"),
        "regionId": region.get("id"),
        "provenanceKey": region.get("id"),
    }


def infer_plan_catalog_terms_from_regions(regions: list, category: str) -> list[dict]:
    """Run the ordinary catalog-term rules over each OCR'd region separately.

    Per REGION, not over one concatenated blob: the region is what gives the
    detection a page and a box, and a row the customer cannot trace back to a
    place on the sheet is a row they have to go and verify by hand anyway.
    """
    results = []
    for region in regions or []:
        text = region.get("text") or ""
        if not text.strip():
            continue
        for term in infer_plan_catalog_terms(text, category):
            term["source"] = detail_region_source(region)
            results.append(term)
    return results


def merge_plan_catalog_terms(primary: list, extra: list, limit: int = PLAN_CATALOG_TERM_LIMIT) -> list[dict]:
    """Text-layer detections first, OCR detections appended if they are new.

    Same term from both sources = the text one wins, because it keeps the
    stronger provenance and the exact plan wording.
    """
    merged = list(primary or [])
    seen = {normalize_text(entry.get("term", "")) for entry in merged}
    for entry in extra or []:
        key = normalize_text(entry.get("term", ""))
        if not key or key in seen:
            continue
        seen.add(key)
        merged.append(entry)
    return merged[:limit]


def infer_plan_pipe_types_from_regions(regions: list) -> list[dict]:
    results = []
    for region in regions or []:
        text = region.get("text") or ""
        if not text.strip():
            continue
        for record in infer_plan_pipe_types(text):
            record["source"] = detail_region_source(region)
            results.append(record)
    return results


def merge_plan_pipe_types(primary: list, extra: list) -> list[dict]:
    merged = list(primary or [])
    seen = {normalize_text(entry.get("pipeType", "")) for entry in merged}
    for entry in extra or []:
        key = normalize_text(entry.get("pipeType", ""))
        if not key or key in seen:
            continue
        seen.add(key)
        merged.append(entry)
    return merged


def infer_plan_sprinklers_from_regions(regions: list) -> list[dict]:
    """Sprinkler legend rows read out of a rendered legend TABLE.

    Deliberately strict: an OCR'd row only counts when it names a model. The
    legend parser is happy to emit a record with a manufacturer and nothing
    else, which is useful when the plan's own text is the source and pure noise
    when the source is tesseract reading a table rule as a letter.
    """
    results = []
    for region in regions or []:
        text = region.get("text") or ""
        if not text.strip():
            continue
        for record in infer_plan_sprinkler_legend(text):
            if not (record.get("model") or "").strip():
                continue
            record["source"] = detail_region_source(region)
            results.append(record)
    return results


def merge_plan_sprinklers(primary: list, extra: list) -> list[dict]:
    merged = list(primary or [])
    seen = {
        (normalize_text(entry.get("manufacturer", "")), normalize_text(entry.get("model", "")))
        for entry in merged
    }
    for entry in extra or []:
        key = (normalize_text(entry.get("manufacturer", "")), normalize_text(entry.get("model", "")))
        if key in seen:
            continue
        seen.add(key)
        merged.append(entry)
    return merged


def infer_seismic_bracing(plan_text: str, regions: list | None = None) -> dict:
    """The seismic-bracing answer: which components, from which calc sheet.

    A sway brace IS a lateral or longitudinal brace - they are the same object,
    and listing both as separate generic "detections" told the customer nothing
    they did not already know. What they actually need is the MODEL NUMBERS off
    the bracing calc sheet the plan set carries, because those are the parts
    that get submitted and bought.

    Returns a record even when nothing specific was found, so the caller can
    tell "no calc sheet on this set" from "bracing was switched off".
    """
    regions = regions or []
    components: dict = {}
    calc_pages: list[dict] = []
    calc_texts: list[str] = []

    def absorb(models: list, source: dict, label: str) -> None:
        for model in models:
            key = (model["manufacturer"], model["token"])
            existing = components.get(key)
            if existing is None:
                model = dict(model)
                model["source"] = dict(source, label=label)
                components[key] = model
                continue
            existing["hits"] += model.get("hits", 1)
            if model["sourceKind"] == "text" and existing["sourceKind"] != "text":
                existing["sourceKind"] = "text"
                existing["source"] = dict(source, label=label)
            existing["confidence"] = _bracing_vocab.model_confidence(existing)

    text_models = _bracing_vocab.find_bracing_models(plan_text or "", "text")
    absorb(text_models, {"kind": "pdf-text", "provenanceKey": ""}, PLAN_TEXT_SOURCE_LABEL)

    for region in regions:
        text = region.get("text") or ""
        if not text.strip():
            continue
        score = _bracing_vocab.bracing_calc_score(text)
        is_calc = score >= 2
        models = _bracing_vocab.find_bracing_models(text, "ocr")
        if is_calc:
            calc_texts.append(text)
            calc_pages.append({
                "page": region.get("page"),
                "regionId": region.get("id"),
                "score": score,
                "markers": _bracing_vocab.bracing_calc_markers(text),
                "models": len(models),
            })
        if models:
            absorb(models, detail_region_source(region, BRACING_CALC_SOURCE_LABEL if is_calc else DETAIL_SOURCE_LABEL),
                   BRACING_CALC_SOURCE_LABEL if is_calc else DETAIL_SOURCE_LABEL)

    found = list(components.values())
    manufacturer = _bracing_vocab.dominant_bracing_manufacturer(found)
    if manufacturer:
        # A stray model from another maker on a sheet that is plainly one
        # maker's calc is noise, not a second assembly.
        found = [entry for entry in found if entry["manufacturer"] == manufacturer]
    order = {role: index for index, role in enumerate(_bracing_vocab.BRACING_ROLE_ORDER)}
    found.sort(key=lambda entry: (order.get(entry["role"], 99), entry["model"]))

    # The calc sheet that actually carries models beats one that merely reads
    # like a calc: a sheet note saying "SEISMIC BRACING PER NFPA 13" scores as
    # a calc and names nothing.
    calc_pages.sort(key=lambda entry: (entry["models"] > 0, entry["score"]), reverse=True)
    best_calc = calc_pages[0] if calc_pages else None

    calc_blob = "\n".join(calc_texts)
    return {
        "detected": bool(found),
        "manufacturer": manufacturer,
        "catalogManufacturer": _bracing_vocab.BRACING_CATALOG_MANUFACTURER.get(manufacturer, ""),
        "calcSheetPage": (best_calc or {}).get("page") or None,
        "calcSheetRegionId": (best_calc or {}).get("regionId") or "",
        "calcSheetFound": bool(calc_pages),
        "calcSheets": calc_pages[:4],
        "braceTypes": _bracing_vocab.brace_types(calc_blob or plan_text or ""),
        "braceMember": _bracing_vocab.brace_member_from_text(calc_blob),
        "components": found,
        "source": (
            BRACING_CALC_SOURCE_LABEL if (best_calc and best_calc.get("models"))
            else (DETAIL_SOURCE_LABEL if any(c.get("sourceKind") == "ocr" for c in found)
                  else (PLAN_TEXT_SOURCE_LABEL if found else ""))
        ),
    }


def bracing_component_detections(seismic: dict) -> list[dict]:
    """Turn the found components into ordinary catalog-term detections so the
    review dialog can match each one to a datasheet with no new plumbing."""
    detections = []
    for component in (seismic or {}).get("components") or []:
        detections.append({
            "category": "Bracing",
            "term": component["model"],
            "model": component["model"],
            "manufacturer": component["manufacturer"],
            "catalogManufacturer": _bracing_vocab.BRACING_CATALOG_MANUFACTURER.get(component["manufacturer"], ""),
            "role": component["role"],
            "roleLabel": component["roleLabel"],
            "product": component["name"],
            "confidence": component.get("confidence", "medium"),
            "hits": component.get("hits", 1),
            "seismicBracing": True,
            "sourceText": (component.get("sourceText") or component["model"])[:180],
            "source": component.get("source") or {},
        })
    return detections


# --- Title-block extraction -------------------------------------------------
#
# pypdf's extract_text(visitor_text=...) reports the TEXT matrix translation,
# which on CAD plan sets is a near-zero local offset inside a nested form
# XObject - every glyph on a 3456pt page comes back with x in 0..48, so a
# page-fraction zone test can never fire. pdfminer.six resolves the full CTM
# chain and reports true page coordinates, so the title block is read from
# pdfminer glyph positions. pdfminer is imported lazily (it costs ~0.3s to
# import) and the pypdf path stays as a fallback for bundles that ship without
# it - notably the browser/Pyodide edition, where plan_scan_core also runs.

TITLE_BLOCK_MAX_SHEETS = 5
TITLE_BLOCK_TIME_BUDGET_SECONDS = 30.0
_TITLE_BLOCK_CACHE: dict = {}
_TITLE_BLOCK_CACHE_LIMIT = 4


def _char_rotation(matrix) -> int:
    """0/1/2/3 quarter turns counter-clockwise from upright."""
    a = matrix[0]
    b = matrix[1]
    if abs(a) >= abs(b):
        return 0 if a >= 0 else 2
    return 1 if b >= 0 else 3


def _title_block_char_record(char) -> dict:
    """Flatten a pdfminer LTChar into a plain dict so the line assembler stays
    testable without pdfminer. `base` is the BASELINE coordinate taken from the
    glyph matrix, never the bbox: for rotated text the bbox spans the glyph
    height along the page axis, so bbox-grouping shreds a line whenever the
    font size changes mid-line (which title blocks do constantly)."""
    matrix = char.matrix
    rot = _char_rotation(matrix)
    x0, y0, x1, y1 = float(char.x0), float(char.y0), float(char.x1), float(char.y1)
    if rot == 0:
        base, lead, trail = float(matrix[5]), x0, x1
    elif rot == 1:
        base, lead, trail = float(matrix[4]), y0, y1
    elif rot == 2:
        base, lead, trail = float(matrix[5]), -x1, -x0
    else:
        base, lead, trail = float(matrix[4]), -y1, -y0
    return {
        "text": char.get_text(),
        "rot": rot,
        "base": base,
        "lead": lead,
        "trail": trail,
        "size": float(getattr(char, "size", 0.0)) or 1.0,
        "font": str(getattr(char, "fontname", "") or ""),
        "x0": x0,
        "y0": y0,
        "x1": x1,
        "y1": y1,
    }


def assemble_title_block_lines(chars: list[dict]) -> list[dict]:
    """Group glyphs into text lines: by ROTATION first, then baseline, then
    reading order. Title-block labels are routinely lettered vertically, so
    without the rotation split "JOB NO" arrives as O, B, O, J on four lines and
    interleaves garbage into the horizontal lines it crosses."""
    lines: list[dict] = []
    for rot in (0, 1, 2, 3):
        group = [char for char in chars if char["rot"] == rot]
        if not group:
            continue
        group.sort(key=lambda char: (round(char["base"], 1), char["lead"]))
        run: list[dict] = []
        for char in group:
            if run:
                previous = run[-1]
                gap = char["lead"] - previous["trail"]
                # NB: do NOT also split on a font-size change. Title-block
                # templates routinely set a field's first letter in a different
                # size ("S" + "TOCKTON, CA"), so size-splitting shreds more
                # lines than it separates. Glued neighbouring fields are dealt
                # with by the heading prefixes in is_title_block_heading().
                same_line = (
                    abs(previous["base"] - char["base"]) <= max(1.5, 0.2 * char["size"])
                    and gap <= max(3.0, 1.6 * char["size"])
                )
                if not same_line:
                    lines.append(_title_block_line(run, rot))
                    run = []
            run.append(char)
        if run:
            lines.append(_title_block_line(run, rot))
    return [line for line in lines if line["text"]]


def _title_block_line(run: list[dict], rot: int) -> dict:
    text = ""
    previous = None
    for char in run:
        if previous is not None and (char["lead"] - previous["trail"]) > 0.22 * char["size"]:
            text += " "
        text += char["text"]
        previous = char
    return {
        "text": " ".join(text.split()),
        "rot": rot,
        "base": run[0]["base"],
        "lead": run[0]["lead"],
        "size": max(char["size"] for char in run),
        "chars": len(run),
        "x0": min(char["x0"] for char in run),
        "y0": min(char["y0"] for char in run),
        "x1": max(char["x1"] for char in run),
        "y1": max(char["y1"] for char in run),
    }


def order_title_block_lines(lines: list[dict]) -> list[list[dict]]:
    """Reading-order line lists, one per rotation present. Rotation groups are
    kept apart so label/value adjacency is never computed across two blocks of
    text that only look adjacent once they are flattened into one string."""
    groups = []
    for rot in (0, 1, 2, 3):
        group = [line for line in lines if line["rot"] == rot]
        if not group:
            continue
        # Next-line direction: down for upright text, +x for 90deg, up for
        # 180deg, -x for 270deg.
        descending = rot in (0, 3)
        group.sort(key=lambda line: ((-line["base"]) if descending else line["base"], line["lead"]))
        groups.append(group)
    return groups


def _occupancy_gutters(intervals: list[tuple], extent: float, min_gap: float) -> list[float]:
    """Coordinates where text resumes after a run of empty space. A title block
    is fenced off from the drawing by a border rule, so its edge is a gutter."""
    size = int(extent) + 2
    if size <= 2:
        return []
    delta = [0] * (size + 1)
    for start, end in intervals:
        low = max(0, min(size - 1, int(start)))
        high = max(low + 1, min(size, int(end) + 1))
        delta[low] += 1
        delta[high] -= 1
    boundaries = []
    running = 0
    gap_start = 0
    was_empty = True
    for position in range(size):
        running += delta[position]
        empty = running <= 0
        if empty and not was_empty:
            gap_start = position
        elif not empty and was_empty:
            if position - gap_start >= min_gap:
                boundaries.append(float(position))
        was_empty = empty
    return boundaries


# Field labels that only ever appear inside a title block or its border strip.
# They are the anchor used to locate the block; the zone is then grown out to
# the nearest gutter so no field of the block is clipped off.
TITLE_BLOCK_ANCHOR_RE = re.compile(
    r"\b(?:"
    r"sheet\s*(?:no|number|title|name)|project\s*(?:title|name|no|number|info(?:rmation)?)|"
    r"job\s*(?:no|number|name|id|info)|drawn\s+by|design(?:ed)?\s+by|checked\s+by|approved\s+by|"
    r"drawing\s+scale|date\s+last\s+revised|document\s+date|issued\s+for|proj\.?\s*no|"
    r"revisions?|approvals?|sheet\s*:\s*\d+\s+of\s+\d+|plot\s+date|as\s+noted"
    r")\b",
    re.IGNORECASE,
)


def _snap_to_gutter(edge: float, gutters: list[float], reach: float) -> float:
    """Pull a zone edge outwards to the nearest empty band, so a field that
    starts a little further out than the anchor is still inside the zone."""
    below = [value for value in gutters if value <= edge + 1.0 and value >= edge - reach]
    return min(below) if below else edge


def _anchor_zone(lines: list[dict], extent: float, axis: str) -> list[dict]:
    if not lines or extent <= 0:
        return []
    # Title-block field labels are SHORT. Without the length cap the copyright
    # boilerplate ("...without the written consent & approval of ...") reads as
    # an "approval" anchor and drags the zone edge across half the sheet.
    def is_anchor(line: dict) -> bool:
        return len(line["text"]) <= 48 and bool(TITLE_BLOCK_ANCHOR_RE.search(line["text"]))

    if axis == "x":
        anchors = [line for line in lines if line["x0"] >= extent * 0.50 and is_anchor(line)]
    else:
        anchors = [line for line in lines if line["y1"] <= extent * 0.50 and is_anchor(line)]
    if len(anchors) < 2:
        return []
    key = "x0" if axis == "x" else "y1"
    positions = sorted(line[key] for line in anchors)
    middle = positions[len(positions) // 2]
    # Drop stragglers: an anchor far outside the pack is not part of this block.
    anchors = [line for line in anchors if abs(line[key] - middle) <= extent * 0.18]
    if len(anchors) < 2:
        return []
    if axis == "x":
        edge = min(line["x0"] for line in anchors)
        gutters = _occupancy_gutters(
            [(line["x0"], line["x1"]) for line in lines], extent, max(3.0, extent * 0.0015)
        )
        edge = _snap_to_gutter(edge, gutters, extent * 0.05)
        edge = max(edge, extent * 0.45)
        return [line for line in lines if line["x0"] >= edge - 0.5]
    edge = max(line["y1"] for line in anchors)
    gutters = _occupancy_gutters(
        [(line["y0"], line["y1"]) for line in lines], extent, max(3.0, extent * 0.0015)
    )
    upper = [value for value in gutters if value >= edge - 1.0 and value <= edge + extent * 0.05]
    edge = max(upper) if upper else edge
    edge = min(edge, extent * 0.55)
    return [line for line in lines if line["y1"] <= edge + 0.5]


def detect_title_block_zone(lines: list[dict], width: float, height: float) -> list[dict]:
    """Adaptive title-block zone. Replaces the old hardcoded 0.88 / 0.45 / 0.22
    page fractions, and works the same on landscape, portrait and /Rotate'd
    sheets because pdfminer has already resolved the page rotation."""
    right = _anchor_zone(lines, width, "x")
    bottom = _anchor_zone(lines, height, "y")
    if right or bottom:
        # Union, not pick-one. Title blocks are frequently an L - a right-edge
        # strip whose lower corner carries the sheet/issue boxes - and the two
        # halves each look like a complete block to the anchor test. Choosing
        # the one with more anchors picked the bottom corner on a STERNCO sheet
        # and clipped the project name off the top of the right strip.
        chosen = {id(line): line for line in right}
        chosen.update({id(line): line for line in bottom})
        union = [line for line in lines if id(line) in chosen]
        total = sum(line["chars"] for line in lines) or 1
        if sum(line["chars"] for line in union) <= total * 0.85:
            return union
        return right or bottom
    # No anchors found (sparse or badly encoded sheet): fall back to generous
    # fixed strips so the ranker still sees something rather than nothing.
    return [line for line in lines if line["x0"] >= width * 0.78 or line["y1"] <= height * 0.20]


def _title_block_sheet(chars: list[dict], width: float, height: float, sheet: int) -> dict:
    lines = assemble_title_block_lines(chars)
    zone = detect_title_block_zone(lines, width, height) or lines
    groups = order_title_block_lines(zone)
    return {
        "sheet": sheet,
        "width": width,
        "height": height,
        "groups": [[line["text"] for line in group] for group in groups],
        "lineGroups": groups,
        "lines": zone,
        "text": "\n".join(line["text"] for group in groups for line in group),
    }


def _pdfminer_title_block_sheets(path: Path, max_sheets: int, time_budget: float) -> list[dict]:
    import time as _time

    from pdfminer.converter import PDFLayoutAnalyzer
    from pdfminer.layout import LTChar
    from pdfminer.pdfinterp import PDFPageInterpreter, PDFResourceManager
    from pdfminer.pdfpage import PDFPage

    class _CharOnlyDevice(PDFLayoutAnalyzer):
        """Collects glyphs and nothing else. CAD sheets are mostly vector
        paths; building LTCurve objects for them is pure waste here."""

        def __init__(self, rsrcmgr):
            super().__init__(rsrcmgr, pageno=1, laparams=None)
            self.chars: list[dict] = []

        def paint_path(self, *args, **kwargs):
            return

        def render_image(self, *args, **kwargs):
            return

        def receive_layout(self, ltpage):
            return

        def render_char(self, matrix, font, fontsize, scaling, rise, cid, ncs, graphicstate):
            try:
                text = font.to_unichr(cid)
            except Exception:
                text = ""
            textwidth = font.char_width(cid)
            item = LTChar(
                matrix,
                font,
                fontsize,
                scaling,
                rise,
                text if isinstance(text, str) else "",
                textwidth,
                font.char_disp(cid),
                ncs,
                graphicstate,
            )
            if item.get_text().strip():
                self.chars.append(_title_block_char_record(item))
            return item.adv

    # Cost is dominated by content-stream tokenisation, which on a 3456x2592
    # CAD sheet runs 10-20s (4M+ tokens, mostly path coordinates). Sheet 1 is
    # always read; every sheet after it has to fit in the remaining budget at
    # the cost the previous sheet actually took. Cheap sheets get all 5 for
    # cross-sheet consensus; expensive ones stop at one and say so.
    budget = max(1.0, time_budget)
    started = _time.time()
    slowest = 0.0
    sheets = []
    manager = PDFResourceManager(caching=True)
    device = _CharOnlyDevice(manager)
    interpreter = PDFPageInterpreter(manager, device)
    with open(str(path), "rb") as handle:
        for index, page in enumerate(PDFPage.get_pages(handle, maxpages=max(1, max_sheets))):
            elapsed = _time.time() - started
            if sheets and elapsed + slowest > budget:
                break
            page_started = _time.time()
            device.chars = []
            try:
                interpreter.process_page(page)
            except Exception:
                continue
            slowest = max(slowest, _time.time() - page_started)
            width = float(getattr(device.cur_item, "width", 0.0) or 0.0)
            height = float(getattr(device.cur_item, "height", 0.0) or 0.0)
            if device.chars and width > 0 and height > 0:
                sheets.append(_title_block_sheet(device.chars, width, height, index + 1))
    return sheets


def _legacy_title_block_sheets(path: Path, max_sheets: int) -> list[dict]:
    """pypdf fallback for bundles without pdfminer (browser edition). Positions
    are unreliable on CAD sheets, so this keeps the old fixed zone and simply
    returns whatever it can - better than nothing, never better than pdfminer."""
    try:
        reader = PdfReader(str(path))
    except Exception:
        return []
    sheets = []
    for index, page in enumerate(reader.pages[:max(1, max_sheets)]):
        try:
            box = page.mediabox
            width = float(box.width)
            height = float(box.height)
            fragments = []

            def visitor(text, cm, tm, font_dict, font_size):
                clean = " ".join((text or "").split())
                if not clean:
                    return
                x = float(tm[4])
                y = float(tm[5])
                if (x >= width * 0.88 and y <= height * 0.75) or (x >= width * 0.45 and y <= height * 0.22):
                    fragments.append((round(y, 1), round(x, 1), clean))

            page.extract_text(visitor_text=visitor)
            fragments.sort(key=lambda item: (-item[0], item[1]))
            texts = [fragment[2] for fragment in fragments]
            if not texts:
                continue
            sheets.append(
                {
                    "sheet": index + 1,
                    "width": width,
                    "height": height,
                    "groups": [texts],
                    "lines": [],
                    "text": "\n".join(texts),
                }
            )
        except Exception:
            continue
    return sheets


def extract_title_block_sheets(
    path: Path,
    max_sheets: int = TITLE_BLOCK_MAX_SHEETS,
    time_budget: float = TITLE_BLOCK_TIME_BUDGET_SECONDS,
) -> list[dict]:
    """Per-sheet title-block slices with true page coordinates."""
    try:
        stat = Path(path).stat()
        cache_key = (str(path), stat.st_mtime_ns, stat.st_size, max_sheets)
    except Exception:
        cache_key = None
    if cache_key is not None and cache_key in _TITLE_BLOCK_CACHE:
        return _TITLE_BLOCK_CACHE[cache_key]
    try:
        sheets = _pdfminer_title_block_sheets(Path(path), max_sheets, time_budget)
    except ImportError:
        sheets = _legacy_title_block_sheets(Path(path), max_sheets)
    except Exception:
        sheets = []
    if not sheets:
        try:
            sheets = _legacy_title_block_sheets(Path(path), max_sheets)
        except Exception:
            sheets = []
    if cache_key is not None:
        if len(_TITLE_BLOCK_CACHE) >= _TITLE_BLOCK_CACHE_LIMIT:
            _TITLE_BLOCK_CACHE.clear()
        _TITLE_BLOCK_CACHE[cache_key] = sheets
    return sheets


def extract_title_block_text(path: Path) -> str:
    return "\n".join(sheet["text"] for sheet in extract_title_block_sheets(path))

def hydratec_project_fields(lines: list[str]) -> dict:
    """HydraCalc/Hydratec calc sheets label project fields differently: "Job Name"
    is the project name and "Location" is the project address — with the CONTRACTOR'S
    letterhead above them, which the generic address finder latches onto. Only
    engages when a "Job Name" label is present (the Hydratec fingerprint)."""
    def labeled(label_pattern):
        pat = re.compile(r"^\s*" + label_pattern + r"\s*[:=\-]?\s*(.*)$", re.I)
        for index, line in enumerate(lines):
            match = pat.match(line)
            if not match:
                continue
            value = match.group(1).strip(" :-_|\t")
            if value:
                return re.sub(r"\s+", " ", value)
            for next_line in lines[index + 1:index + 3]:
                candidate = next_line.strip()
                if not candidate.startswith(":") and pat.match(candidate):
                    continue
                candidate = candidate.lstrip(" :=-").strip()
                if candidate and not re.match(r"^(?:drawing|contract|data\s+file|remote\s+area)\b", candidate, re.I):
                    return re.sub(r"\s+", " ", candidate)
                break
        return ""
    name = labeled(r"JOB\s+NAME")
    if not name:
        return {}
    return {"name": name, "address": labeled(r"LOCATION")}

# --- Ranking inside the title block -----------------------------------------

_TITLE_BLOCK_LABEL = r"(?:project\s*(?:title|name|info(?:rmation)?|description)?|job\s*(?:name|title|info(?:rmation)?|description)|site\s*name|name\s*of\s*(?:project|job)|building\s*name|facility\s*name)"
TITLE_BLOCK_LABEL_INLINE_RE = re.compile(r"^\s*" + _TITLE_BLOCK_LABEL + r"\s*[:\-]\s*(.+)$", re.IGNORECASE)
TITLE_BLOCK_LABEL_ONLY_RE = re.compile(r"^\s*" + _TITLE_BLOCK_LABEL + r"\s*[:\-]?\s*$", re.IGNORECASE)

# Headings that live inside title blocks and border strips. Each one has been
# observed winning the project-name slot on a real plan set.
TITLE_BLOCK_HEADING_RE = re.compile(
    r"^\s*(?:"
    r"seismic\s+design\s+information|ss\s*value|sds?\s*value|general\s+notes?|sheet\s+index|from\s+supply|"
    r"approvals?|scope\s+of\s+work|key\s*notes?|piping\s+legend|symbol\s+legend|sprinkler\s+legend|"
    r"hydraulic\s+(?:information|calculations?|reference|data)|ahj\s+information|owner\s+information|"
    r"project\s+design\s+data|design\s+(?:data|criteria)|exclusions?|revisions?|issued\s+for|"
    r"drawing\s+scale|sheet\s+title|sheet\s+(?:no|number|name)\.?|proj(?:ect)?\.?\s*no\.?|job\s*(?:no|number|id)\.?|"
    r"design(?:ed)?\s+by|drawn\s+by|checked\s+by|plot\s+date|date\s+last\s+revised|contacts?|"
    r"occupancy\s+classification|brace\s+information|water\s+supply\s+information|abbreviations?|"
    r"vicinity\s+map|location\s+map|deferred\s+submittals?|cover\s+sheet|title\s+sheet|"
    r"fire\s+sprinkler\s+notes?|installation\s+notes?|notes?|legend|specifications?|inspections?|"
    r"date\s+revision|no\.?\s+date\s+revision"
    r")\b\s*[:.]?\s*$",
    re.IGNORECASE,
)

# Headings unmistakable enough to reject a line that merely STARTS with them.
# Title-block boxes abut, so neighbouring fields arrive glued to their heading:
# "REVISIONSSTANDARD SYMBOLS", "DESIGN BYHEAT THROUGHOUT AREAS WHERE",
# "AREA OF WORKW". Anchoring these at the end only would let all of them
# through as project names.
TITLE_BLOCK_HEADING_PREFIX_RE = re.compile(
    r"^\s*(?:"
    r"revisions?|approvals?|scope\s+of\s+work|area\s+of\s+work|general\s+notes?|key\s*notes?|"
    r"sheet\s+index|standard\s+symbols?|symbol\s+legend|piping\s+legend|sprinkler\s+legend|"
    r"seismic\s+design\s+information|hydraulic\s+(?:information|calculations?|data)|"
    r"ahj\s+information|owner\s+information|project\s+design\s+data|design\s+criteria|"
    r"water\s+supply\s+information|occupancy\s+classification|brace\s+information|"
    r"design(?:ed)?\s+by|drawn\s+by|checked\s+by|issued\s+for|drawing\s+scale|"
    r"date\s+last\s+revised|document\s+date|plot\s+date|exclusions?|deferred\s+submittals?|"
    r"sheet\s+title|sheet\s+name|from\s+supply|ss\s*value|"
    # Revision-log descriptions. They sit right beside the project address in
    # a title block and repeat on every sheet, so both the adjacency rule and
    # cross-sheet consensus promote them hard.
    r"(?:added|revised|updated|changed|removed|deleted|corrected|relocated|reissued)\s"
    r")",
    # Deliberately NOT \b-terminated: the whole point is that the next field is
    # glued straight onto the heading with no separator ("AREA OF WORK" + "W",
    # "REVISIONS" + "STANDARD SYMBOLS"), so a word boundary never occurs.
    re.IGNORECASE,
)

# CAD/calc software watermarks. They repeat on every sheet, so cross-sheet
# consensus promotes them hard if they are not excluded outright.
PLAN_SOFTWARE_WATERMARK_RE = re.compile(
    r"\b(?:autosprink|mepcad|autocad|bluebeam|revit|hydracalc|hydratec|sprinkcad|"
    r"fabrication\s+cadmep|elite\s*software|draftlogic)\b|\bv\d+\.\d+\.\d+",
    re.IGNORECASE,
)


def is_title_block_label_line(value: str) -> bool:
    line = (value or "").strip()
    return bool(TITLE_BLOCK_LABEL_ONLY_RE.match(line) or TITLE_BLOCK_LABEL_INLINE_RE.match(line))


# "JOB NO. 3769G", "PROJECT NUMBER 4075", "SHEET NO FP-1.0" - a numbered field,
# never the project name, whatever follows the label.
TITLE_BLOCK_NUMBER_FIELD_RE = re.compile(
    r"^\s*(?:job|proj(?:ect)?\.?|sheet|dwg|drawing|plan|contract|file)\s*(?:no|number|id|#)\b",
    re.IGNORECASE,
)


def is_title_block_heading(value: str) -> bool:
    line = (value or "").strip()
    return bool(
        TITLE_BLOCK_HEADING_RE.match(line)
        or TITLE_BLOCK_HEADING_PREFIX_RE.match(line)
        or TITLE_BLOCK_NUMBER_FIELD_RE.match(line)
        or PLAN_SOFTWARE_WATERMARK_RE.search(line)
    )


def is_title_block_value_continuation(value: str) -> bool:
    """Loose test for the SECOND and later lines of a labelled value."""
    text = (value or "").strip()
    if not text or len(text) > 60:
        return False
    if len(re.findall(r"[A-Za-z]", text)) < 2:
        return False
    if re.search(r"\d{5,}", text):
        return False
    if is_plan_noise_line(text) or find_plan_address(text) or find_city_state_zip(text):
        return False
    if re.search(r"(?:\+?1[\s.-]?)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}", text):
        return False
    if PLAN_SOFTWARE_WATERMARK_RE.search(text):
        return False
    return True


def labeled_title_block_names(lines: list[str]) -> list[dict]:
    """PROJECT: / PROJECT TITLE / JOB NAME - the one reliable signal a title
    block offers. Generalises hydratec_project_fields() to any label, and
    handles the common CAD layout where the label is its own line and the value
    is the one or two lines that follow it."""
    rows = [line if isinstance(line, dict) else {"text": line, "size": 0.0} for line in lines]
    results: list[dict] = []
    for index, row in enumerate(rows):
        text = (row.get("text") or "").strip()
        inline = TITLE_BLOCK_LABEL_INLINE_RE.match(text)
        if inline:
            value = clean_plan_project_name(inline.group(1))
            if is_project_name_candidate(value, allow_street_address=True):
                results.append({"name": value, "index": index, "score": 120, "size": row.get("size") or 0.0})
                continue
        if not TITLE_BLOCK_LABEL_ONLY_RE.match(text):
            continue

        window = []
        valid: list[int] = []
        for follow in rows[index + 1 : index + 7]:
            candidate_text = (follow.get("text") or "").strip()
            if is_title_block_label_line(candidate_text):
                break
            if is_title_block_heading(candidate_text):
                # "Sheet Title" right after the project title's value starts a
                # different field - stop. Before any value has been seen it is
                # just a divider between the label and its value, so skip it.
                if valid:
                    break
                window.append(follow)
                continue
            window.append(follow)
            value = format_project_name(clean_plan_project_name(candidate_text))
            if is_project_name_candidate(value, allow_street_address=True):
                valid.append(len(window) - 1)
        if not valid:
            continue

        # The value normally starts on the first line after the label. But in a
        # vertical title block every label sits in one column and every value in
        # the next, so reading order can put SHEET TITLE:, REVISIONS: and
        # PROJECT INFO: together and then all three values - and the first line
        # after PROJECT INFO: is the sheet title. A markedly LARGER line inside
        # the window is the project name in that layout; a merely slightly
        # larger one is the second line of a wrapped name.
        anchor = valid[0]
        first_size = window[anchor].get("size") or 0.0
        if first_size > 0:
            bigger = [
                position
                for position in valid
                if (window[position].get("size") or 0.0) > 1.4 * first_size
            ]
            if bigger:
                anchor = max(bigger, key=lambda position: window[position].get("size") or 0.0)

        anchor_size = window[anchor].get("size") or 0.0
        collected = [clean_plan_project_name((window[anchor].get("text") or "").strip())]
        for follow in window[anchor + 1 :]:
            candidate_text = (follow.get("text") or "").strip()
            size = follow.get("size") or 0.0
            # A wrapped project name continues in the SAME type size. Anything
            # noticeably smaller is the next field, not the rest of the name.
            if anchor_size > 0 and size > 0 and not (0.65 * anchor_size <= size <= 1.5 * anchor_size):
                break
            if is_title_block_heading(candidate_text) or not is_title_block_value_continuation(candidate_text):
                break
            collected.append(clean_plan_project_name(candidate_text))
            if len(collected) >= 3:
                break
        for count in range(len(collected), 0, -1):
            joined = clean_plan_project_name(" ".join(collected[:count]))
            if is_project_name_candidate(joined, allow_street_address=True):
                results.append(
                    {
                        "name": joined,
                        "index": index + 1 + anchor,
                        "score": 120 if count == len(collected) else 112,
                        "size": anchor_size,
                    }
                )
    return results


def infer_plan_design_firms(text: str, lines: list[str] | None = None, contractor: dict | None = None) -> set[str]:
    """Normalised names of the design firms on the sheet - contractor,
    engineer, architect. The ranker excludes them: STERNCO, HMC ARCHITECTS and
    JACOBSON ENGINEERIN. all beat the real project name before this existed."""
    firms: set[str] = set()
    contractor = (contractor if contractor is not None else infer_plan_contractor(text)) or {}
    if contractor.get("name"):
        firms.add(normalize_text(contractor["name"]))
    source_lines = lines if lines is not None else normalize_plan_lines(text)
    firm_pattern = re.compile(
        r"\b([A-Z][A-Za-z0-9&.,' -]{1,60}?)\s*,?\s*"
        r"(?:engineers?|engineering|architects?|architecture|design\s+group|consultants?|associates)"
        r"\s*,?\s*(?:inc\.?|llc|ltd\.?|l\.?l\.?p\.?|p\.?c\.?)?\s*\.?$",
        re.IGNORECASE,
    )
    firm_word = re.compile(r"engineers?|engineering|architects?|architecture|design\s+group", re.IGNORECASE)
    for index, raw in enumerate(source_lines):
        line = re.sub(r"\s+", " ", raw or "").strip(" .,-")
        if not line:
            continue
        match = firm_pattern.match(line)
        if match and len(match.group(1).split()) <= 6:
            firms.add(normalize_text(match.group(1)))
            firms.add(normalize_text(line))
        # CAD letterheads letter the firm name huge and set the discipline tiny
        # on the next line ("STERNCO" over "e n g i n e e r s, i n c."). Only a
        # line that is JUST the discipline qualifies - anything looser starts
        # blacklisting real project names that merely sit near the word.
        despaced = re.sub(r"\s+", "", line)
        if re.fullmatch(r"(?:engineers?|engineering|architects?|architecture|designgroup)[,.]?(?:inc|llc|ltd|pc|llp)?[.,]?", despaced, re.IGNORECASE):
            for neighbour in source_lines[max(0, index - 2) : index + 3]:
                candidate = re.sub(r"\s+", " ", neighbour or "").strip(" .,-")
                if candidate and candidate != line and len(candidate.split()) <= 3 and not firm_word.search(re.sub(r"\s+", "", candidate)):
                    firms.add(normalize_text(candidate))
    firms.discard("")
    return firms


def title_block_name_candidates(
    sheets: list[dict],
    address: str = "",
    design_firms: set[str] | None = None,
    file_name: str = "",
) -> list[dict]:
    """Rank project-name candidates using only title-block text, with
    cross-sheet consensus. A string that occupies the same title-block slot on
    every sheet of the set is the project name almost by definition."""
    excluded = design_firms or set()
    file_candidate = project_name_from_filename(file_name)
    candidates: dict[str, dict] = {}

    emphasis_by_key: dict[str, int] = {}

    def add(
        raw_value: str,
        reason: str,
        score: int,
        sheet: int,
        labeled: bool = False,
        allow_street_address: bool = False,
        emphasis: int = 0,
    ) -> None:
        value = format_project_name(clean_plan_project_name(raw_value))
        if not is_project_name_candidate(value, allow_street_address) or is_title_block_heading(value):
            return
        key = normalize_text(value)
        # A joined multi-line value is not itself a line, so it has no size of
        # its own; it inherits its anchor line's. Without this the single first
        # line outscores the complete name it is only part of.
        score += max(emphasis_by_key.get(key, 0), emphasis)
        if not key or key in excluded:
            return
        # Either direction: the candidate IS a firm, or a firm is glued inside
        # it ("CLAY ST RESIDENCE GOLDEN BLAZE FIRE PROTECTION3806 CLAY ST").
        if any(
            key == firm or (len(key) > 6 and key in firm) or (len(firm) >= 10 and firm in key)
            for firm in excluded
        ):
            return
        entry = candidates.setdefault(
            key,
            {"name": value, "score": 0, "reasons": [], "sheets": set(), "labeled": False},
        )
        entry["score"] = max(entry["score"], score + score_project_name_candidate(value))
        entry["sheets"].add(sheet)
        entry["labeled"] = entry["labeled"] or labeled
        if reason not in entry["reasons"]:
            entry["reasons"].append(reason)

    for sheet in sheets:
        number = sheet.get("sheet", 0)
        line_groups = sheet.get("lineGroups")
        if not line_groups:
            line_groups = [[{"text": text, "size": 0.0} for text in group] for group in (sheet.get("groups") or [])]
        for line_group in line_groups:
            group = [line["text"] for line in line_group]
            # Compare type sizes only WITHIN one orientation block. Across the
            # whole sheet a single oddly-scaled run (a copyright line whose
            # glyphs report 40pt) flattens every real difference.
            biggest = max((line.get("size") or 0.0 for line in line_group), default=0.0)
            # Title blocks letter the project name largest. Relative type size
            # inside the block is the strongest UNLABELLED signal there is: it
            # is what separates SOMERTON HIGH SCHOOL (24pt) from the school
            # district that owns it (12pt) two lines away. Registered here so
            # it applies to a line however it was nominated.
            emphasis_by_key.clear()
            if biggest > 0:
                for line in line_group:
                    size = line.get("size") or 0.0
                    if size <= 0:
                        continue
                    key = normalize_text(format_project_name(clean_plan_project_name(line["text"])))
                    if key:
                        emphasis_by_key[key] = max(emphasis_by_key.get(key, 0), int(26 * (size / biggest)))
            for hit in labeled_title_block_names(line_group):
                hit_size = hit.get("size") or 0.0
                add(
                    hit["name"],
                    "labeled field",
                    hit["score"],
                    number,
                    labeled=True,
                    allow_street_address=True,
                    emphasis=int(26 * (hit_size / biggest)) if biggest > 0 and hit_size > 0 else 0,
                )
            for hit in project_names_near_address(group, address):
                add(hit["name"], "beside the project address", 60 + min(20, hit["score"]), number)
            for index, line in enumerate(line_group):
                if is_title_block_heading(line["text"]):
                    continue
                # The biggest type in the block is where the project name goes,
                # so an address-shaped string there is a building named after
                # its street, not the address field.
                size = line.get("size") or 0.0
                headline = biggest > 0 and size >= 0.95 * biggest
                add(
                    clean_plan_project_name(line["text"]),
                    "title block text",
                    max(14, 34 - index // 2),
                    number,
                    allow_street_address=headline,
                )

    total_sheets = len({sheet.get("sheet", 0) for sheet in sheets}) or 1
    for entry in candidates.values():
        if file_candidate:
            # Two independent sources agreeing (title block and filename) is
            # worth more than either alone.
            similarity = filename_similarity_score(entry["name"], file_candidate)
            if similarity >= 8:
                entry["score"] += similarity
                if "matches the filename" not in entry["reasons"]:
                    entry["reasons"].append("matches the filename")
        seen = len(entry["sheets"])
        entry["sheetCount"] = seen
        if seen >= 2:
            entry["score"] += 30 + min(30, seen * 10)
            if "on every sheet" not in entry["reasons"] and seen >= total_sheets:
                entry["reasons"].append("on every sheet")
            elif f"on {seen} sheets" not in entry["reasons"]:
                entry["reasons"].append(f"on {seen} sheets")
    ranked = sorted(
        candidates.values(),
        key=lambda entry: (-entry["score"], -entry["sheetCount"], entry["name"]),
    )
    return [
        {
            "name": entry["name"],
            "score": int(entry["score"]),
            "reasons": entry["reasons"][:4],
            "sheetCount": entry["sheetCount"],
            "labeled": entry["labeled"],
        }
        for entry in ranked[:10]
    ]


def infer_project_info(text: str, source: str, pages: int, file_name: str = "", exclude_addresses=(), project_name: str = "") -> dict:
    cleaned = text or ""
    lines = normalize_plan_lines(cleaned)
    # Name and address corroborate each other, so neither can go first cleanly.
    # Rank the name once with no address to get something to measure proximity
    # and token affinity against, then rank it again against the address that
    # produced. The provisional pass is thrown away; only its top name is used.
    provisional_name = project_name
    if not provisional_name:
        provisional = rank_project_name_candidates(lines, "", file_name)
        provisional_name = provisional[0]["name"] if provisional else ""
    address_signals: set = set()
    address = find_project_address(lines, cleaned, exclude_addresses, provisional_name, address_signals)
    name_candidates = rank_project_name_candidates(lines, address, file_name)
    labeled_name = next((entry["name"] for entry in name_candidates if "labeled field" in entry.get("reasons", [])), "")
    name = name_candidates[0]["name"] if name_candidates else ""
    hydratec = hydratec_project_fields(lines)
    if hydratec.get("name"):
        name = hydratec["name"]
        labeled_name = name
    if hydratec.get("address"):
        address = hydratec["address"]

    address_check = validate_plan_address(address)
    confidence_score = 0
    if name:
        confidence_score += 1
    if address_check["ok"]:
        confidence_score += 2
    elif address:
        confidence_score += 1
    if source == "title block":
        confidence_score += 1
    confidence = "high" if confidence_score >= 4 else "medium" if confidence_score >= 2 else "low"

    notes = []
    if address_check["message"]:
        notes.append(address_check["message"])
    if not name:
        notes.append("Project name was not confidently detected.")
    if not address:
        notes.append("Project address was not detected.")

    return {
        "name": name,
        "address": address,
        "addressSignals": sorted(address_signals),
        "addressLooksValid": address_check["ok"],
        "confidence": confidence,
        "source": source,
        "labelEvidence": bool(labeled_name),
        "projectNameCandidates": name_candidates[:6],
        "pagesScanned": min(pages or 0, 4),
        "notes": notes,
        "textPreview": "\n".join(lines[:18]),
    }

def normalize_plan_lines(text: str, dedupe: bool = True) -> list[str]:
    seen = set()
    lines = []
    for raw in text.splitlines():
        line = re.sub(r"\s+", " ", raw).strip(" -:\t")
        if len(line) < 2:
            continue
        key = normalize_text(line)
        if not key or (dedupe and key in seen):
            continue
        seen.add(key)
        lines.append(line)
    return lines

def find_labeled_plan_address(lines: list[str]) -> str:
    for index, line in enumerate(lines):
        if re.search(r"\b(project\s*)?(address|location|site address)\b", line, flags=re.IGNORECASE):
            inline = find_plan_address(line)
            if inline:
                return inline
            for candidate in lines[index + 1 : index + 4]:
                address = find_plan_address(candidate)
                if address:
                    return address
    return ""

def _plan_address_search(lines: list[str], cleaned: str, project_name: str = "", signals: set | None = None) -> str:
    address = find_best_plan_address(lines, project_name, signals)
    if address:
        return address
    if signals is not None:
        signals.clear()
    labeled = find_labeled_plan_address(lines)
    if labeled:
        if signals is not None:
            signals.add("labeled")
        return labeled
    near_label = find_address_near_project_label(lines)
    if near_label:
        if signals is not None:
            signals.add("labeled")
        return near_label
    return find_plan_address(cleaned) or find_city_state_plan_address(lines)


def find_project_address(lines: list[str], cleaned: str, exclude_addresses=(), project_name: str = "", signals: set | None = None) -> str:
    """The project address, never the design firm's own office address.

    Once the title block is actually readable, the contractor's letterhead sits
    in the same slice as the project address and routinely outscores it - four
    files in the corpus started answering with their own office. Excluding the
    firm address we already detected is cheaper and far more general than
    trying to out-score a letterhead.

    That exclusion only ever covered the ONE address the contractor sniffer
    managed to attach to a firm name, and it was computed from a different text
    than the one being searched - so a letterhead whose name the sniffer missed
    (collapsed glyph spacing, an engineer rather than a contractor, an AHJ
    stamp) walked straight into the project slot. Dropping the whole letterhead
    NEIGHBOURHOOD out of the lines, up front, reaches every finder path below
    instead of just the one."""
    excluded = {normalize_text(value) for value in exclude_addresses if value}
    excluded.discard("")
    zoned = vouched_letterhead_indices(lines, project_name)
    working = [line for index, line in enumerate(lines) if index not in zoned] if zoned else list(lines)
    working_text = "\n".join(working) if zoned else cleaned
    if not any(assemble_plan_address(working, index) for index in range(len(working))):
        # Every address on the sheet sits in a letterhead neighbourhood. That
        # is usually a one-party sheet whose only address IS the project's, so
        # fall back to the unfiltered lines rather than answering nothing.
        working = list(lines)
        working_text = cleaned
    for _ in range(3):
        address = _plan_address_search(working, working_text, project_name, signals)
        if not address:
            break
        key = normalize_text(address)
        if not key or not any(key == item or key in item or item in key for item in excluded):
            return address
        contributing = {
            normalize_text(line)
            for line in working
            if len(normalize_text(line)) >= 4 and normalize_text(line) in key
        }
        if not contributing:
            break
        remaining = [line for line in working if normalize_text(line) not in contributing]
        if len(remaining) == len(working):
            break
        working = remaining
        working_text = "\n".join(working)
    # Deliberately empty rather than the firm address we just rejected: an
    # empty result here lets choose_plan_project() fall through to the other
    # text source, which on several corpus files carries the right address.
    if signals is not None:
        signals.clear()
    return ""


def find_address_near_project_label(lines: list[str]) -> str:
    for index, line in enumerate(lines):
        if re.fullmatch(r"project|project name|project title|job name|site name", line, flags=re.IGNORECASE):
            for candidate in lines[index + 1 : index + 7]:
                address = find_plan_address(candidate)
                if address:
                    return address
    return ""

def rank_project_name_candidates(lines: list[str], address: str, file_name: str = "") -> list[dict]:
    candidates: dict[str, dict] = {}
    line_counts: dict[str, int] = {}
    line_first_index: dict[str, int] = {}
    file_candidate = project_name_from_filename(file_name)
    file_key = normalize_text(file_candidate)

    def add(raw_value: str, reason: str, base_score: int = 0, index: int | None = None) -> None:
        value = format_project_name(raw_value)
        if not is_project_name_candidate(value):
            return
        key = normalize_text(value)
        if not key:
            return
        entry = candidates.setdefault(
            key,
            {
                "name": value,
                "score": 0,
                "reasons": [],
                "count": 0,
                "firstIndex": index if index is not None else 9999,
            },
        )
        entry["score"] += base_score + score_project_name_candidate(value)
        entry["count"] += 1
        if reason not in entry["reasons"]:
            entry["reasons"].append(reason)
        if index is not None:
            entry["firstIndex"] = min(entry.get("firstIndex", 9999), index)

    for index, line in enumerate(lines):
        value = clean_plan_project_name(line)
        if not is_project_name_candidate(value):
            continue
        key = normalize_text(format_project_name(value))
        line_counts[key] = line_counts.get(key, 0) + 1
        line_first_index.setdefault(key, index)

    if file_candidate:
        add(file_candidate, "PDF filename", 44 if is_meaningful_filename_project_name(file_candidate) else 10, 0)

    for index, line in enumerate(lines):
        labeled = project_name_from_labeled_line(line)
        if labeled:
            add(labeled, "labeled field", 24, index)
        if re.fullmatch(r"project|project name|project title|job name|site name", line.rstrip(":"), flags=re.IGNORECASE):
            for offset, candidate in enumerate(lines[index + 1 : index + 5], start=1):
                add(candidate, "labeled field", 24 - offset, index + offset)

    for candidate in project_names_near_address(lines, address):
        add(candidate["name"], "near address", candidate["score"], candidate["index"])

    for candidate in project_names_near_sheet_title(lines):
        add(candidate["name"], "title sheet heading", candidate["score"], candidate["index"])

    for key, count in line_counts.items():
        if count < 2:
            continue
        name = next((line for line in lines if normalize_text(format_project_name(clean_plan_project_name(line))) == key), "")
        add(name, "repeated on sheets", min(18, count * 4), line_first_index.get(key, 9999))

    for index, line in enumerate(lines[:80]):
        add(line, "early title block text", max(0, 8 - index // 10), index)

    for entry in candidates.values():
        entry["score"] += filename_similarity_score(entry["name"], file_candidate)
        if file_candidate and filename_similarity_score(entry["name"], file_candidate) >= 8 and "matches filename" not in entry["reasons"]:
            entry["reasons"].append("matches filename")
        if entry.get("count", 0) >= 2:
            entry["score"] += min(12, entry["count"] * 2)
        if entry.get("firstIndex", 9999) <= 40:
            entry["score"] += 4
        if file_key and normalize_text(entry["name"]) == file_key:
            entry["score"] += 8
        if file_key and file_key in normalize_text(entry["name"]) and "near address" in entry.get("reasons", []):
            entry["score"] += 16

    ranked = sorted(candidates.values(), key=lambda item: (-item["score"], item.get("firstIndex", 9999), item["name"]))
    top_score = ranked[0]["score"] if ranked else 0
    ranked = [entry for entry in ranked if entry["score"] >= max(18, top_score - 30)]
    return [
        {
            "name": format_project_name(entry["name"]),
            "score": int(entry["score"]),
            "reasons": entry["reasons"][:4],
        }
        for entry in ranked[:10]
    ]

def project_name_from_labeled_line(line: str) -> str:
    match = re.match(r"^(?:project\s*name|project\s*title|project\s*info(?:rmation)?|job\s*name|site\s*name|project)\s*[:#-]\s*(.+)$", line, re.IGNORECASE)
    return clean_plan_project_name(match.group(1)) if match else ""

def project_names_near_address(lines: list[str], address: str) -> list[dict]:
    if not address:
        return []
    address_key = normalize_text(address)
    street_match = re.match(
        r"\d{1,6}(?:-\d{1,6})?\s+(?:[NSEW]\.?\s+)?[A-Za-z0-9.'#& -]+?\s+"
        r"(?:Street|St\.?|Avenue|Ave\.?|Road|Rd\.?|Drive|Dr\.?|Lane|Ln\.?|Boulevard|Blvd\.?|Way|Court|Ct\.?|Place|Pl\.?|Highway|Hwy\.?|Parkway|Pkwy\.?|Circle|Cir\.?|Loop|Terrace|Ter\.?|Trail|Trl\.?)(?:\s+\d{1,4})?(?=\W|$)",
        address,
        flags=re.IGNORECASE,
    )
    street_key = normalize_text(street_match.group(0) if street_match else address)
    results = []
    for index, line in enumerate(lines):
        line_key = normalize_text(line)
        if not line_key or (street_key not in line_key and not (len(line_key) > 8 and line_key in address_key)):
            continue
        before_candidates = []
        for offset, candidate in enumerate(reversed(lines[max(0, index - 8) : index]), start=1):
            value = clean_plan_project_name(candidate)
            if not is_project_name_candidate(value):
                continue
            before_candidates.append((value, index - offset, max(10, 26 - offset * 2)))
            if len(before_candidates) >= 4:
                break
        after_candidates = []
        for offset, candidate in enumerate(lines[index + 1 : index + 20], start=1):
            if re.fullmatch(r"revisions?", candidate.strip(), re.IGNORECASE):
                break
            value = clean_plan_project_name(candidate)
            if not is_project_name_candidate(value):
                continue
            after_candidates.append((value, index + offset, max(8, 22 - offset)))
            if len(after_candidates) >= 4:
                break
        before_values = [value for value, _, _ in reversed(before_candidates)]
        after_values = [value for value, _, _ in after_candidates]
        multiline = compose_multiline_project_name(before_values, after_values)
        if multiline:
            results.append({"name": multiline, "index": index, "score": 48})
        for value, candidate_index, score in [*before_candidates, *after_candidates]:
            results.append({"name": value, "index": candidate_index, "score": score})
        for group in [
            clean_plan_project_name(" ".join(before_values)),
            clean_plan_project_name(" ".join(after_values)),
        ]:
            if group and len(group.split()) <= 8:
                results.append({"name": group, "index": index, "score": 18})
    return results

def project_names_near_sheet_title(lines: list[str]) -> list[dict]:
    results = []
    for index, line in enumerate(lines[:100]):
        if not re.search(r"\b(?:(?:fire\s+)?sprinkler|fire\s+service\s+underground|fire\s+protection|fire\s+pump)\s+plans?\b", line, re.IGNORECASE):
            continue
        options = []
        for candidate_index, candidate in enumerate(lines[max(0, index - 12) : index], start=max(0, index - 12)):
            value = clean_plan_project_name(candidate)
            if not is_project_name_candidate(value):
                continue
            if re.search(r"\b(symbol|legend|notes?|materials?|installations?|automatic fire|coupling|valve|grooved|rigid|flexible|wagner\s+fire|true\s+north\s+fire)\b", value, re.IGNORECASE):
                continue
            score = score_project_name_candidate(value) + max(0, 8 - (index - candidate_index))
            options.append({"name": value, "index": candidate_index, "score": 46 + score})
        if options:
            results.append(max(options, key=lambda item: item["score"]))
    return results

def compose_multiline_project_name(before_candidates: list[str], after_candidates: list[str]) -> str:
    candidates = [candidate for candidate in after_candidates if candidate]
    if len(candidates) < 2:
        return ""
    descriptor = next((candidate for candidate in candidates if is_project_descriptor_line(candidate)), "")
    if not descriptor:
        return ""
    name = next(
        (
            candidate
            for candidate in candidates
            if normalize_text(candidate) != normalize_text(descriptor)
            and not is_project_descriptor_line(candidate)
        ),
        "",
    )
    if not name:
        return ""
    return clean_plan_project_name(f"{name}, {descriptor}")

def is_project_descriptor_line(value: str) -> bool:
    return bool(re.search(r"\b\d+[- ]?story\b|\b\d+\s+suites?\b|\bbuilding\b|\bphase\b|\baddition\b|\bgarage\b", value, re.IGNORECASE))

def find_best_plan_address(lines: list[str], project_name: str = "", signals: set | None = None) -> str:
    """The best address in these lines.

    With a project_name supplied, two signals outrank raw completeness:

    * PROXIMITY - an address within a few lines of the project name in the
      title block is the project's address, and a missing ZIP must not lose it
      to a letterhead across the strip that happens to carry one.
    * AFFINITY  - an address sharing a distinctive token with the project name
      ("517 CHANNEL ST" under "CHANNEL ST APARTMENTS") is corroborated by the
      name itself.

    Callers looking for a FIRM's address (infer_plan_contractor) pass no name
    and get the old completeness-first behaviour unchanged."""
    best = ("", -1000)
    best_signals: set = set()
    name_indices = project_name_line_indices(lines, project_name)
    name_tokens = distinctive_name_tokens(project_name)
    for index in range(len(lines)):
        address = assemble_plan_address(lines, index)
        if not address:
            continue
        found: set = set()
        if address_is_near_project_name(index, name_indices):
            found.add("proximity")
        if name_tokens and (name_tokens & set(re.findall(r"[A-Z][A-Z0-9]{3,}", address.upper()))):
            found.add("affinity")
        has_street_address = bool(
            re.search(
                r"\b\d{1,6}(?:-\d{1,6})?\s+.+\s(?:Street|St\.?|Avenue|Ave\.?|Road|Rd\.?|Drive|Dr\.?|Lane|Ln\.?|Boulevard|Blvd\.?|Way|Court|Ct\.?|Place|Pl\.?|Highway|Hwy\.?|Parkway|Pkwy\.?|Circle|Cir\.?|Loop|Terrace|Ter\.?|Trail|Trl\.?)(?:\s+\d{1,4})?(?=\W|$)",
                address,
                re.IGNORECASE,
            )
        )
        nearby = lines[max(0, index - 5) : min(len(lines), index + 7)]
        score = 0
        if validate_plan_address(address)["ok"]:
            score += 8
        if has_street_address:
            score += 10
        else:
            score -= 15
        if re.search(r"\b\d{5}(?:-\d{4})?\b", address):
            score += 4
        if any(is_project_name_candidate(clean_plan_project_name(line)) for line in nearby):
            score += 5
        if any(re.search(r"\b(apartments?|restaurant|hotel|school|tenant|improvement|center|building|residence|residential|company|warehouse)\b", line, re.IGNORECASE) for line in nearby):
            score += 3
        if any(re.search(r"\b(owner|architect|engineer|civil|structural|m/p|electrical|principal|manager|contact|phone|email|responsible entity)\b", line, re.IGNORECASE) for line in nearby):
            score -= 5
        if any(re.search(r"\b(lic\.?|license|c[-\s]?16|phone|1-\(?\d{3}\)?|\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4})\b", line, re.IGNORECASE) for line in nearby):
            score -= 9
        if any(re.search(r"\b(nfpa code|system type|design criteria|fire prevention|phone number)\b", line, re.IGNORECASE) for line in nearby):
            score -= 6
        if index < 30:
            score -= 2
        # Deliberately larger than the completeness bonuses combined (valid +8,
        # ZIP +4): "517 CHANNEL ST" with no ZIP, sitting under "CHANNEL ST
        # APARTMENTS", must beat a fully-formed letterhead address elsewhere.
        if "proximity" in found:
            score += 14
        if "affinity" in found:
            score += 16
        if score > best[1]:
            best = (address, score)
            best_signals = found
    if signals is not None:
        signals.clear()
        signals.update(best_signals)
    return best[0]

def assemble_plan_address(lines: list[str], index: int) -> str:
    address = find_plan_address(lines[index])
    if not address:
        return find_city_state_zip(lines[index])
    if not address:
        return ""
    if re.search(r",\s*[A-Za-z .'-]+,\s*[A-Z]{2}\b", address):
        return address
    best_city_state = ""
    for candidate in lines[index + 1 : index + 13]:
        city_state = re.match(city_state_zip_pattern(), candidate.strip(), re.IGNORECASE)
        if city_state:
            formatted = format_city_state_zip(city_state.group(0))
            if re.search(r"\b\d{5}(?:-\d{4})?\b", formatted):
                return format_plan_address(f"{address.rstrip(' ,.')}, {formatted}")
            if not best_city_state:
                best_city_state = formatted
    if best_city_state:
        return format_plan_address(f"{address.rstrip(' ,.')}, {best_city_state}")
    return format_plan_address(address)

def find_plan_address(text: str) -> str:
    pattern = re.compile(
        r"\b\d{1,6}(?:-\d{1,6})?\s+(?:[NSEW]\.?\s+)?[A-Za-z0-9.'#& -]+?\s+"
        r"(?:Street|St\.?|Avenue|Ave\.?|Road|Rd\.?|Drive|Dr\.?|Lane|Ln\.?|Boulevard|Blvd\.?|Way|Court|Ct\.?|Place|Pl\.?|Highway|Hwy\.?|Parkway|Pkwy\.?|Circle|Cir\.?|Loop|Terrace|Ter\.?|Trail|Trl\.?)(?:\s+\d{1,4})?(?=\W|$)"
        r"(?:\s+(?:Suite|Ste\.?|Unit|#)\s*[A-Za-z0-9-]+)?"
        r"(?:[,\s]+[A-Za-z .'-]+,?\s+[A-Z]{2}\.?,?)?(?:\s*\d{5}(?:-\d{4})?)?",
        re.IGNORECASE,
    )
    match = pattern.search(text)
    if not match:
        return ""
    address = re.sub(r"\s+", " ", match.group(0)).strip(" ,")
    address = re.sub(r"\b(St|Ave|Blvd|Rd|Dr|Ln|Ct|Pl|Hwy|Pkwy|Cir|Ter|Trl)\.\s+([A-Za-z .'-]+,\s*[A-Z]{2})\b", r"\1, \2", address, flags=re.IGNORECASE)
    address = re.sub(
        r"\b(Street|St\.?|Avenue|Ave\.?|Road|Rd\.?|Drive|Dr\.?|Lane|Ln\.?|Boulevard|Blvd\.?|Way|Court|Ct\.?|Place|Pl\.?|Highway|Hwy\.?|Parkway|Pkwy\.?|Circle|Cir\.?|Loop|Terrace|Ter\.?|Trail|Trl\.?)\s+([A-Za-z .'-]+),\s*([A-Z]{2})\b",
        r"\1, \2, \3",
        address,
        flags=re.IGNORECASE,
    )
    address = re.sub(r",\s*([A-Z]{2}),\s*(\d{5})\b", r", \1 \2", address)
    address = re.sub(r",\s*([A-Z]{2})\.\s*(\d{5})\b", r", \1 \2", address, flags=re.IGNORECASE)
    address = re.sub(r"\s+([A-Z]{2})\.?\s+(\d{5})\b", r", \1 \2", address)
    return format_plan_address(address)

def format_plan_address(value: str) -> str:
    value = re.sub(r"\s+", " ", value or "").strip(" ,")
    parts = [part.strip() for part in value.split(",") if part.strip()]
    if len(parts) >= 3 and re.match(r"^[A-Z]{2}\.?(?:\s+\d{5}(?:-\d{4})?)?$", parts[-1], re.IGNORECASE):
        state_zip = parts[-1].replace(".", "").upper()
        street = project_title_case(parts[0])
        city = project_title_case(" ".join(parts[1:-1]))
        return f"{street}, {city}, {state_zip}"
    if len(parts) == 2 and re.match(r"^[A-Z]{2}\.?(?:\s+\d{5}(?:-\d{4})?)?$", parts[1], re.IGNORECASE):
        return format_city_state_zip(value)
    return project_title_case(value) if value.upper() == value else value

def city_state_zip_pattern() -> str:
    return r"^[A-Za-z .'-]+,?\s+[A-Z]{2}\.?\s*,?\s*\d{5}(?:-\d{4})?$|^[A-Za-z .'-]+,\s*[A-Z]{2}\.?\s*,?\s*$"

def find_city_state_zip(value: str) -> str:
    value = re.sub(r"\s+", " ", value or "").strip(" ,")
    match = re.match(city_state_zip_pattern(), value, re.IGNORECASE)
    return format_city_state_zip(match.group(0)) if match else ""

def find_city_state_plan_address(lines: list[str]) -> str:
    for line in lines:
        address = find_city_state_zip(line)
        if address:
            return address
    return ""

def format_city_state_zip(value: str) -> str:
    value = re.sub(r"\s+", " ", value or "").strip(" ,")
    match = re.match(r"^(.+?),?\s+([A-Z]{2})\.?\s*,?\s*(\d{5}(?:-\d{4})?)?$", value, re.IGNORECASE)
    if not match:
        return value
    city = match.group(1).strip(" ,")
    state = match.group(2).upper()
    zip_code = match.group(3) or ""
    return f"{project_title_case(city)}, {state}{f' {zip_code}' if zip_code else ''}"

def validate_plan_address(address: str) -> dict:
    if not address:
        return {"ok": False, "message": "No address was detected."}
    has_street = bool(
        re.search(
            r"\b\d{1,6}(?:-\d{1,6})?\s+.+\s(?:Street|St\.?|Avenue|Ave\.?|Road|Rd\.?|Drive|Dr\.?|Lane|Ln\.?|Boulevard|Blvd\.?|Way|Court|Ct\.?|Place|Pl\.?|Highway|Hwy\.?|Parkway|Pkwy\.?|Circle|Cir\.?|Loop|Terrace|Ter\.?|Trail|Trl\.?)(?=\W|$)",
            address,
            re.IGNORECASE,
        )
    )
    has_city_state = bool(re.search(r",\s*[A-Za-z .'-]+,\s*[A-Z]{2}\.?\b", address))
    has_zip = bool(re.search(r"\b\d{5}(?:-\d{4})?\b", address))
    is_city_state_zip = bool(re.fullmatch(r"[A-Za-z .'-]+,\s*[A-Z]{2}\s+\d{5}(?:-\d{4})?", address))
    if has_street and has_city_state and has_zip:
        return {"ok": True, "message": ""}
    if has_street and has_city_state:
        return {"ok": True, "message": "Address looks usable, but no ZIP code was detected."}
    if is_city_state_zip:
        return {"ok": True, "message": "Only city/state/ZIP was detected; confirm whether a street address is needed."}
    if has_street:
        return {"ok": False, "message": "Address has a street, but city/state/ZIP may be missing."}
    return {"ok": False, "message": "Detected address does not look like a complete street address."}

def clean_plan_project_name(value: str) -> str:
    value = re.sub(r"^(?:project\s*name|project\s*title|job\s*name|site\s*name|project)\s*[:#-]\s*", "", value, flags=re.IGNORECASE)
    value = re.sub(r"\s+", " ", value).strip(" -:")
    value = re.sub(r"^(?:area of work|underground connection\s*\(for reference only\)|site location)\s*,\s*", "", value, flags=re.IGNORECASE)
    value = re.sub(
        r"^\d{1,3}\s+(?=[A-Za-z&.' -]+(?:addition|residence|apartments?|center|building|market|retail|winery|cheese|drywall|hotel|hall|terminal|pump|seminary)\b)",
        "",
        value,
        flags=re.IGNORECASE,
    )
    if len(value.split()) > 10:
        return ""
    return value if 4 <= len(value) <= 100 and re.search(r"[A-Za-z]", value) else ""

def format_project_name(value: str) -> str:
    value = clean_plan_project_name(value)
    if value and value.upper() == value and re.search(r"[A-Z]", value):
        return project_title_case(value)
    return format_mixed_project_name(value)

def detected_project_caps(value: str) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip()).upper()

def format_mixed_project_name(value: str) -> str:
    keep_upper = {"AFB", "UCSF", "UCLA", "UC", "CSU", "B14", "LLC", "QOZB"}
    words = []
    for word in value.split():
        prefix = re.match(r"^\W*", word).group(0)
        suffix = re.search(r"\W*$", word).group(0)
        core = word[len(prefix) : len(word) - len(suffix) if suffix else len(word)]
        bare = re.sub(r"[^A-Za-z0-9]", "", core)
        if bare.upper() in keep_upper or re.fullmatch(r"(?:[A-Za-z]\.){2,}[A-Za-z]?\.?", core) or re.search(r"\d", bare) or not core.isupper():
            words.append(word)
        else:
            words.append(f"{prefix}{core[:1].upper()}{core[1:].lower()}{suffix}")
    return " ".join(words)

def project_title_case(value: str) -> str:
    keep_upper = {"AFB", "UCSF", "UCLA", "UC", "CSU", "B14"}
    words = []
    for word in value.split():
        clean = word.strip()
        bare = re.sub(r"[^A-Za-z0-9]", "", clean)
        if bare.upper() in keep_upper or re.search(r"\d", bare):
            words.append(clean.upper())
        elif re.fullmatch(r"(?:[A-Za-z]\.){2,}[A-Za-z]?\.?", clean):
            words.append(clean.upper())
        else:
            words.append(clean[:1].upper() + clean[1:].lower())
    return " ".join(words)

def is_project_name_candidate(value: str, allow_street_address: bool = False) -> bool:
    """allow_street_address lifts ONLY the street-address rejection. Plenty of
    buildings are named after the street they stand on - "2814 CLAY ST",
    "1523 HARRISON ST HIGH RISE", "609 KEARNEY ST CONDOS" - and rejecting every
    address-shaped string costs those outright. Callers turn it on only where
    the layout says "project name": a labelled field, or the largest type in
    the title block. A city/state/ZIP is still always rejected, because that
    really is the address line and never the name."""
    if not value:
        return False
    if normalize_text(value) in {"studio", "firstsubmit", "artifexwest"}:
        return False
    bad_key = normalize_text(value)
    bad_fragments = {
        "aterialsshall",
        "isprinklersystem",
        "attendedlocation",
        "referencekey",
        "ofcall",
        "areaofproject",
        "siteworkarea",
        "actualbuildingheight",
        "poweringbusiness",
        "powesingbusiness",
        "poweningbusiness",
        "businessworldwide",
        "aiciadd",
        "iconstructiontype",
        "vsttoconfgrmtokfpafts",
        "watersupplyinformation",
        "undergroundshownforreferenceonly",
        "sector2aloadoutareaplans",
        "seatingareas",
        "indicatedonplanallpipingabovegradetobeductile",
        "eofcale",
        "20tshalpetheresponsiltyofhevinertokantan",
        "rooremaproved",
        "fthevtrawlaracopyofhfpazes",
        "responsilty",
        "heviner",
        "kantan",
        "hfpazes",
        "roore",
        "nsfortu",
        "vtrawlar",
        "aproved",
        "braceidentification",
        "jrwagner",
        "lrwagner",
        "irwagner",
        "wagnerfre",
        "wagnerfire",
        "mtaned",
    }
    if any(fragment in bad_key for fragment in bad_fragments):
        return False
    if len(value.split()) > 10:
        return False
    # Runs of text that lost their spaces, and a number glued to a word. Both
    # are extraction debris from abutting title-block columns and legend
    # tables ("ITISTHEOWNER'SRESPONSIBILITY...", "139EXISTING UPRIGHT HEAD").
    if any(len(token) > 24 for token in value.split()):
        return False
    if re.match(r"^\d+[A-Za-z]{3,}", value.strip()):
        return False
    if value.count(")") > value.count("(") or re.search(r"^\s*(?:by|designed|drawn)\s*:", value, re.IGNORECASE):
        return False
    tokens_for_quality = meaningful_name_token_list(value)
    has_compact_acronym = bool(re.search(r"\b[A-Z]\d+\b|\b[A-Z](?:\.[A-Z]){1,}\.?\b", value))
    if len(tokens_for_quality) <= 1 and not has_compact_acronym:
        return False
    if not any(len(token) >= 3 for token in tokens_for_quality) and not has_compact_acronym:
        return False
    if re.match(r"^\d+\.\s*", value) or re.search(r"\s=\s|=", value):
        return False
    if re.fullmatch(r"system\.?|staff|typical|remarks?|n\.?t\.?s\.?|p\.?o\.?c\.?|n\.?l\.?c\.?|u\.?n\.?o\.?|no\.?\s*a\.?s\.?|osfm stamp|brace identification|vertical pipe|ductile iron|fire underground|fire pump plan|applicable codes|action codes|disclaimer|hazard|stubs?-?up|plan|location\.?|site location|fully sprinklered:?\s*yes|reference site|commodity classification", value, re.IGNORECASE):
        return False
    if re.match(r"^\(?[EN]\)?\s+", value, re.IGNORECASE) and re.search(r"\b(pipe|piping|riser|discharge|suction)\b", value, re.IGNORECASE):
        return False
    if re.search(r"\b[A-Z]/FS\d+\b|THRU\s+[A-Z]/FS\d+", value, re.IGNORECASE):
        return False
    if re.fullmatch(r"(?:FP|FS|F)-?\d+(?:\.\d+)?[A-Z]?|PROJECT\s+NO\.?|SHEET\s+NO\.?|SHEET\s+NAME|PAGE\s+NO\.?|\d+\s+OF\s+\d+", value, re.IGNORECASE):
        return False
    if re.search(r"\b(lic\.?|license|c[-\s]?16|phone|address|date signed|date issued|designed by|drawn by|checked by|job number|job id|project no\.?|sheet no\.?|sheet name|page no\.?|drawing scale|plot size|as shown|as noted|as-built|issued for|revised|revision|revisiondate|comments?|ahj|authority having jurisdiction|requirements?|required|attachment|materials?|aterial|installations?|automatic fire|building structure|building areas?|description|render|connection point|point of connection|flow test|water flow|water supply|water\s*f\s*l_?ow|remote area|hydraulic information|hydraulic calcs?|construction type|occupancy|nfpa|total|thread rod|branch lines?|ordinances?|perspective|section|indoor fire pump|buildings shall|buildings on the same lot|same lot|physically separated|brass|temperature|finish|parcel|square footage|sq\.?\s*ft|s\.?\s*f\.?|riser|exp\.?|coupling|grooved|valve|earthquake bracing|hydraulic reference|key note|location map|site map|vicinity map|install plan|job info|project location|building footing|cut base|base lgth|pop-out|eave ht|verify in field|unless noted otherwise|reference only|tenant improvement|pendent sprinklers|seating areas|acceptance of these plans|subject to field|not\s*in\s*contract|no automatic sprinklers|no\.?\s*stories|stories|blocking|by others|alterations?|instruction manuals?|upkeep|shall bear this notice|any part of these|express written consent|area of work|loadout area|i?applicable codes|action codes|fire\s*prevention|firei?prevention|fire department|department|departmi?ent|design criteria|ordinary hazard|commodity classification|approx|exposure|freezing|adequately protected|hydrant location|clg:|pipe type|available|separate permit|custom lengths|existing|milking|rankler|rinkler|discharge piping|suction piping|victaulic|flange adapter)\b", value, re.IGNORECASE):
        return False
    if re.search(r"(?:\+?1[\s.-]?)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}", value):
        return False
    # Any run of 5+ digits: a job number, not a project name. Not \b-anchored,
    # because title-block columns abut and arrive glued ("23100051JOB ID").
    if re.search(r"\d{5,}", value):
        return False
    if is_plan_noise_line(value) or find_city_state_zip(value):
        return False
    if not allow_street_address and find_plan_address(value):
        return False
    if re.fullmatch(r"[\d\s.,#/-]+", value):
        return False
    alpha_chars = re.findall(r"[A-Za-z]", value)
    if alpha_chars and len(alpha_chars) < max(3, len(value) * 0.35):
        return False
    if re.search(r"[{}\\|]", value):
        return False
    if re.search(r"[§#^_™®©|]", value):
        return False
    # A numbered-field label anywhere in the string, not just at the front:
    # abutting columns glue them on ("SURFACEMOUNT,WHITE PROJ. NO.").
    if re.search(r"\b(?:proj(?:ect)?\.?|job|sheet|dwg|drawing)\s*(?:no\.?|number|id)\b", value, re.IGNORECASE):
        return False
    if re.search(r"\b\d{2,3}\s*°\s*f\b", value, re.IGNORECASE):
        return False
    if re.fullmatch(r"(?:quick|fast|standard)(?:\s+response)?", value, re.IGNORECASE):
        return False
    if re.search(r"\bp\.?\s*o\.?\s*box\b", value, re.IGNORECASE):
        return False
    if re.search(r"@|www\.|\.com\b|\b(owner|architect|engineer|principal|manager|contact|phone|email|civil|structural|m/p|electrical|inc\.?|llc|corporation|sternco|jrs|james quinn|ernst flores|j\.?\s*r\.?\s*wagner|l\.?\s*r\.?\s*wagner|i\.?\s*r\.?\s*wagner|lr\s+wagner|ir\s+wagner|wagner fire|true north fire|dan thacker|wharnen)\b", value, re.IGNORECASE):
        return False
    if len(value) > 10:
        letters = re.findall(r"[A-Za-z]", value)
        vowels = re.findall(r"[AEIOUaeiou]", value)
        if letters and len(vowels) / len(letters) < 0.14:
            return False
    return True

def project_name_from_filename(file_name: str) -> str:
    stem = Path(file_name or "").stem
    stem = re.sub(r"[_+]+", " ", stem)
    stem = re.sub(r"^Fire\s+Approval[-\s]*", " ", stem, flags=re.IGNORECASE)
    stem = re.sub(r"\[[^\]]*\]", " ", stem)
    stem = re.sub(r"\((?:\d+|james rev|in rack approved plans|fire sprinkler approved plans)\)", " ", stem, flags=re.IGNORECASE)
    stem = re.sub(r"^\s*(?:\d{6,}[A-Z]?(?:-[A-Z]{1,3})?|BLD\d{2,4}-?\d+|FDPR\d+-?\d+|24F-\d+-\d+AP|4LEAF)\s*[-_ ]*", " ", stem, flags=re.IGNORECASE)
    stem = re.sub(r"^\s*\d{3,6}\s*[-_ ]*", " ", stem)
    stem = re.sub(r"\b(?:FS|FP|FA|FD|Fire Sprinkler|Sprinklers?|Fire Plans?|Plans?|Submittals?|AHJ|GC|DATE|DSA|OSFM|BPR|Stamped|Shop Drawings?|Hydraulic Calcs?|Signed|Parsons Response|Full Pkg|Draft Stop Detail|with|REV(?:ISION)?\s*\d*|REVISED|APPROVED|APRV|Approval)\b", " ", stem, flags=re.IGNORECASE)
    stem = re.sub(r"\b\d{1,2}[.-]\d{1,2}[.-]\d{2,4}\b", " ", stem)
    stem = re.sub(r"\bFP\d+_?\d*\b", " ", stem, flags=re.IGNORECASE)
    stem = re.sub(r"\b\d+\b$", " ", stem)
    stem = re.sub(r"\s+", " ", stem).strip(" -_")
    stem = re.sub(r"\(\s*\)", " ", stem)
    stem = re.sub(r"\s+-\s+", " - ", stem).strip(" -_")
    if not stem or len(stem) < 4:
        return ""
    return format_project_name(stem)

def is_meaningful_filename_project_name(value: str) -> bool:
    key = normalize_text(value)
    if not key:
        return False
    if re.fullmatch(r"(?:bld|fdpr|si|aprv|dsa|osfm|bpr|xpo|rtp|delta|underground|asbuilt|firepump|plans?|approved|ap)\w*(?:\s+\w+){0,2}", key):
        return False
    if re.search(r"\b(?:as-built|delta|underground delta|fire approval|approved|plans?|shop drawings?|full pkg)\b", value, re.IGNORECASE):
        return False
    if re.search(r"\b\d{5,}\b", value):
        return False
    tokens = meaningful_name_token_list(value)
    alpha_tokens = [token for token in tokens if re.search(r"[a-z]", token)]
    if len(alpha_tokens) >= 2:
        return True
    return bool(alpha_tokens and re.search(r"\b(XPO|WPWMA|RTP|M\.?A\.?C)\b", value, re.IGNORECASE))

def filename_similarity_score(candidate: str, file_candidate: str) -> int:
    if not candidate or not file_candidate:
        return 0
    candidate_key = normalize_text(candidate)
    file_key = normalize_text(file_candidate)
    if not candidate_key or not file_key:
        return 0
    if candidate_key == file_key:
        return 18
    if candidate_key in file_key or file_key in candidate_key:
        return 12
    candidate_token_list = meaningful_name_token_list(candidate_key)
    file_token_list = meaningful_name_token_list(file_key)
    candidate_tokens = set(candidate_token_list)
    file_tokens = set(file_token_list)
    if not candidate_tokens or not file_tokens:
        return 0
    overlap = candidate_tokens & file_tokens
    score = len(overlap) * 6
    candidate_acronym = "".join(token[:1] for token in candidate_token_list if token)
    file_acronym = "".join(token[:1] for token in file_token_list if token)
    if file_acronym and candidate_acronym and (file_acronym in candidate_acronym or candidate_acronym in file_acronym):
        score += 8
    for token in file_tokens:
        if len(token) >= 2 and token == candidate_acronym[: len(token)]:
            score += 8
    return min(score, 18)

def meaningful_name_token_list(value: str) -> list[str]:
    stop = {
        "fs",
        "fp",
        "fire",
        "sprinkler",
        "sprinklers",
        "plan",
        "plans",
        "project",
        "job",
        "rev",
        "revision",
        "revised",
        "set",
        "pdf",
    }
    return [token for token in re.findall(r"[a-z0-9]+", value.lower()) if len(token) > 1 and token not in stop and not token.isdigit()]

def score_project_name_candidate(value: str) -> int:
    score = 0
    if re.search(r"\b(apartments?|restaurant|hotel|school|tenant|improvement|center|building|residence|residential|childcare|daycare|company|warehouse|base|garage|plaza|pavilion|remodeling|addition|store|suites?|facility)\b", value, re.IGNORECASE):
        score += 5
    if "," in value and is_project_descriptor_line(value):
        score += 4
    if is_project_descriptor_line(value) and not re.match(r"^\d", value.strip()):
        score += 5
    if re.match(r"^\d+[- ]?story\b", value.strip(), re.IGNORECASE):
        score -= 5
    if value.isupper():
        score += 2
    words = value.split()
    if 2 <= len(words) <= 7:
        score += 2
    if len(set(words)) <= max(1, len(words) // 2):
        score -= 4
    return score

def is_plan_noise_line(value: str) -> bool:
    return bool(
        re.search(
            r"\b(sheet|sheet title|sheet no|page no|drawing|drawing scale|as noted|issued for|scale|date|revision|revisions|revised|comments?|ahj|approved|checked|drawn|title block|legend|detail|details|symbol|north|sprinkler|fire protection|fire prevention|architect|engineer|contractor|consultant|code|deferred|submittal|cover sheet|cover plate|white cover|floor plan|site plan|piping plan|reflected ceiling plan|building sections?|vicinity|index|notes?|scope of work|project team|project info|project data|project design data|design data|abbreviations?|exclusions?|city water main|water main)\b",
            value,
            re.IGNORECASE,
        )
    )

def normalize_text(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", value.lower())

def _provisional_project_name(title_block_text: str, full_text: str, file_name: str) -> str:
    """A first-pass project name, ranked before any address is known, so the
    address finders have something to measure proximity and affinity against."""
    for text in (title_block_text, full_text):
        provisional = rank_project_name_candidates(normalize_plan_lines(text or ""), "", file_name)
        if provisional:
            return provisional[0]["name"]
    return ""


#: Stage keys analyze_plan_core emits through its ``progress`` callback, in the
#: order they can fire. The percent/copy mapping lives with the caller (server),
#: so this module stays a pure text pipeline that only names what it is doing.
#: Stages are SKIPPED, never reordered - a caller can rely on the order below
#: being monotonic.
PLAN_SCAN_STAGES = (
    "title-block",   # pdfminer read of the sheet-1 title-block zone
    "page-text",     # selectable text of the first plan pages
    "ocr-fallback",  # whole-sheet OCR (encoded / raster sheets)
    "fields",        # name + address inference and confidence
    "ocr-retry",     # whole-sheet OCR re-read after a weak first answer
    "detail-ocr",    # OCR of the sheets' embedded details / bracing calc sheets
    "catalog",       # sprinkler / pipe / hanger catalog term matching
    "strip-ocr",     # targeted high-DPI OCR of the title strips
    "ai-read",       # AI title-block read (the visible "AI" stage)
)
# NB: the order above is the order the PIPELINE runs in, which is not the order
# a reader would guess: catalog matching happens on the text we already have,
# BEFORE the two title-block rescue passes fire. Progress narrates what is
# actually happening, so the AI stage is the last one a slow scan shows.


def _stage_emitter(progress):
    """Wrap a caller's progress callback so the pipeline can announce stages
    without caring whether anyone is listening. ``None`` (the default, and the
    only thing the browser edition passes) makes every emit a no-op, so the
    scan behaves EXACTLY as it did before this existed."""
    if progress is None:
        return lambda stage, detail="": None

    def emit(stage: str, detail: str = "") -> None:
        try:
            progress(stage, detail)
        except Exception:
            # Progress reporting must never be able to fail a scan.
            pass

    return emit


def analyze_plan_core(
    pdf_path: Path,
    file_name: str = "",
    scan_options: dict | None = None,
    ocr_hooks: dict | None = None,
    progress=None,
) -> dict:
    _ocr = ocr_hooks or {}
    _stage = _stage_emitter(progress)
    scan_options = normalize_plan_scan_options(scan_options)
    file_name = file_name or pdf_path.name
    _stage("title-block")
    title_block_sheets = extract_title_block_sheets(pdf_path)
    title_block_text = "\n".join(sheet["text"] for sheet in title_block_sheets)
    _stage("page-text")
    full_text, pages = extract_pdf_text(pdf_path, max_pages=12)
    used_ocr_fallback = False
    ocr_note = ""
    if _ocr and _ocr["should_use"](title_block_text, full_text):
        _stage("ocr-fallback")
        ocr_text, ocr_note = _ocr["extract"](pdf_path, max_pages=min(max(pages or 1, 1), 4))
        if ocr_text:
            title_block_text = ocr_text
            full_text = ocr_text
            used_ocr_fallback = True
    # The project name is a fact about the DOCUMENT, not about whichever text
    # slice we happen to be searching, and the address finders need it to judge
    # proximity and token affinity. Rank it once, with the filename as evidence,
    # and hand the same answer to both passes - the title-block pass used to be
    # given no filename at all, so it went into the address search name-blind.
    _stage("fields")
    provisional_name = _provisional_project_name(title_block_text, full_text, file_name)
    contractor = infer_plan_contractor("\n".join([title_block_text, full_text]))
    firm_addresses = drop_project_labeled_addresses(
        [contractor.get("address") or ""],
        project_labeled_address_keys(title_block_text, full_text)
        | project_vouched_address_keys((title_block_text, full_text), provisional_name),
    )
    title_project = infer_project_info(title_block_text, source="title block", pages=pages, exclude_addresses=firm_addresses, project_name=provisional_name)
    full_project = infer_project_info(full_text, source="first plan pages", pages=pages, file_name=file_name, exclude_addresses=firm_addresses, project_name=provisional_name)
    project = choose_plan_project(title_project, full_project)

    # Never OCR-retry a sheet whose title block we already read confidently.
    # The retry replaces the page text wholesale, so a good pdfminer address
    # ("3305 W KUNA RD") gets overwritten by a worse OCR of the same field
    # ("3305 WKUNA RD") purely because the NAME looked weak.
    strong_title_block = any(
        candidate.get("labeled") or candidate.get("sheetCount", 0) >= 2
        for candidate in title_block_name_candidates(
            title_block_sheets, project.get("address") or "", set(), file_name
        )[:1]
    )
    if _ocr and not used_ocr_fallback and not strong_title_block and _ocr["should_retry"](project, file_name):
        _stage("ocr-retry")
        ocr_text, ocr_note = _ocr["extract"](pdf_path, max_pages=min(max(pages or 1, 1), 4))
        if ocr_text:
            title_block_text = ocr_text
            full_text = ocr_text
            # The OCR replaced the text wholesale, so the provisional name has
            # to be re-read from it before the address finders use it.
            provisional_name = _provisional_project_name(title_block_text, full_text, file_name)
            contractor = infer_plan_contractor("\n".join([title_block_text, full_text]))
            firm_addresses = drop_project_labeled_addresses(
                [contractor.get("address") or ""],
                project_labeled_address_keys(title_block_text, full_text)
                | project_vouched_address_keys((title_block_text, full_text), provisional_name),
            )
            title_project = infer_project_info(title_block_text, source="title block", pages=pages, exclude_addresses=firm_addresses, project_name=provisional_name)
            full_project = infer_project_info(full_text, source="first plan pages", pages=pages, file_name=file_name, exclude_addresses=firm_addresses, project_name=provisional_name)
            project = choose_plan_project(title_project, full_project)
            used_ocr_fallback = True

    notes = project.get("notes") or []
    if not title_block_text.strip():
        notes.append("No selectable title-block text was found; scanned plans may need an image crop or OCR.")
    elif project.get("source") == "title block":
        notes.append("Title block was checked first.")
    if used_ocr_fallback:
        notes.append("OCR fallback was used because the PDF text was selectable but encoded.")
    elif ocr_note:
        notes.append(ocr_note)
    project["notes"] = notes
    project["fileName"] = file_name
    combined_text = "\n".join([title_block_text, full_text])
    if looks_like_encoded_pdf_text(combined_text):
        project["notes"].append("Plan text appears encoded, so some title-block and legend details may require OCR or a clearer plan export.")
    project["contractor"] = infer_plan_contractor(combined_text)

    # Rendered details (riser details, hanger details, seismic bracing calc
    # sheets) are embedded RASTERS - the sheet's text layer says nothing about
    # what is lettered inside them. This pass reads them.
    #
    # It runs AFTER name/address are settled and its text is never fed back
    # into them: the whole point is to add catalog detections without putting a
    # tesseract guess anywhere near the title-block answer.
    detail_fn = _ocr.get("extract_detail_regions") if _ocr else None
    detail_regions: list = []
    detail_pages: list = []
    if detail_fn and any(scan_options.values()):
        _stage("detail-ocr")
        try:
            detail = detail_fn(pdf_path) or {}
        except Exception:
            detail = {}
        detail_regions = detail.get("regions") or []
        detail_pages = detail.get("pages") or []
        if detail.get("seconds"):
            project["detailOcrSeconds"] = detail["seconds"]
    # Sheets past the 12 the pypdf pass reads. A bracing calc or a riser detail
    # is routinely on sheet 14 of a 20-sheet set, and until now nothing looked.
    deep_text = "\n".join(
        page.get("text") or "" for page in detail_pages if (page.get("page") or 0) > 12
    )
    catalog_text = "\n".join([combined_text, deep_text]) if deep_text.strip() else combined_text

    _stage("catalog")
    project["sprinklers"] = (
        merge_plan_sprinklers(
            infer_plan_sprinkler_legend(catalog_text),
            infer_plan_sprinklers_from_regions(detail_regions),
        ) if scan_options["sprinklers"] else []
    )
    project["pipeTypes"] = (
        merge_plan_pipe_types(
            infer_plan_pipe_types(catalog_text),
            infer_plan_pipe_types_from_regions(detail_regions),
        ) if scan_options["piping"] else []
    )
    for field, category, enabled in (
        ("fittings", "Fittings", scan_options["piping"]),
        ("hangers", "Hangers", scan_options["hangers"]),
        ("bracing", "Bracing", scan_options["bracing"]),
        ("valves", "Valves", scan_options["valves"]),
        ("miscellaneous", "Miscellaneous", scan_options["miscellaneous"]),
    ):
        project[field] = merge_plan_catalog_terms(
            infer_plan_catalog_terms(catalog_text, category),
            infer_plan_catalog_terms_from_regions(detail_regions, category),
        ) if enabled else []

    # The seismic-bracing answer proper: the models printed on the calc sheet,
    # not a pair of generic "Lateral Brace" / "Sway Brace" rows that name the
    # same thing twice. The generic rows STAY in project["bracing"] - loadout
    # triggers are armed against them - and the review dialog decides which of
    # the two shapes to draw.
    if scan_options["bracing"]:
        seismic = infer_seismic_bracing(catalog_text, detail_regions)
        project["seismicBracing"] = seismic
        # Components FIRST in the merge. The generic pass also emits a bare
        # "Fig. 980" term (it has always known the figure numbers), and merging
        # the other way round let that thin row win the dedupe - taking the
        # role, the manufacturer and the calc-sheet provenance down with it.
        project["bracing"] = merge_plan_catalog_terms(
            bracing_component_detections(seismic), project["bracing"],
            limit=PLAN_CATALOG_TERM_LIMIT + len(seismic.get("components") or []),
        )
    else:
        project["seismicBracing"] = {"detected": False, "components": [], "manufacturer": ""}

    project["detailRegions"] = [
        {
            "id": region.get("id"),
            "page": region.get("page"),
            "box": list(region.get("box") or ()),
            "pageSize": list(region.get("pageSize") or ()),
            "words": len(region.get("words") or []),
        }
        for region in detail_regions
    ]
    project["scanTextSample"] = clean_text(combined_text[:24000])
    # Kept apart from scanTextSample on purpose: the front end's custom-alias
    # matcher and material triggers want it, but nothing that judges the
    # project name or address may ever see OCR text.
    project["detailTextSample"] = clean_text(
        "\n".join((region.get("text") or "") for region in detail_regions)[:16000]
    )
    project["scanOptions"] = scan_options
    project["name"] = detected_project_caps(correct_detected_project_name(project.get("name"), file_name))
    project["address"] = detected_project_caps(project.get("address"))
    for candidate in project.get("projectNameCandidates") or []:
        candidate["name"] = detected_project_caps(candidate.get("name"))
    # NB: the pdfminer sheets survive an OCR fallback. OCR only replaces the
    # flat TEXT; the glyph geometry it was read from is still true, and
    # discarding it threw away a correct title-block answer whenever the OCR
    # retry happened to fire on a sheet that had parsed perfectly well.
    ranking_sheets = title_block_sheets
    if used_ocr_fallback and not ranking_sheets:
        # Genuinely scanned: no geometry at all, but a labelled field in the
        # OCR text is still a labelled field.
        ocr_lines = normalize_plan_lines(title_block_text)
        if ocr_lines:
            ranking_sheets = [
                {
                    "sheet": 1,
                    "width": 0.0,
                    "height": 0.0,
                    "groups": [ocr_lines],
                    "lineGroups": [[{"text": line, "size": 0.0} for line in ocr_lines]],
                    "lines": [],
                    "text": title_block_text,
                }
            ]
    apply_project_name_confidence(
        project,
        ranking_sheets,
        title_block_text,
        file_name,
        combined_text,
    )

    # Targeted title-block OCR rescue. The whole-sheet OCR renders a 42-inch
    # sheet at 150 DPI, which leaves title-block lettering ~15px tall; cropping
    # the title strips and rendering just those at high DPI recovers names and
    # addresses the full-page pass shreds (measured: 9 of 11 remaining name
    # failures readable this way). Only runs when the answer is still shaky, so
    # cleanly-parsed plans never pay for it.
    strips_fn = _ocr.get("extract_title_strips") if _ocr else None
    address_ok = validate_plan_address(project.get("address") or "").get("ok")
    if strips_fn and (project.get("nameConfidence") != "high" or not address_ok):
        _stage("strip-ocr")
        try:
            strips_text = strips_fn(pdf_path) or ""
        except Exception:
            strips_text = ""
        strip_lines = normalize_plan_lines(strips_text) if strips_text.strip() else []
        if strip_lines:
            strip_sheet = {
                "sheet": 1,
                "width": 0.0,
                "height": 0.0,
                "groups": [strip_lines],
                "lineGroups": [[{"text": line, "size": 0.0} for line in strip_lines]],
                "lines": [],
                "text": strips_text,
            }
            before_conf = project.get("nameConfidence")
            before_name = project.get("name")
            if before_conf != "high":
                apply_project_name_confidence(
                    project,
                    ranking_sheets + [strip_sheet],
                    "\n".join([title_block_text, strips_text]),
                    file_name,
                    "\n".join([combined_text, strips_text]),
                )
                # OCR text earns at most "medium": a labelled field read through
                # tesseract is strong evidence but not the 100%-precise class
                # that pdfminer-read labels measured as.
                if project.get("nameConfidence") == "high" and before_conf != "high":
                    project["nameConfidence"] = "medium"
                    if project.get("name") != before_name:
                        project["nameSource"] = "targeted title-block OCR, labeled field"
            # Address rescue: take the strip address when the current one is
            # missing/invalid, or when the strip found the SAME address with
            # more of it intact (whole-sheet OCR drops single-char directionals
            # like "W" and suffixes like "4E").
            #
            # The strips are a fresh text, so the letterhead in them has to be
            # re-detected here: reusing the firm addresses found in the pdfminer
            # text let J.R. Wagner's office walk in through this door on the one
            # sheet where the pdfminer read of the logo was unparseable.
            strip_firm_addresses = drop_project_labeled_addresses(
                list(firm_addresses) + [(infer_plan_contractor(strips_text) or {}).get("address") or ""],
                project_labeled_address_keys(strips_text),
            )
            strip_project = infer_project_info(
                strips_text, source="title block", pages=pages,
                exclude_addresses=strip_firm_addresses,
                project_name=project.get("name") or "",
            )
            strip_address = strip_project.get("address") or ""
            if strip_address and validate_plan_address(strip_address).get("ok"):
                if _address_may_be_replaced(project, strip_address):
                    project["address"] = detected_project_caps(strip_address)
                    project["addressSignals"] = strip_project.get("addressSignals") or []
            note = "Targeted high-resolution OCR of the title block was used."
            if note not in (project.get("notes") or []):
                project.setdefault("notes", []).append(note)

    # AI title-block read - the last resort, and the only pass that can read a
    # raster scan tesseract shreds. Cloud-side it is subscriber-gated and
    # metered; here it only fires when the local pipeline is still shaky, so a
    # cleanly-parsed plan never spends a metered call.
    ai_fn = _ocr.get("extract_title_ai") if _ocr else None
    address_ok = validate_plan_address(project.get("address") or "").get("ok")
    if ai_fn and (project.get("nameConfidence") != "high" or not address_ok):
        _stage("ai-read")
        try:
            ai_read = ai_fn(pdf_path, file_name) or {}
        except Exception:
            ai_read = {}
        ai_name = detected_project_caps(clean_plan_project_name(ai_read.get("name") or ""))
        # The AI returns a COMPLETE address string. Do not run it back through
        # format_plan_address: its street-suffix regex ends the street at "Rd"
        # and shreds a trailing directional ("5950 Woodbridge Rd E, Acampo, CA"
        # became "5950 Woodbridge Rd, E, AC"). Light cleanup + validation only.
        ai_address = re.sub(r"\s+", " ", str(ai_read.get("address") or "")).strip(" ,;")
        ai_address = re.sub(r"^(?:PROJECT\s+)?(?:SITE\s+)?ADDRESS\s*[:\-]\s*", "", ai_address, flags=re.IGNORECASE)
        # An AI read of the pixels can drop small words from a name the local
        # pipeline read from real glyphs ("SPENGLER - CAN SWIM" for
        # "SPENGLER - I CAN SWIM"). If the AI answer is just a token-subset of
        # the local one, the local answer stands.
        local_name = project.get("name") or ""
        if ai_name and local_name:
            ai_tokens = set(re.findall(r"[A-Z0-9]+", ai_name.upper()))
            local_tokens = set(re.findall(r"[A-Z0-9]+", local_name.upper()))
            if ai_tokens and ai_tokens <= local_tokens:
                ai_name = ""
        if ai_name and is_project_name_candidate(ai_name, allow_street_address=True):
            candidates = project.get("projectNameCandidates") or []
            entry = {"name": ai_name, "score": 200, "reasons": ["AI title-block read"]}
            key = normalize_text(ai_name)
            candidates = [entry] + [c for c in candidates if normalize_text(c.get("name") or "") != key]
            project["projectNameCandidates"] = candidates[:8]
            if project.get("nameConfidence") != "high":
                project["name"] = ai_name
                project["nameConfidence"] = "medium"
                project["nameSource"] = "AI title-block read"
        if ai_address and validate_plan_address(ai_address).get("ok"):
            if _address_may_be_replaced(project, ai_address):
                project["address"] = detected_project_caps(ai_address)
                project["addressSignals"] = ["AI title-block read"]
        if ai_name or ai_address:
            note = "AI read of the title block was used."
            if note not in (project.get("notes") or []):
                project.setdefault("notes", []).append(note)
    return project


#: Signals that make a locally-read address load-bearing rather than a guess.
_BACKED_ADDRESS_SIGNALS = frozenset({"proximity", "affinity", "labeled"})


def _address_may_be_replaced(project: dict, candidate: str) -> bool:
    """Whether a rescue pass (strip OCR, AI) may overwrite the current address.

    An address the local pipeline read NEXT TO the project name, or that shares
    a distinctive token with it, or that the sheet explicitly labelled, is the
    project's address whether or not it carries a ZIP. Rescue passes may still
    complete it - a token-superset of the same address is the same address with
    more of it intact - but they may not swap it for a different one just
    because theirs looks more complete. Without that rule the strip OCR traded
    a correct "517 CHANNEL ST" for a ZIP-bearing letterhead in Modesto, and the
    AI's own (correct) read never got a chance to disagree."""
    current = project.get("address") or ""
    if not current:
        return True
    if address_tokens_subsumed(current, candidate):
        return True
    if set(project.get("addressSignals") or []) & _BACKED_ADDRESS_SIGNALS:
        return False
    return not validate_plan_address(current).get("ok")


#: Suffix/directional spellings collapse so "1093 JEFFERSON ST" reads as a
#: subset of "1093 W JEFFERSON STREET" (same address, more of it intact).
_ADDRESS_TOKEN_CANON = {
    "STREET": "ST", "AVENUE": "AVE", "ROAD": "RD", "DRIVE": "DR",
    "BOULEVARD": "BLVD", "LANE": "LN", "COURT": "CT", "PLACE": "PL",
    "HIGHWAY": "HWY", "PARKWAY": "PKWY", "CIRCLE": "CIR",
    "NORTH": "N", "SOUTH": "S", "EAST": "E", "WEST": "W",
}


def _canonical_address_tokens(value: str) -> set:
    tokens = re.findall(r"[A-Z0-9]+", (value or "").upper())
    return {_ADDRESS_TOKEN_CANON.get(token, token) for token in tokens}


def address_tokens_subsumed(current: str, candidate: str) -> bool:
    """True when ``candidate`` is the same street line as ``current`` but with
    strictly more of it intact - the dropped-directional upgrade case."""
    cur = _canonical_address_tokens(current)
    cand = _canonical_address_tokens(candidate)
    if not cur or not cand:
        return False
    if cur < cand:  # proper subset: everything we had, plus more
        return True
    # Truncation artifacts are PREFIXES ("AC" for "ACAMPO", "JEFFERS" for
    # "JEFFERSON"): accept the upgrade when every current token is a prefix of
    # some candidate token and the candidate carries strictly more material.
    def covered(token: str) -> bool:
        # Prefix tolerance is for truncated WORDS ("AC" for "ACAMPO", "JEFFERS"
        # for "JEFFERSON"). A street number is not a truncation of a longer
        # street number - 517 Channel St and 5171 Channel St are two buildings -
        # so digits must match exactly.
        if token.isdigit():
            return token in cand
        return any(other == token or (len(token) >= 2 and other.startswith(token))
                   for other in cand)
    return all(covered(token) for token in cur) and len(cand) > len(cur)


def apply_project_name_confidence(
    project: dict,
    title_block_sheets: list[dict],
    title_block_text: str,
    file_name: str,
    combined_text: str,
) -> None:
    """Decide the project name from the title block, then say how sure we are
    and where it came from. A low-confidence guess is published as an EMPTY
    name with the ranked candidates still attached - an empty field is faster
    to fix than a plausible wrong one, and it is the plausible-wrong answers
    that make the scan feel like a coin flip."""
    contractor = project.get("contractor") or {}
    design_firms = infer_plan_design_firms(combined_text, normalize_plan_lines(title_block_text), contractor)
    # The firm's own office address must not be offered as the project NAME
    # either. Allowing address-shaped names (buildings named after their street)
    # otherwise lets a letterhead address win the slot.
    firm_address = (contractor.get("address") or "").strip()
    if firm_address:
        design_firms.add(normalize_text(firm_address))
    address = project.get("address") or ""
    title_candidates = title_block_name_candidates(title_block_sheets, address, design_firms, file_name)

    existing = [
        candidate
        for candidate in (project.get("projectNameCandidates") or [])
        if candidate.get("name") and normalize_text(candidate["name"]) not in design_firms
    ]
    merged: list[dict] = []
    seen: set[str] = set()
    for candidate in title_candidates:
        key = normalize_text(candidate["name"])
        if key in seen:
            continue
        seen.add(key)
        merged.append(
            {
                "name": detected_project_caps(candidate["name"]),
                "score": candidate["score"],
                "reasons": candidate["reasons"],
            }
        )
    for candidate in existing:
        key = normalize_text(candidate["name"])
        if key in seen:
            continue
        seen.add(key)
        merged.append({"name": candidate["name"], "score": int(candidate.get("score") or 0), "reasons": candidate.get("reasons") or []})
    project["projectNameCandidates"] = merged[:8]

    file_candidate = project_name_from_filename(file_name)
    file_key = normalize_text(file_candidate)
    confidence = "low"
    source = ""
    name = ""

    if title_candidates:
        top = title_candidates[0]
        name = detected_project_caps(top["name"])
        sheet_count = top.get("sheetCount", 1)
        # Calibrated against the labelled corpus, not assumed. A LABELLED
        # title-block field was right 10 times out of 10; cross-sheet
        # consensus on an unlabelled string was right 9 times out of 15,
        # because a notes heading repeats on every sheet just as faithfully as
        # the project name does. So consensus is corroboration, not proof, and
        # only a labelled field earns "high".
        if top.get("labeled"):
            confidence = "high"
            source = "labeled field"
        elif sheet_count >= 2:
            confidence = "medium"
            source = f"title block, {sheet_count} sheets"
        else:
            confidence = "medium"
            sheet_number = (title_block_sheets[0].get("sheet") if title_block_sheets else 1) or 1
            source = f"title block, sheet {sheet_number}"
    else:
        fallback = project.get("name") or ""
        fallback_key = normalize_text(fallback)
        if fallback and fallback_key in design_firms:
            fallback = ""
        if fallback and file_key and filename_similarity_score(fallback, file_candidate) >= 8:
            # Page text and the filename agree - not a title-block read, but
            # two independent sources saying the same thing.
            name = fallback
            confidence = "medium"
            source = "plan text and PDF filename"
        elif fallback and file_key and fallback_key == file_key:
            name = fallback
            confidence = "low"
            source = "PDF filename"
        elif fallback:
            confidence = "low"
            source = "first plan pages"
        elif file_candidate:
            confidence = "low"
            source = "PDF filename"

    if confidence == "low":
        if not project.get("projectNameCandidates") and (project.get("name") or file_candidate):
            project["projectNameCandidates"] = [
                {"name": project.get("name") or detected_project_caps(file_candidate), "score": 0, "reasons": [source or "best guess"]}
            ]
        name = ""

    project["name"] = name
    project["nameConfidence"] = confidence
    project["nameSource"] = source
    if not name and "Project name was not confidently detected." not in (project.get("notes") or []):
        project.setdefault("notes", []).append("Project name was not confidently detected.")


# ---------------------------------------------------------------------------
# Scan provenance geometry - "show me where it read this"
#
# The scan already renders title-block crops (server.render_title_strip_images)
# and already knows, per glyph, where on the PAGE a title-block line sits. The
# two live in different coordinate systems, so pointing at a value inside a crop
# needs one honest converter between them. Everything below is pure arithmetic
# and string matching over data the pipeline already produced: it can neither
# change a scan result nor reach the filesystem.
# ---------------------------------------------------------------------------

#: The crop rectangles server.render_title_strip_images cuts, as
#: (x0, y0, x1, y1) FRACTIONS of the page in PDF page space - origin at the
#: BOTTOM-left, y increasing upward, exactly like pdfminer reports glyphs.
#:
#: Read them that way and the historical names stop being confusing: pdfium's
#: crop argument is (left, bottom, right, top) MARGINS, so "bottom": y from
#: 0.78 to 1.0 keeps the band at the TOP of the PDF coordinate space - which is
#: the top of the sheet as printed. Only "right" spans the full sheet height and
#: therefore reliably contains a bottom-right title block.
TITLE_STRIP_CROPS = {
    "right": (0.80, 0.0, 1.0, 1.0),
    "bottom": (0.0, 0.78, 1.0, 1.0),
    "corner": (0.60, 0.60, 1.0, 1.0),
}

#: What each crop is called in front of a customer.
TITLE_STRIP_LABELS = {
    "right": "right edge of sheet 1",
    "bottom": "top strip of sheet 1",
    "corner": "upper-right corner of sheet 1",
}


def page_rect_to_crop_pixels(page_rect, crop_fractions, page_size, image_size) -> dict | None:
    """Convert a PDF-page rectangle into pixel coordinates inside one rendered
    title-strip crop.

    ``page_rect``      (x0, y0, x1, y1) in PDF page units, origin bottom-left.
    ``crop_fractions`` (fx0, fy0, fx1, fy1) - one entry of TITLE_STRIP_CROPS.
    ``page_size``      (width, height) of the page in the same PDF units.
    ``image_size``     (px_w, px_h) of the rendered crop bitmap.

    Returns ``{"x", "y", "w", "h", "coverage"}`` in crop pixel space with the
    image's origin at its TOP-left (the way a browser lays an overlay over an
    ``<img>``), clipped to the image. ``coverage`` is the fraction of the source
    rectangle that survived clipping, so a caller can pick the crop that
    actually contains the value. Returns ``None`` when the rectangle misses the
    crop entirely, or when any input is degenerate.
    """
    try:
        x0, y0, x1, y1 = (float(v) for v in page_rect)
        fx0, fy0, fx1, fy1 = (float(v) for v in crop_fractions)
        page_w, page_h = float(page_size[0]), float(page_size[1])
        px_w, px_h = float(image_size[0]), float(image_size[1])
    except (TypeError, ValueError, IndexError):
        return None
    if page_w <= 0 or page_h <= 0 or px_w <= 0 or px_h <= 0:
        return None
    if x1 < x0:
        x0, x1 = x1, x0
    if y1 < y0:
        y0, y1 = y1, y0

    crop_x0, crop_x1 = fx0 * page_w, fx1 * page_w
    crop_y0, crop_y1 = fy0 * page_h, fy1 * page_h
    crop_w, crop_h = crop_x1 - crop_x0, crop_y1 - crop_y0
    if crop_w <= 0 or crop_h <= 0:
        return None
    scale_x, scale_y = px_w / crop_w, px_h / crop_h

    # x runs the same way in both spaces; y is flipped, because a bitmap counts
    # rows downward from the crop's TOP edge (crop_y1 in page space).
    ix0 = (x0 - crop_x0) * scale_x
    ix1 = (x1 - crop_x0) * scale_x
    iy0 = (crop_y1 - y1) * scale_y
    iy1 = (crop_y1 - y0) * scale_y

    source_area = max(ix1 - ix0, 0.0) * max(iy1 - iy0, 0.0)
    cx0, cy0 = max(0.0, ix0), max(0.0, iy0)
    cx1, cy1 = min(px_w, ix1), min(px_h, iy1)
    if cx1 <= cx0 or cy1 <= cy0:
        return None
    clipped_area = (cx1 - cx0) * (cy1 - cy0)
    coverage = 1.0 if source_area <= 0 else min(1.0, clipped_area / source_area)
    return {
        "x": round(cx0, 2),
        "y": round(cy0, 2),
        "w": round(cx1 - cx0, 2),
        "h": round(cy1 - cy0, 2),
        "coverage": round(coverage, 4),
    }


def best_crop_for_page_rect(page_rect, page_size, image_sizes: dict) -> tuple | None:
    """Pick the crop that shows the most of ``page_rect`` and return
    ``(crop_id, box)``. ``image_sizes`` maps crop id -> (px_w, px_h) for the
    crops that were actually rendered. Ties break toward the SMALLEST crop, so
    a value lands in the tightest view that still contains all of it."""
    best = None
    for crop_id, fractions in TITLE_STRIP_CROPS.items():
        size = image_sizes.get(crop_id)
        if not size:
            continue
        box = page_rect_to_crop_pixels(page_rect, fractions, page_size, size)
        if not box:
            continue
        area = float(size[0]) * float(size[1])
        key = (-box["coverage"], area)
        if best is None or key < best[0]:
            best = (key, crop_id, box)
    if best is None:
        return None
    return best[1], best[2]


def rotated_box_to_upright(box, rotated_size, degrees: int = -90) -> dict | None:
    """Map a box found in a rotated copy of a crop back onto the upright crop.

    The strip OCR runs a second pass over ``image.rotate(-90, expand=True)``
    because CAD title blocks letter the right strip vertically. Boxes from that
    pass live in the ROTATED bitmap's space and have to come home before they
    can be drawn over the upright image the viewer shows.

    PIL's ``rotate(-90, expand=True)`` turns the image CLOCKWISE: an upright
    point ``(ux, uy)`` in a W x H image lands at ``(H - uy, ux)`` in the H x W
    result. Inverting that maps a rotated box back, with width and height
    trading places.
    """
    try:
        x, y = float(box["x"]), float(box["y"])
        w, h = float(box["w"]), float(box["h"])
        rot_w, rot_h = float(rotated_size[0]), float(rotated_size[1])
    except (TypeError, ValueError, KeyError):
        return None
    if w <= 0 or h <= 0 or rot_w <= 0 or rot_h <= 0:
        return None
    if degrees % 360 != 270:
        return None
    return {
        "x": round(y, 2),
        "y": round(max(0.0, rot_w - (x + w)), 2),
        "w": round(h, 2),
        "h": round(w, 2),
        "coverage": box.get("coverage", 1.0),
    }


def union_boxes(boxes: list) -> dict | None:
    """Smallest box covering them all - a value read as several OCR words is one
    highlight, not five."""
    usable = [b for b in boxes if b and b.get("w") and b.get("h")]
    if not usable:
        return None
    x0 = min(float(b["x"]) for b in usable)
    y0 = min(float(b["y"]) for b in usable)
    x1 = max(float(b["x"]) + float(b["w"]) for b in usable)
    y1 = max(float(b["y"]) + float(b["h"]) for b in usable)
    return {
        "x": round(x0, 2), "y": round(y0, 2),
        "w": round(x1 - x0, 2), "h": round(y1 - y0, 2),
        "coverage": min(float(b.get("coverage", 1.0)) for b in usable),
    }


def pad_box(box, pad: float, image_size) -> dict | None:
    """Breathing room around a highlight, clipped to the image."""
    if not box:
        return None
    try:
        px_w, px_h = float(image_size[0]), float(image_size[1])
    except (TypeError, ValueError, IndexError):
        return box
    x0 = max(0.0, float(box["x"]) - pad)
    y0 = max(0.0, float(box["y"]) - pad)
    x1 = min(px_w, float(box["x"]) + float(box["w"]) + pad)
    y1 = min(px_h, float(box["y"]) + float(box["h"]) + pad)
    if x1 <= x0 or y1 <= y0:
        return box
    return {
        "x": round(x0, 2), "y": round(y0, 2),
        "w": round(x1 - x0, 2), "h": round(y1 - y0, 2),
        "coverage": box.get("coverage", 1.0),
    }


def provenance_key(value: str) -> str:
    """Match key for locating a value in source text: letters and digits only,
    so "IMPERIAL VALLEY COLLEGE" finds "Imperial Valley College" and an address
    survives its own punctuation."""
    return re.sub(r"[^a-z0-9]+", "", str(value or "").lower())


def locate_value_in_title_block_lines(sheets: list, value: str) -> dict | None:
    """Find where on the PAGE a detected value was lettered.

    Searches the pdfminer title-block lines of sheet 1 (the only sheet the crops
    come from) for the line whose text carries the value, and returns
    ``{"rect": (x0, y0, x1, y1), "pageSize": (w, h), "text": line_text}``.

    This is a LOOKUP run after the answer is already decided - it never feeds
    back into ranking, so it cannot move a bench number.
    """
    key = provenance_key(value)
    if len(key) < 3 or not sheets:
        return None
    sheet = None
    for candidate in sheets:
        if int(candidate.get("sheet") or 0) == 1:
            sheet = candidate
            break
    if sheet is None:
        sheet = sheets[0]
    width = float(sheet.get("width") or 0.0)
    height = float(sheet.get("height") or 0.0)
    lines = sheet.get("lines") or []
    if width <= 0 or height <= 0 or not lines:
        return None
    exact = None
    contains = None
    for line in lines:
        line_key = provenance_key(line.get("text") or "")
        if not line_key:
            continue
        if line_key == key:
            exact = line
            break
        if contains is None and key in line_key:
            contains = line
    line = exact or contains
    if line is None:
        return None
    try:
        rect = (float(line["x0"]), float(line["y0"]), float(line["x1"]), float(line["y1"]))
    except (KeyError, TypeError, ValueError):
        return None
    return {
        "rect": rect,
        "pageSize": (width, height),
        "text": line.get("text") or "",
        "exact": exact is not None,
    }


def locate_value_in_ocr_words(words: list, value: str) -> dict | None:
    """Find a value inside one crop's tesseract word boxes.

    ``words`` is the TSV pass's output for a single image: dicts with
    ``left``/``top``/``w``/``h``/``text`` in that image's pixel space. Returns
    ``{"box": {...}, "words": n}`` for the shortest run of consecutive words
    whose joined text carries the value, or ``None``.
    """
    key = provenance_key(value)
    if len(key) < 3 or not words:
        return None
    keys = [provenance_key(word.get("text") or "") for word in words]
    best = None
    for start in range(len(words)):
        # Cheap prefilter: a run worth walking starts with a word that appears
        # in the value. Keeps this linear-ish on a 900-word strip.
        if not keys[start] or keys[start] not in key:
            continue
        joined = ""
        for end in range(start, min(len(words), start + 14)):
            joined += keys[end]
            if len(joined) > len(key) + 24:
                break
            if key in joined:
                span = end - start + 1
                if best is None or span < best[0]:
                    best = (span, start, end)
                break
    if best is None:
        return None
    _span, start, end = best
    boxes = [
        {"x": float(word["left"]), "y": float(word["top"]),
         "w": float(word["w"]), "h": float(word["h"]), "coverage": 1.0}
        for word in words[start:end + 1]
    ]
    box = union_boxes(boxes)
    if not box:
        return None
    return {"box": box, "words": end - start + 1}

