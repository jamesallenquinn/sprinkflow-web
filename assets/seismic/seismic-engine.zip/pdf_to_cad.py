# -*- coding: utf-8 -*-
"""PDF-to-CAD vector converter (Python port of the SprinkFlow Design Platform's
PdfVectorImport.cs). Turns a vector PDF page into a downloadable R12 DXF.

Pipeline: extract paths -> group by CAD layer (PDF Optional Content Groups,
the same layer data AutoCAD's PDFIMPORT reads) or by color when the PDF has
no layer data -> weld polylines -> text phrases -> scale -> emit R12/AC1009
DXF (POLYLINE/TEXT, one DXF layer per group, no handles). Uses pdfminer.six
(MIT) deliberately; PyMuPDF is AGPL and avoided here.

Layer extraction: PDFs plotted from CAD (AutoCAD "DWG To PDF" etc.) wrap each
layer's content in marked-content sections (`/OC /name BDC ... EMC`) that
reference named OCGs. A custom PDFPageInterpreter resolves those tags against
the live resource dict and a custom aggregator stamps every painted path and
glyph with the active layer name.

See PDF_TO_CAD_HANDOFF.md for the full spec and the seven gotchas.
"""
from __future__ import annotations

import math
import re
from collections import defaultdict, Counter

from pdfminer.converter import PDFPageAggregator
from pdfminer.layout import (LTLine, LTCurve, LTRect, LTChar, LTFigure, LAParams,
                             LTTextLine, LTTextLineVertical)
from pdfminer.pdfinterp import PDFPageInterpreter, PDFResourceManager
from pdfminer.pdfpage import PDFPage
from pdfminer.pdftypes import resolve1, stream_value
from pdfminer.psparser import PSLiteral, literal_name

PT_PER_IN = 72.0
WELD_TOL_IN = 0.02          # endpoints within 0.02 paper-inch weld
NEAR_WHITE = 245            # fills with r,g,b >= 245 are dropped (invisible junk)
BEZIER_CHORDS = 6           # cubic bezier -> 6 straight chords

# --- color helpers ---------------------------------------------------------

def _to_rgb(color):
    if color is None:
        return None
    if isinstance(color, (int, float)):
        v = max(0, min(255, int(round(color * 255)))); return (v, v, v)
    if isinstance(color, (list, tuple)):
        if len(color) == 1:
            v = max(0, min(255, int(round(color[0] * 255)))); return (v, v, v)
        if len(color) >= 3:
            return tuple(max(0, min(255, int(round(c * 255)))) for c in color[:3])
    return None


def _hex(rgb):
    return None if rgb is None else "#%02X%02X%02X" % rgb


def _label_for(rgb):
    if rgb is None:
        return "Uncolored"
    r, g, b = rgb
    if r == g == b:
        if r < 40:
            return "Black linework"
        pct = round(100 - (r / 255.0) * 100)
        return "Grey linework (%d%%)" % pct
    return "Color linework"


# ACI (AutoCAD Color Index) nearest match for common colors.
# Black -> ACI 250 (renders 51,51,51 - verified exact in AutoSPRINK), NOT
# ACI 7: AutoSPRINK draws 7 as 96-grey. White still maps to 7.
_ACI = {(0, 0, 0): 250, (51, 51, 51): 250, (255, 255, 255): 7,
        (255, 0, 0): 1, (255, 255, 0): 2,
        (0, 255, 0): 3, (0, 255, 255): 4, (0, 0, 255): 5, (255, 0, 255): 6,
        (128, 128, 128): 8, (192, 192, 192): 9}


def _nearest_aci(rgb):
    if rgb is None:
        return 7
    best, bd = 7, 1e18
    for c, aci in _ACI.items():
        d = sum((a - b) ** 2 for a, b in zip(rgb, c))
        if d < bd:
            bd, best = d, aci
    return best


def _to_rgb_from_hex(hexc):
    if not hexc:
        return None
    h = hexc.lstrip("#")
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))


# --- OCG (PDF layer) tracking ----------------------------------------------

def _pdf_text(value):
    """PDF string/name object -> python str (handles UTF-16BE BOM)."""
    value = resolve1(value)
    if isinstance(value, bytes):
        if value[:2] == b"\xfe\xff":
            try:
                return value[2:].decode("utf-16-be", "replace")
            except Exception:
                return None
        return value.decode("latin-1", "replace")
    if isinstance(value, PSLiteral):
        return str(value.name)
    if isinstance(value, str):
        return value
    return None


def _ocg_name(prop):
    """OCG or OCMD dict (possibly a ref) -> layer name, else None."""
    prop = resolve1(prop)
    if not hasattr(prop, "get"):
        return None
    type_name = getattr(resolve1(prop.get("Type")), "name", None)
    if type_name == "OCMD":
        ocgs = resolve1(prop.get("OCGs"))
        if isinstance(ocgs, list):
            ocgs = ocgs[0] if ocgs else None
        prop = resolve1(ocgs)
        if not hasattr(prop, "get"):
            return None
    return _pdf_text(prop.get("Name"))


class _LayerInterpreter(PDFPageInterpreter):
    """Tracks the active Optional Content Group through BDC/EMC marked-content
    scopes (and /OC entries on Form XObjects) and mirrors it onto the device.
    Property-name resolution must happen here because only the interpreter
    knows the CURRENT resource dict (forms carry their own /Properties)."""

    def do_BDC(self, tag, props):
        layer = None
        try:
            if getattr(tag, "name", None) == "OC":
                prop = props
                if isinstance(props, PSLiteral):
                    prop_map = resolve1((self.resources or {}).get("Properties"))
                    if hasattr(prop_map, "get"):
                        prop = prop_map.get(props.name)
                layer = _ocg_name(prop)
        except Exception:
            layer = None
        if hasattr(self.device, "push_layer"):
            self.device.push_layer(layer)
        return super().do_BDC(tag, props)

    def do_BMC(self, tag):
        if hasattr(self.device, "push_layer"):
            self.device.push_layer(None)   # inherit the enclosing layer
        return super().do_BMC(tag)

    def do_EMC(self):
        if hasattr(self.device, "pop_layer"):
            self.device.pop_layer()
        return super().do_EMC()

    def do_Do(self, xobjid_arg):
        # A whole Form XObject can be assigned to a layer via its /OC entry.
        layer = None
        try:
            xobj = self.xobjmap.get(literal_name(xobjid_arg))
            if xobj is not None:
                oc = stream_value(xobj).attrs.get("OC")
                if oc is not None:
                    layer = _ocg_name(oc)
        except Exception:
            layer = None
        pushed = False
        if layer is not None and hasattr(self.device, "push_layer"):
            self.device.push_layer(layer)
            pushed = True
        try:
            return super().do_Do(xobjid_arg)
        finally:
            if pushed:
                self.device.pop_layer()


class _LayerAggregator(PDFPageAggregator):
    """PDFPageAggregator that stamps each painted path / glyph with the layer
    name active at paint time (``.ocg_layer`` on the layout object)."""

    def __init__(self, rsrcmgr, pageno=1, laparams=None):
        super().__init__(rsrcmgr, pageno=pageno, laparams=laparams)
        self._layer_stack = []

    def push_layer(self, name):
        inherited = self._layer_stack[-1] if self._layer_stack else None
        self._layer_stack.append(name if name is not None else inherited)

    def pop_layer(self):
        if self._layer_stack:
            self._layer_stack.pop()

    def _stamp_new(self, before):
        layer = self._layer_stack[-1] if self._layer_stack else None
        if layer is None:
            return
        objs = getattr(self.cur_item, "_objs", None)
        if objs is None:
            return
        for obj in objs[before:]:
            if getattr(obj, "ocg_layer", None) is None:
                obj.ocg_layer = layer

    def paint_path(self, gstate, stroke, fill, evenodd, path):
        before = len(getattr(self.cur_item, "_objs", ()))
        super().paint_path(gstate, stroke, fill, evenodd, path)
        self._stamp_new(before)

    def render_char(self, *args, **kwargs):
        before = len(getattr(self.cur_item, "_objs", ()))
        adv = super().render_char(*args, **kwargs)
        self._stamp_new(before)
        return adv


def _load_page(pdf_path, page_index):
    """Layer-aware replacement for pdfminer's extract_pages(): returns the
    analyzed LTPage with .ocg_layer stamped on paths and chars."""
    rsrcmgr = PDFResourceManager()
    device = _LayerAggregator(rsrcmgr, laparams=LAParams())
    interpreter = _LayerInterpreter(rsrcmgr, device)
    with open(pdf_path, "rb") as fh:
        for page in PDFPage.get_pages(fh, pagenos=[page_index]):
            interpreter.process_page(page)
            return device.get_result()
    raise ValueError("Page %d not found in this PDF." % (page_index + 1))


def _default_off_layers(pdf_path):
    """Layer names hidden by default in the PDF (catalog /OCProperties /D /OFF).
    Their content is invisible in any PDF viewer, so default them unchecked."""
    try:
        from pypdf import PdfReader
        reader = PdfReader(str(pdf_path))
        ocp = reader.trailer["/Root"].get("/OCProperties")
        if ocp is None:
            return set()
        ocp = ocp.get_object() if hasattr(ocp, "get_object") else ocp
        d = ocp.get("/D") or {}
        d = d.get_object() if hasattr(d, "get_object") else d
        off = d.get("/OFF") or []
        return {str(o.get_object().get("/Name")) for o in off}
    except Exception:
        return set()


def _layer_id(name):
    """Stable group id for a layer group ('' = content with no layer tag)."""
    return "layer:" + (name or "")


# --- stage 1-2: extract + flatten -----------------------------------------

def _flatten(original_path):
    """PDF path commands -> list of polylines (each a list of (x,y) paper inches)."""
    polylines = []
    cur = []
    start = None
    ipt = lambda pt: (pt[0] / PT_PER_IN, pt[1] / PT_PER_IN)  # pdf point tuple -> paper inches
    for seg in original_path or []:
        op = seg[0]
        if op == "m":
            if len(cur) >= 2:
                polylines.append(cur)
            start = ipt(seg[1]); cur = [start]
        elif op == "l":
            cur.append(ipt(seg[1]))
        elif op in ("c", "v", "y") and cur:
            # cubic bezier; pdfminer emits 'c' with 3 control tuples. Flatten to chords.
            p0 = cur[-1]
            pts = [ipt(seg[k]) for k in range(1, len(seg))]
            if op == "v":       # first control = current point
                p1, p2, p3 = p0, pts[0], pts[1]
            elif op == "y":     # last control = endpoint
                p1, p2, p3 = pts[0], pts[1], pts[1]
            else:
                p1, p2, p3 = pts[0], pts[1], pts[2]
            for i in range(1, BEZIER_CHORDS + 1):
                t = i / BEZIER_CHORDS; mt = 1 - t
                x = mt**3 * p0[0] + 3 * mt**2 * t * p1[0] + 3 * mt * t**2 * p2[0] + t**3 * p3[0]
                y = mt**3 * p0[1] + 3 * mt**2 * t * p1[1] + 3 * mt * t**2 * p2[1] + t**3 * p3[1]
                cur.append((x, y))
        elif op == "h" and start is not None:
            if cur and cur[-1] != start:
                cur.append(start)
    if len(cur) >= 2:
        polylines.append(cur)
    return polylines


def _line_layer(line):
    """A text line's layer = the majority layer of its characters."""
    votes = Counter()
    for ch in line:
        if isinstance(ch, LTChar):
            votes[getattr(ch, "ocg_layer", None)] += 1
    if not votes:
        return None
    return votes.most_common(1)[0][0]


# --- stroke-weight buckets --------------------------------------------------
# PDF stroke widths are in points (1/72"). Plots made at true pen weights land
# almost exactly on these: 0.50 mm = 1.42 pt, 0.25 mm = 0.71 pt, 0.13 mm =
# 0.37 pt. Buckets: thin < 0.5 pt (~0.18 mm) < med < 1.2 pt (~0.42 mm) < thick.
THIN_MAX_PT = 0.5
MED_MAX_PT = 1.2
W_SUFFIX = {"thick": "-W050", "med": "-W025", "thin": "-W010", "fill": "", "hatch": "-HATCH"}
# DXF lineweight enum (1/100 mm) for the R2000 layers; -3 = default (fills).
W_LINEWEIGHT = {"thick": 50, "med": 25, "thin": 9, "hatch": 9, "fill": -3}
# AutoSPRINK entity widths: its importer shows Element Width = lineweight x
# 0.0023622 (probe-calibrated, 3 data points exact). These enum values land
# the Width box on 0.4984 / 0.2504 / 0.0945 - no Layer Width flip needed.
# (In generic CAD they read as fat 2.11/1.06/0.4 mm pens - that's why they
# only go on ENTITIES in the AutoSPRINK output; layers keep the true values.)
W_ENTITY_AUTOSPRINK = {"thick": 211, "med": 106, "thin": 40, "hatch": 40, "fill": None}

def _wclass(width_pt):
    try:
        w = float(width_pt)
    except (TypeError, ValueError):
        return "med"
    if w <= 0:
        return "med"       # 0-width strokes render as hairlines of device res; treat as medium
    if w < THIN_MAX_PT:
        return "thin"
    if w < MED_MAX_PT:
        return "med"
    return "thick"


# --- stipple / hatch-dot detection ------------------------------------------
# Concrete stipple and similar hatch textures come through as hundreds of tiny
# separate shapes. When a color cohort has a crowd of them they move to a
# dedicated "hatch" bucket -> their own picker row (color mode) and a -HATCH
# layer, so they can be excluded or bulk-styled in one selection.
HATCH_MAX_DIM_IN = 0.08     # a "tiny" shape: bbox under ~2 mm on paper
HATCH_MIN_COUNT = 150

def _bbox_maxdim(poly):
    xs = [p[0] for p in poly]; ys = [p[1] for p in poly]
    return max(max(xs) - min(xs), max(ys) - min(ys))

def _tag_hatch(linework, fills):
    tiny = defaultdict(list)   # (layer, hex) -> [(source dict, key, tiny indexes)]
    for src in (linework, fills):
        for key in list(src.keys()):
            idxs = [i for i, p in enumerate(src[key]) if _bbox_maxdim(p) < HATCH_MAX_DIM_IN]
            if idxs:
                tiny[(key[0], key[1])].append((src, key, idxs))
    for (lay, hexc), refs in tiny.items():
        if sum(len(idxs) for _s, _k, idxs in refs) < HATCH_MIN_COUNT:
            continue
        for src, key, idxs in refs:
            drop = set(idxs)
            moved = [p for i, p in enumerate(src[key]) if i in drop]
            keep = [p for i, p in enumerate(src[key]) if i not in drop]
            if keep:
                src[key] = keep
            else:
                del src[key]
            linework[(lay, hexc, "hatch")] += moved


def _extract(page):
    """Return (linework, fills, textlines) keyed by (layer, hex, wclass).
    layer is the OCG name or None for untagged content; wclass is the stroke
    weight bucket ("thin"/"med"/"thick"), "fill" for fills, "hatch" for
    stipple dots (tagged after the walk)."""
    linework = defaultdict(list)   # (layer, hex, wclass) -> list of polylines
    fills = defaultdict(list)      # (layer, hex, "fill") -> list of closed polylines
    textlines = []                 # list of (layer, LTTextLine)

    def walk(obj):
        for el in obj:
            if isinstance(el, (LTLine, LTCurve, LTRect)):
                layer = getattr(el, "ocg_layer", None)
                op = getattr(el, "original_path", None)
                polys = _flatten(op)
                if getattr(el, "stroke", False):
                    rgb = _to_rgb(getattr(el, "stroking_color", None))
                    wcl = _wclass(getattr(el, "linewidth", None))
                    for p in polys:
                        linework[(layer, _hex(rgb), wcl)].append(p)
                if getattr(el, "fill", False):
                    rgb = _to_rgb(getattr(el, "non_stroking_color", None))
                    if rgb is not None and min(rgb) >= NEAR_WHITE:
                        continue  # drop near-white fills
                    for p in polys:
                        if len(p) >= 3:
                            fills[(layer, _hex(rgb), "fill")].append(p)
            elif isinstance(el, LTTextLine):
                if el.get_text().strip():
                    textlines.append((_line_layer(el), el))
                continue  # don't descend into the line's chars
            if isinstance(el, LTFigure) or hasattr(el, "__iter__"):
                try:
                    walk(el)
                except TypeError:
                    pass

    walk(page)
    _tag_hatch(linework, fills)
    return linework, fills, textlines


# --- stage 3: weld ---------------------------------------------------------

def _weld(polylines):
    """Chain polylines whose endpoints meet cleanly at a degree-2 vertex.
    Weld at the polyline level (NOT segment level - see gotcha #1)."""
    if not polylines:
        return []
    inv = 1.0 / WELD_TOL_IN

    def key(pt):
        return (round(pt[0] * inv), round(pt[1] * inv))

    # endpoint key -> list of (poly index, which end 0=start 1=end)
    ends = defaultdict(list)
    for i, p in enumerate(polylines):
        ends[key(p[0])].append((i, 0))
        ends[key(p[-1])].append((i, 1))

    used = [False] * len(polylines)
    result = []
    for i in range(len(polylines)):
        if used[i]:
            continue
        chain = list(polylines[i]); used[i] = True
        # extend forward from the tail, then reverse to extend the other way
        for _ in range(2):
            while True:
                k = key(chain[-1])
                cands = [(j, e) for (j, e) in ends[k] if not used[j]]  # unused neighbors here
                if len(cands) != 1:
                    break  # degree != 2 (or none) -> honest junction, stop
                j, e = cands[0]
                nxt = polylines[j] if e == 0 else list(reversed(polylines[j]))
                used[j] = True
                chain.extend(nxt[1:])  # skip the duplicate shared point
            chain.reverse()
        result.append(chain)
    return result


# --- stage 4: text words -> phrases ---------------------------------------

def _textlines_to_entities(textlines):
    """(layer, LTTextLine) pairs -> DXF-ready text entities (paper inches).
    Each entity also carries its full paper-inch bbox and its index in
    ``textlines`` so the smart-layer classifier can reason about where the
    text sits without importing pdfminer (see pdf_to_cad_smart)."""
    ents = []
    for idx, (layer, line) in enumerate(textlines):
        txt = line.get_text().strip()
        if not txt:
            continue
        vertical = isinstance(line, LTTextLineVertical)
        # representative char height from the tallest glyph on the line
        heights = [ch.height for ch in line if isinstance(ch, LTChar)]
        h_pt = (max(heights) if heights else (line.height if not vertical else line.width))
        ents.append({
            "t": txt,
            "x": line.x0 / PT_PER_IN,
            "y": line.y0 / PT_PER_IN,
            "h": (h_pt / PT_PER_IN) * 0.72,   # DXF text height ~ cap height, not full bbox
            "rot": 90 if vertical else 0,
            "layer": layer,
            "idx": idx,
            "x1": line.x1 / PT_PER_IN,
            "y1": line.y1 / PT_PER_IN,
        })
    return ents


# --- R12 DXF emit ----------------------------------------------------------

def _layer_name(hexc):
    if not hexc:
        return "PDF-UNCOLORED"
    return "PDF-" + hexc.lstrip("#")


def _dxf_layer_from_name(name, used):
    """PDF layer name -> valid unique R12 layer name (A-Z 0-9 $ - _, max 31)."""
    base = re.sub(r"[^A-Za-z0-9_$-]+", "_", (name or "PDF-UNTAGGED")).upper().strip("_") or "LAYER"
    base = base[:31]
    candidate, i = base, 2
    while candidate in used:
        suffix = "_%d" % i
        candidate = base[:31 - len(suffix)] + suffix
        i += 1
    used.add(candidate)
    return candidate


def _dxf(records, scale):
    """records: list of {name, aci, polys: [(entity_aci_or_None, pts)], texts}.
    Geometry in paper inches; scale = real inches per paper inch.
    Emit R12/AC1009, no handles."""
    out = []
    p = lambda c, v: (out.append(str(c)), out.append(str(v)))
    n = lambda v: ("%.4f" % float(v))

    layers = {}
    for rec in records:
        layers.setdefault(rec["name"], rec["aci"])

    p(0, "SECTION"); p(2, "HEADER"); p(9, "$ACADVER"); p(1, "AC1009")
    p(9, "$INSUNITS"); p(70, 1)  # inches
    p(0, "ENDSEC")
    p(0, "SECTION"); p(2, "TABLES")
    p(0, "TABLE"); p(2, "LAYER"); p(70, len(layers))
    for name, aci in layers.items():
        p(0, "LAYER"); p(2, name); p(70, 0); p(62, aci); p(6, "CONTINUOUS")
    p(0, "ENDTAB"); p(0, "ENDSEC")
    p(0, "SECTION"); p(2, "ENTITIES")

    for rec in records:
        layer = rec["name"]
        for entity_aci, pts in rec["polys"]:
            p(0, "POLYLINE"); p(8, layer)
            if entity_aci is not None and entity_aci != rec["aci"]:
                p(62, entity_aci)   # mixed-color layer: keep the entity's color
            p(66, 1); p(70, 0)
            for (x, y) in pts:
                p(0, "VERTEX"); p(8, layer); p(10, n(x * scale)); p(20, n(y * scale)); p(30, 0)
            p(0, "SEQEND")
        for ph in rec["texts"]:
            txt = ph["t"].strip()
            if not txt:
                continue
            p(0, "TEXT"); p(8, layer)
            p(10, n(ph["x"] * scale)); p(20, n(ph["y"] * scale)); p(30, 0)
            p(40, n(ph["h"] * scale)); p(1, txt)
            if ph["rot"]:
                p(50, n(ph["rot"]))

    p(0, "ENDSEC"); p(0, "EOF")
    return "\n".join(out)


def _dxf_r2000(records, scale):
    """R2000/AC1015 via ezdxf with true lineweights on the layers (records
    carry "lw" in 1/100 mm). AutoSPRINK's acceptance of R2000 is unproven
    (R12 is the known-safe path) — this is the opt-in "test it" output.
    Verified by read-back before returning, per the DXF export rule."""
    import io
    import ezdxf
    doc = ezdxf.new("R2004")   # true color (420) needs 2004+; R2000 drops layer.rgb silently
    doc.header["$INSUNITS"] = 1  # inches
    msp = doc.modelspace()
    # Two width channels, calibrated to AutoSPRINK's importer (probe tests):
    # - entities carry the compensated weights (W_ENTITY_AUTOSPRINK) so the
    #   Element Width box imports pre-filled at ~0.5/0.25/0.09 - users never
    #   touch Layer Width
    # - layers keep the TRUE mm weights as the manual fallback
    # Colors are ACI-only: AutoSPRINK ignores DXF true color (its companion
    # ACI turns RGB black into maroon), and blacks map to ACI 250.
    for rec in records:
        lw = int(rec.get("lw", -3))
        elw = rec.get("entity_lw")
        if rec["name"] not in doc.layers:
            attribs = {"color": int(rec["aci"])}
            if lw > 0:
                attribs["lineweight"] = lw
            doc.layers.add(rec["name"], **attribs)
        for entity_aci, pts in rec["polys"]:
            dxfattribs = {"layer": rec["name"]}
            if elw is not None:
                dxfattribs["lineweight"] = int(elw)
            if entity_aci is not None and entity_aci != rec["aci"]:
                dxfattribs["color"] = int(entity_aci)
            msp.add_lwpolyline([(x * scale, y * scale) for (x, y) in pts], dxfattribs=dxfattribs)
        for ph in rec["texts"]:
            txt = ph["t"].strip()
            if not txt:
                continue
            text = msp.add_text(txt, dxfattribs={
                "layer": rec["name"],
                "height": ph["h"] * scale,
                "rotation": ph.get("rot") or 0,
            })
            text.set_placement((ph["x"] * scale, ph["y"] * scale))
    buf = io.StringIO()
    doc.write(buf)
    dxf = buf.getvalue()
    check = ezdxf.read(io.StringIO(dxf))            # read-back gate
    assert len(check.modelspace()) >= sum(len(r["polys"]) for r in records)
    return dxf


# --- public API ------------------------------------------------------------

def _page_count(pdf_path):
    with open(pdf_path, "rb") as f:
        return sum(1 for _ in PDFPage.get_pages(f))


def _layer_names_in(linework, fills, textlines):
    names = {k[0] for k in linework} | {k[0] for k in fills} | {lay for lay, _ in textlines}
    names.discard(None)
    return names


def _hatch_group_id(hexc):
    return (hexc or "#000000") + "|HATCH"


# --- smart layers (pdf_to_cad_smart) ---------------------------------------
# Reading a dense sheet with pdfminer costs 60-100 s, and Smart layers make the
# user want to re-run it (changing the plot scale re-tunes every real-world
# threshold). One page of extraction is cached so that second read is free. The
# key carries the file's size and mtime, so a different PDF at the same path can
# never be served from it.
_EXTRACT_CACHE = {"key": None, "value": None}

SMART_PREFIX = "smart:"


def _extract_cache_key(pdf_path, page_index):
    try:
        import os
        st = os.stat(str(pdf_path))
        return (str(pdf_path), int(page_index), st.st_size, st.st_mtime_ns)
    except Exception:
        return None


def _load_and_extract(pdf_path, page_index):
    """(page_w_in, page_h_in, linework, fills, textlines) with a 1-page cache."""
    key = _extract_cache_key(pdf_path, page_index)
    if key is not None and _EXTRACT_CACHE["key"] == key:
        return _EXTRACT_CACHE["value"]
    page = _load_page(pdf_path, page_index)
    linework, fills, textlines = _extract(page)
    value = (page.width / PT_PER_IN, page.height / PT_PER_IN, linework, fills, textlines)
    if key is not None:
        _EXTRACT_CACHE["key"] = key
        _EXTRACT_CACHE["value"] = value
    return value


def _bbox_in(pts):
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    return min(xs), min(ys), max(xs), max(ys)


def _smart_items(linework, fills, phrases, only_untagged):
    """Plain-dict records for pdf_to_cad_smart.classify().

    ``ref`` addresses the source record exactly, so convert() can route each
    polyline to the layer the classifier chose. Keeping these dicts free of
    pdfminer objects is what lets the smart module stay stdlib-only (it runs
    in Pyodide for the Web Edition)."""
    items = []
    for src, kind in ((linework, "line"), (fills, "fill")):
        for key, polys in src.items():
            lay, hexc, wcl = key
            if only_untagged and lay is not None:
                continue
            for i, pts in enumerate(polys):
                if len(pts) < 2:
                    continue
                x0, y0, x1, y1 = _bbox_in(pts)
                items.append({"ref": (kind, key, i), "kind": kind, "pts": pts,
                              "x0": x0, "y0": y0, "x1": x1, "y1": y1,
                              "hex": hexc, "wclass": wcl, "layer": lay})
    for ph in phrases:
        if only_untagged and ph.get("layer") is not None:
            continue
        items.append({"ref": ("text", ph["idx"]), "kind": "text", "pts": [],
                      "text": ph["t"],
                      "x0": ph["x"], "y0": ph["y"], "x1": ph["x1"], "y1": ph["y1"],
                      "hex": None, "wclass": "text", "layer": ph.get("layer")})
    return items


def _smart_classify(linework, fills, phrases, page_w, page_h, scale, only_untagged):
    import pdf_to_cad_smart
    items = _smart_items(linework, fills, phrases, only_untagged)
    return pdf_to_cad_smart.classify(items, page_w, page_h, scale=scale), items


def smart_group_id(name):
    return SMART_PREFIX + name


def analyze(pdf_path, page_index, smart=False, scale=96.0):
    """Return the group summary for the picker + page size. Groups are real CAD
    layers when the PDF carries OCG layer data, else color groups.

    ``smart=True`` swaps the colour buckets for SEMANTIC layers named after what
    the linework is (A-WALL, A-DOOR, ... plus L-* layers read off the sheet's own
    legend). Content that already carries a real OCG layer name keeps it; only
    untagged content is classified. ``scale`` is real inches per paper inch and
    tunes every real-world threshold, so re-analyzing after the user picks a
    different plot scale is worth it (the page extraction is cached)."""
    page_w, page_h, linework, fills, textlines = _load_and_extract(pdf_path, page_index)
    layer_names = _layer_names_in(linework, fills, textlines)
    groups = []
    smart_stats = None

    if smart:
        phrases = _textlines_to_entities(textlines)
        result, _items = _smart_classify(linework, fills, phrases, page_w, page_h,
                                         scale, bool(layer_names))
        smart_stats = result["stats"]
        if layer_names:
            # tagged content keeps its real CAD layer name; the classifier only
            # names what the PDF left untagged
            hidden = _default_off_layers(pdf_path)
            counts = Counter()
            colors = defaultdict(Counter)
            for (lay, hexc, _wcl), polys in linework.items():
                if lay is None:
                    continue
                counts[lay] += len(polys); colors[lay][hexc] += len(polys)
            for (lay, hexc, _wcl), polys in fills.items():
                if lay is None:
                    continue
                counts[lay] += len(polys); colors[lay][hexc] += len(polys)
            for lay, _line in textlines:
                if lay is not None:
                    counts[lay] += 0
            for lay, count in counts.most_common():
                dominant = colors[lay].most_common(1)
                hexc = (dominant[0][0] if dominant else None) or "#000000"
                is_hidden = lay in hidden
                groups.append({"id": _layer_id(lay), "hex": hexc,
                               "label": lay + (" (hidden in PDF)" if is_hidden else ""),
                               "kind": "layer", "count": count, "defaultOn": not is_hidden})
        import pdf_to_cad_smart
        for i, row in enumerate(result["layers"]):
            groups.append({
                "id": smart_group_id(row["name"]),
                "hex": pdf_to_cad_smart.layer_color(row["name"], i),
                "label": "%s (%s)" % (row["label"], row["name"]),
                "kind": "smart",
                "smartKind": row["kind"],
                "count": row["count"],
                "confidence": row["confidence"],
                "hint": row["hint"],
                "defaultOn": row["defaultOn"],
            })
        return {"pageWidthIn": round(page_w, 3), "pageHeightIn": round(page_h, 3),
                "textLines": len(_textlines_to_entities(textlines)),
                "layerMode": bool(layer_names), "smart": True,
                "smartStats": smart_stats, "groups": groups}

    if layer_names:
        hidden = _default_off_layers(pdf_path)
        counts = Counter()
        colors = defaultdict(Counter)
        for (lay, hexc, _wcl), polys in linework.items():
            counts[lay] += len(polys); colors[lay][hexc] += len(polys)
        for (lay, hexc, _wcl), polys in fills.items():
            counts[lay] += len(polys); colors[lay][hexc] += len(polys)
        for lay, _line in textlines:
            counts[lay] += 0   # touch, so text-only layers still get a row
        for lay, count in counts.most_common():
            dominant = colors[lay].most_common(1)
            hexc = (dominant[0][0] if dominant else None) or "#000000"
            is_hidden = lay is not None and lay in hidden
            groups.append({
                "id": _layer_id(lay),
                "hex": hexc,
                "label": (lay if lay is not None else "No layer tag")
                         + (" (hidden in PDF)" if is_hidden else ""),
                "kind": "layer",
                "count": count,
                "defaultOn": not is_hidden,
            })
    else:
        by_hex_line = defaultdict(list)
        by_hex_hatch = defaultdict(list)
        for (_lay, hexc, wcl), polys in linework.items():
            (by_hex_hatch if wcl == "hatch" else by_hex_line)[hexc] += polys
        by_hex_fill = defaultdict(list)
        for (_lay, hexc, _wcl), polys in fills.items():
            by_hex_fill[hexc] += polys
        for hexc, polys in sorted(by_hex_line.items(), key=lambda kv: -len(kv[1])):
            groups.append({"id": hexc, "hex": hexc,
                           "label": _label_for(_to_rgb_from_hex(hexc)),
                           "kind": "linework", "count": len(polys), "defaultOn": True})
        for hexc, polys in sorted(by_hex_fill.items(), key=lambda kv: -len(kv[1])):
            groups.append({"id": hexc, "hex": hexc,
                           "label": _label_for(_to_rgb_from_hex(hexc)) + " (fills)",
                           "kind": "fill", "count": len(polys), "defaultOn": True})
        for hexc, polys in sorted(by_hex_hatch.items(), key=lambda kv: -len(kv[1])):
            groups.append({"id": _hatch_group_id(hexc), "hex": hexc,
                           "label": _label_for(_to_rgb_from_hex(hexc)) + " (stipple / hatch dots)",
                           "kind": "hatch", "count": len(polys), "defaultOn": True})

    return {"pageWidthIn": round(page_w, 3),
            "pageHeightIn": round(page_h, 3),
            "textLines": len(_textlines_to_entities(textlines)),
            "layerMode": bool(layer_names), "smart": False,
            "groups": groups}


def convert(pdf_path, page_index, selected_ids, scale, include_text=True, include_fills=True,
            dxf_version="R12", smart=False):
    """selected_ids: group ids from analyze() (layer ids, color hexes, or
    "smart:A-WALL" style semantic ids; hatch groups use hex+"|HATCH"). scale:
    real inches per paper inch (1/8"=1'-0" -> 96). Output layers split by stroke
    weight (-W050/-W025/-W010, -HATCH for stipple) so weights survive R12;
    dxf_version="R2000" instead writes true DXF lineweights, which lets the
    smart layers stay unsuffixed (A-WALL rather than A-WALL-W025). Returns DXF
    text + stats."""
    page_w, page_h, linework, fills, textlines = _load_and_extract(pdf_path, page_index)
    layer_names = _layer_names_in(linework, fills, textlines)
    selected = set(selected_ids or [])
    all_phrases = _textlines_to_entities(textlines)
    phrases = all_phrases if include_text else []

    records = []
    raw = welded = 0

    if smart:
        raw, welded, records = _smart_records(
            linework, fills, all_phrases, phrases, page_w, page_h, scale,
            selected, bool(layer_names), include_fills, dxf_version)
    elif layer_names:
        per_key = {}   # (ocg layer, wclass) -> {polys, texts}

        def rec(lay, wcl):
            return per_key.setdefault((lay, wcl), {"polys": [], "texts": []})

        for (lay, hexc, wcl), polys in linework.items():
            if _layer_id(lay) not in selected:
                continue
            raw += len(polys)
            chains = polys if wcl == "hatch" else _weld(polys)   # dots don't weld
            welded += len(chains)
            aci = _nearest_aci(_to_rgb_from_hex(hexc))
            rec(lay, wcl)["polys"] += [(aci, pts) for pts in chains]
        if include_fills:
            for (lay, hexc, _wcl), polys in fills.items():
                if _layer_id(lay) not in selected:
                    continue
                aci = _nearest_aci(_to_rgb_from_hex(hexc))
                rec(lay, "fill")["polys"] += [(aci, pts) for pts in polys]
        for ph in phrases:
            if _layer_id(ph.get("layer")) in selected:
                rec(ph.get("layer"), "fill")["texts"].append(ph)   # text -> unsuffixed base layer

        used = set()
        for (lay, wcl), data in sorted(per_key.items(), key=lambda kv: -len(kv[1]["polys"])):
            acis = Counter(aci for aci, _pts in data["polys"])
            suffix = W_SUFFIX[wcl]
            base = str(lay if lay is not None else "PDF-UNTAGGED")
            records.append({
                "name": _dxf_layer_from_name(base[:31 - len(suffix)] + suffix, used),
                # text-only records default to black (250 - see _ACI note)
                "aci": acis.most_common(1)[0][0] if acis else 250,
                "lw": W_LINEWEIGHT[wcl],
                "entity_lw": W_ENTITY_AUTOSPRINK[wcl],
                "polys": data["polys"],
                "texts": data["texts"],
            })
    else:
        by_group = defaultdict(list)   # (hexc, wclass) -> polys
        for (_lay, hexc, wcl), polys in linework.items():
            gid = _hatch_group_id(hexc) if wcl == "hatch" else hexc
            if gid not in selected:
                continue
            by_group[(hexc, wcl)] += polys
        for (hexc, wcl), polys in sorted(by_group.items(), key=lambda kv: -len(kv[1])):
            raw += len(polys)
            chains = polys if wcl == "hatch" else _weld(polys)
            welded += len(chains)
            records.append({"name": _layer_name(hexc) + W_SUFFIX[wcl],
                            "aci": _nearest_aci(_to_rgb_from_hex(hexc)),
                            "lw": W_LINEWEIGHT[wcl],
                            "entity_lw": W_ENTITY_AUTOSPRINK[wcl],
                            "polys": [(None, pts) for pts in chains], "texts": []})
        if include_fills:
            by_hex_fill = defaultdict(list)
            for (_lay, hexc, _wcl), polys in fills.items():
                by_hex_fill[hexc] += polys
            for hexc, polys in by_hex_fill.items():
                if hexc not in selected:
                    continue
                records.append({"name": _layer_name(hexc),
                                "aci": _nearest_aci(_to_rgb_from_hex(hexc)),
                                "lw": W_LINEWEIGHT["fill"],
                                "polys": [(None, pts) for pts in polys], "texts": []})
        if phrases:
            records.append({"name": "PDF-TEXT", "aci": 250, "lw": -3, "polys": [], "texts": phrases})

    dxf = _dxf_r2000(records, scale) if str(dxf_version).upper() == "R2000" else _dxf(records, scale)
    return {"dxf": dxf, "rawPolylines": raw, "weldedPolylines": welded,
            "textLines": sum(len(r["texts"]) for r in records),
            "layerMode": bool(layer_names), "smart": bool(smart),
            "layerNames": [r["name"] for r in records],
            "pageWidthIn": round(page_w, 3),
            "pageHeightIn": round(page_h, 3)}


def _smart_records(linework, fills, all_phrases, phrases, page_w, page_h, scale,
                   selected, has_ocg, include_fills, dxf_version):
    """convert() in Smart-layers mode: classify, then bucket the selected
    content by semantic layer.

    Stroke weight still has to survive. R2000 carries it on the entity, so the
    DXF layer is exactly the semantic name (A-WALL). R12 has no lineweight at
    all, so there the weight keeps riding on the layer NAME the way the colour
    mode already does (A-WALL-W050 / -W025 / -W010) - no information is lost
    either way, and the picker shows the semantic name in both."""
    result, items = _smart_classify(linework, fills, all_phrases, page_w, page_h,
                                    scale, has_ocg)
    assign = result["assign"]
    suffix_by_weight = str(dxf_version).upper() != "R2000"

    keep_text = {ph["idx"]: ph for ph in phrases}
    per_key = {}          # (layer name, wclass) -> {"polys", "texts"}
    raw = welded = 0

    def rec(name, wcl):
        return per_key.setdefault((name, wcl), {"polys": [], "texts": []})

    by_layer_polys = defaultdict(list)   # (name, wclass, hexc) -> polys
    for it in items:
        ref = it["ref"]
        got = assign.get(ref)
        if not got:
            continue
        name = got["layer"]
        gid = smart_group_id(name) if not name.startswith("PDF-") else name
        if gid not in selected:
            continue
        if it["kind"] == "text":
            ph = keep_text.get(it["ref"][1])
            if ph is not None:
                rec(name, "fill")["texts"].append(ph)
            continue
        if it["kind"] == "fill" and not include_fills:
            continue
        by_layer_polys[(name, it["wclass"], it["hex"])].append(it["pts"])

    # anything still tagged with a real OCG layer keeps that layer name
    for (lay, hexc, wcl), polys in linework.items():
        if lay is None or _layer_id(lay) not in selected:
            continue
        by_layer_polys[(str(lay), wcl, hexc)] += polys
    if include_fills:
        for (lay, hexc, wcl), polys in fills.items():
            if lay is None or _layer_id(lay) not in selected:
                continue
            by_layer_polys[(str(lay), "fill", hexc)] += polys
    for ph in phrases:
        if ph.get("layer") is not None and _layer_id(ph["layer"]) in selected:
            rec(str(ph["layer"]), "fill")["texts"].append(ph)

    for (name, wcl, hexc), polys in by_layer_polys.items():
        raw += len(polys)
        chains = polys if wcl == "hatch" else _weld(polys)
        welded += len(chains)
        aci = _nearest_aci(_to_rgb_from_hex(hexc))
        rec(name, wcl)["polys"] += [(aci, pts) for pts in chains]

    used = set()
    records = []
    for (name, wcl), data in sorted(per_key.items(), key=lambda kv: -len(kv[1]["polys"])):
        acis = Counter(aci for aci, _pts in data["polys"])
        suffix = W_SUFFIX.get(wcl, "") if suffix_by_weight else ""
        base = name[:31 - len(suffix)].rstrip("-") + suffix if suffix else name
        records.append({
            "name": _dxf_layer_from_name(base, used),
            "aci": acis.most_common(1)[0][0] if acis else 250,
            "lw": W_LINEWEIGHT.get(wcl, -3),
            "entity_lw": W_ENTITY_AUTOSPRINK.get(wcl),
            "polys": data["polys"],
            "texts": data["texts"],
        })
    return raw, welded, records
