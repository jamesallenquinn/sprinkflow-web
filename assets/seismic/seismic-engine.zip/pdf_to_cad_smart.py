# -*- coding: utf-8 -*-
"""Smart layers for the PDF-to-CAD converter: name a layer after what the
linework IS, not what colour it happens to be.

Two passes, both pure functions over the plain-dict records ``pdf_to_cad``
hands us (see ``pdf_to_cad._smart_items``):

  1. **Geometry heuristics** - wall pairs, door swings, column grids, grid
     bubbles, dimension strings, title block, room names, leaders, hatch and
     fills get semantic layers (``A-WALL``, ``A-DOOR``, ``A-GRID`` ...).
  2. **Legend reading** - the sheet's own LEGEND / SYMBOLS table is parsed into
     rows (symbol at the left, label at the right); every instance of that
     symbol elsewhere on the sheet lands on a layer named after the label
     (``L-1-HR-RATED-WALL``).

Every assignment carries a confidence in 0..1 so the picker can say how sure it
is, and anything that fails every test lands on ``A-MISC`` rather than being
guessed at.

**This module is stdlib-only, on purpose.** The browser (Web Edition) runs the
exact same converter inside Pyodide, where numpy/shapely are not available -
see packaging/build_seismic_web_bundle.py. Do not add a third-party import.

Units: every length is in **paper inches** (the unit ``pdf_to_cad`` extracts
in). Thresholds that describe the BUILDING (wall thickness, column size, door
radius) are written in real-world inches and divided by ``scale`` (real inches
per paper inch, 96 for 1/8"=1'-0"); thresholds that describe ANNOTATION (text
gaps, tick marks, bubble diameters) stay in paper inches, because annotation is
drawn at a fixed size on the sheet no matter what the plan scale is.
"""
from __future__ import annotations

import math
import re
from collections import Counter, defaultdict

# --- semantic layer catalogue ----------------------------------------------
# name -> (human label, default on for a fresh import, one-line hint)
LAYER_INFO = {
    "A-WALL": ("Walls", True, "Parallel line pairs at wall thickness, plus heavy-pen runs."),
    "A-DOOR": ("Doors", True, "Quarter-circle swings with their leaf."),
    "A-WINDOW": ("Windows", True, "Parallel lines bridging a gap in a wall."),
    "A-COLS": ("Columns", True, "Small repeated boxes/circles at column size."),
    "A-GRID": ("Column grid", True, "Full-span lines ending in a lettered/numbered bubble."),
    "A-DIMS": ("Dimensions", False, "Dimension strings, their ticks and extension lines."),
    "A-ANNO": ("Annotation", False, "Notes, tags and leader lines."),
    "A-ROOM": ("Room names", True, "Free-standing uppercase text away from linework."),
    "A-TITLE": ("Sheet border & title block", False, "The border frame and the title-block band."),
    "A-HATCH": ("Hatch / stipple", False, "Crowds of tiny repeated marks (concrete, gravel)."),
    "A-FILL": ("Solid fills", False, "Filled regions."),
    "A-FURN": ("Furniture & fixtures", False, "Small closed shapes that are not columns."),
    "A-MISC": ("Unclassified", True, "Everything no test could name."),
}
LAYER_ORDER = list(LAYER_INFO)

LEGEND_PREFIX = "L-"

# Picker swatch colours - distinct hues so the cards read at a glance. These are
# UI colours only; the DXF keeps each entity's own colour from the PDF.
LAYER_COLOR = {
    "A-WALL": "#1F4E79", "A-DOOR": "#C55A11", "A-WINDOW": "#2E9BD6",
    "A-COLS": "#7030A0", "A-GRID": "#8C8C8C", "A-DIMS": "#B5651D",
    "A-ANNO": "#375623", "A-ROOM": "#548235", "A-TITLE": "#595959",
    "A-HATCH": "#A6A6A6", "A-FILL": "#BF8F00", "A-FURN": "#00786E",
    "A-MISC": "#C00000",
}
LEGEND_PALETTE = ("#0B7285", "#9C36B5", "#C2255C", "#2B8A3E", "#E8590C",
                  "#1864AB", "#5F3DC4", "#A9762A")


def layer_color(name, index=0):
    """Swatch colour for a semantic or legend layer."""
    return LAYER_COLOR.get(name) or LEGEND_PALETTE[index % len(LEGEND_PALETTE)]

# Turned ON by the "For sprinkler design" preset; everything else goes off.
SPRINKLER_PRESET_ON = ("A-WALL", "A-DOOR", "A-WINDOW", "A-COLS", "A-GRID", "A-ROOM")
SPRINKLER_PRESET_OFF = ("A-DIMS", "A-ANNO", "A-FURN", "A-HATCH", "A-FILL", "A-TITLE", "A-MISC")

# --- tuned thresholds (every number here is named on purpose) ---------------

# straightness / collinear dash chaining (paper inches, degrees)
STRAIGHT_TOL_IN = 0.010          # max deviation from the chord to call a polyline straight
SEG_MIN_LEN_IN = 0.012           # shorter than this is a dot, not a segment
ANGLE_QUANT_DEG = 2.0            # collinear bucket width
RHO_QUANT_IN = 0.02              # collinear bucket offset width
ANGLE_TOL_DEG = 2.5              # two runs are "parallel" within this
COLLINEAR_RHO_TOL_IN = 0.014     # ...and "collinear" within this offset
DASH_GAP_MAX_IN = 0.22           # dashes further apart than this start a new run
MAX_POLY_PTS_FOR_SEGS = 96       # don't explode very dense curves into segments

# walls (real-world inches)
WALL_MIN_THICK_IN = 3.0
WALL_MAX_THICK_IN = 14.0
WALL_MIN_LEN_IN = 24.0
WALL_OVERLAP_MIN = 0.55          # shared span / shorter run
WALL_THICK_PEN_MIN_LEN_IN = 72.0  # heavy-pen fallback: a 6 ft+ thick run is a wall
WALL_EXTRA_MIN_LEN_IN = 6.0      # a collinear leftover this long is still wall
WALL_EXTRA_REACH_IN = 0.30       # ...if it sits within this (paper in) of the wall
WALL_RETURN_FACTOR = 1.6         # a return/jamb is at most this x the wall thickness
WALL_JOIN_TOL_IN = 0.03          # paper inches

# doors (real-world inches, except the join tolerance)
DOOR_MIN_R_IN = 18.0
DOOR_MAX_R_IN = 60.0
DOOR_ARC_MIN_TURN_DEG = 50.0
DOOR_ARC_MAX_TURN_DEG = 135.0
DOOR_RADIUS_VAR_MAX = 0.14       # rms radius error / mean radius
DOOR_LEAF_TOL = 0.35             # leaf length within +/-35% of the arc radius
DOOR_JOIN_TOL_IN = 0.05          # paper inches

# windows (real-world inches)
WINDOW_MIN_W_IN = 18.0
WINDOW_MAX_W_IN = 180.0
WINDOW_MIN_LINES = 2

# columns (real-world inches)
COL_MIN_SIZE_IN = 6.0
COL_MAX_SIZE_IN = 36.0
COL_MIN_REPEATS = 3
COL_SIZE_QUANT_IN = 3.0
COL_ALIGN_TOL_IN = 12.0

# column grid (paper inches for the bubble, fraction of extents for the line)
GRID_SPAN_FRACTION = 0.50
GRID_BUBBLE_MIN_D_IN = 0.15
GRID_BUBBLE_MAX_D_IN = 0.85
GRID_BUBBLE_ROUND_TOL = 0.25     # rms radius error / mean radius
GRID_BUBBLE_MAX_CHARS = 3
GRID_END_TOL_FACTOR = 2.0        # bubble centre within radius * this of the run's axis
GRID_BUBBLE_REACH_IN = 2.0       # ...and no further than this past the run's end

# hatch fields: a tight bundle of evenly spaced parallel strokes (paper inches).
# The spacing cap is what keeps a ceiling grid (2 ft = 0.25 in at 1/8") out of it.
HATCH_FIELD_MIN_LINES = 6
HATCH_FIELD_MAX_PITCH_IN = 0.10
HATCH_FIELD_PITCH_VAR = 0.35     # stdev / mean pitch

# dimensions (paper inches)
DIM_TEXT_MAX_CHARS = 16
DIM_TEXT_GAP_IN = 0.30
DIM_TICK_MAX_IN = 0.16
DIM_TICK_NEAR_IN = 0.12
DIM_EXT_MAX_IN = 1.80
DIM_LINE_MIN_IN = 0.20

# title block (paper inches / fractions of the page)
TITLE_BORDER_AREA_FRACTION = 0.85
TITLE_LONG_RUN_FRACTION = 0.80
TITLE_STRIP_MIN_IN = 1.20
TITLE_STRIP_MAX_FRACTION = 0.40
TITLE_BAND_MIN_IN = 0.90
TITLE_BAND_MAX_FRACTION = 0.30

# rooms / annotation (paper inches)
ROOM_CLEAR_IN = 0.05
ROOM_MIN_LETTERS = 3
LEADER_TOUCH_IN = 0.10
ANNO_TEXT_NEAR_IN = 0.12

# furniture (real-world inches)
FURN_MAX_SIZE_IN = 132.0

# outlined text: some plotters emit note blocks as vector glyph strokes instead
# of real text. Those are crowds of tiny strokes sitting in a horizontal band.
GLYPH_MAX_SIZE_IN = 0.14         # paper inches
GLYPH_BAND_TOL_IN = 0.05
GLYPH_RUN_GAP_IN = 0.18
GLYPH_MIN_IN_RUN = 25
GLYPH_MIN_RUN_SPAN_IN = 0.60

# legend (paper inches)
LEGEND_TITLE_RE = re.compile(r"\b(LEGEND|SYMBOLS?|KEY)\b", re.I)
LEGEND_HEADING_MAX_CHARS = 34    # "LEGEND", "WALL TYPE LEGEND" - not a paragraph
LEGEND_REGION_W_IN = 6.0
LEGEND_REGION_BACK_IN = 2.2      # labels often start LEFT of the heading
LEGEND_REGION_H_IN = 12.0
LEGEND_ROW_TOL_IN = 0.10
LEGEND_MIN_ROWS = 3
LEGEND_MAX_ROWS = 60
LEGEND_LABEL_MIN_CHARS = 3
LEGEND_LABEL_MAX_CHARS = 42      # longer than this is body copy, not a key label
LEGEND_SYMBOL_MIN_ITEMS = 1
LEGEND_SYMBOL_MIN_W_IN = 0.04    # a symbol cell is a small glyph...
LEGEND_SYMBOL_MAX_W_IN = 1.60    # ...not a whole drawing
LEGEND_SYMBOL_MAX_H_FACTOR = 1.7  # ...and no taller than ~1.7 rows
LEGEND_PITCH_TOL = 0.40          # a row pitch this close to the median "agrees"
LEGEND_PITCH_AGREE_MIN = 0.5     # ...and at least half of them must
LEGEND_TABLE_BREAK_FACTOR = 3.0  # a gap this many pitches wide ends the table
LEGEND_SYMBOL_COL_MIN_IN = 0.08
LEGEND_SYMBOL_COL_MAX_IN = 2.60
LEGEND_COLUMN_GAP_IN = 0.70      # a gap this wide in a row starts a new column
LEGEND_MIN_SYMBOL_ROWS = 3       # rows that actually carry a symbol
SIG_GRID = 8                     # signature raster is SIG_GRID x SIG_GRID cells
SIG_MAX_DIST = 8                 # max differing cells (of 64) for a match
SIG_MIN_CELLS = 3                # a signature with fewer lit cells is too vague
SIG_ASPECT_TOL = 0.30
INSTANCE_SIZE_MIN = 0.55         # instance bbox diagonal / legend symbol diagonal
INSTANCE_SIZE_MAX = 1.90
CLUSTER_GAP_IN = 0.06
CLUSTER_MAX_ITEMS = 60           # a legend symbol is a handful of strokes, not a wing
MAX_CLUSTER_TESTS = 20000        # hard runtime cap on instance matching

# a dimension string: 12'-6", 3'-0", 24", 1/2", 4'-6 1/2", 12.5', bare 6'
DIM_TEXT_RE = re.compile(
    r"""^\s*\(?\s*
        (?:\d+\s*['′]\s*[-–]?\s*)?     # feet part
        (?:\d+(?:\s+\d+/\d+)?|\d+/\d+)?          # inches / fraction
        \s*["″”']?\s*\)?\s*$""",
    re.X)
DIM_TEXT_HAS_DIGIT = re.compile(r"\d")
DIM_TEXT_HAS_MARK = re.compile(r"['′\"″”]|\d+/\d+")
DIM_VALUE_RE = re.compile(
    r"""^\s*\(?\s*
        (?:(?P<ft>\d+)\s*['′]\s*)?
        (?:[-–]?\s*(?P<in>\d+)(?:\s+(?P<n>\d+)/(?P<d>\d+))?
           |[-–]?\s*(?P<n2>\d+)/(?P<d2>\d+))?
        \s*["″”]?\s*\)?\s*$""",
    re.X)

# plot-scale detection from the sheet's own dimension strings
SCALE_MIN = 4.0                  # 3" = 1'-0"
SCALE_MAX = 1200.0               # 1" = 100'
SCALE_MIN_SAMPLES = 6
SCALE_SAMPLE_TOL = 0.25          # a sample must land within 25% of the median
SCALE_AGREE_MIN = 0.55           # ...and most of them must
SCALE_SNAP_TOL = 0.12            # snap to a standard scale within 12%, else reject
# the plot scales an architectural sheet is actually drawn at (real inches per
# paper inch). A measurement that lands on none of these is a bad measurement.
STANDARD_SCALES = (8.0, 12.0, 16.0, 24.0, 32.0, 48.0, 64.0, 96.0, 128.0, 192.0,
                   120.0, 240.0, 360.0, 480.0, 600.0, 720.0)

ROOM_TEXT_RE = re.compile(r"^[A-Z][A-Z0-9 .,'/&()#–-]{2,}$")


# ===========================================================================
# small geometry helpers
# ===========================================================================

def _hypot(ax, ay, bx, by):
    return math.hypot(bx - ax, by - ay)


def _bbox(pts):
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    return min(xs), min(ys), max(xs), max(ys)


def _bbox_of_items(items):
    x0 = y0 = float("inf")
    x1 = y1 = float("-inf")
    for it in items:
        x0 = min(x0, it["x0"]); y0 = min(y0, it["y0"])
        x1 = max(x1, it["x1"]); y1 = max(y1, it["y1"])
    if x0 == float("inf"):
        return None
    return x0, y0, x1, y1


def _diag(box):
    return math.hypot(box[2] - box[0], box[3] - box[1])


def _poly_length(pts):
    return sum(_hypot(pts[i][0], pts[i][1], pts[i + 1][0], pts[i + 1][1])
               for i in range(len(pts) - 1))


def _is_closed(pts, tol=0.01):
    return len(pts) >= 4 and _hypot(pts[0][0], pts[0][1], pts[-1][0], pts[-1][1]) <= tol


def _is_straight(pts, tol=STRAIGHT_TOL_IN):
    """Max perpendicular deviation from the first->last chord is under tol."""
    if len(pts) == 2:
        return True
    ax, ay = pts[0]
    bx, by = pts[-1]
    dx, dy = bx - ax, by - ay
    span = math.hypot(dx, dy)
    if span < SEG_MIN_LEN_IN:
        return False
    for (px, py) in pts[1:-1]:
        if abs((px - ax) * dy - (py - ay) * dx) / span > tol:
            return False
    return True


def _normal_form(ax, ay, bx, by):
    """Infinite line through (a,b) -> (theta in [0,pi), rho) with a stable sign."""
    theta = math.atan2(by - ay, bx - ax) % math.pi
    # unit normal for theta
    nx, ny = -math.sin(theta), math.cos(theta)
    return theta, ax * nx + ay * ny


def _rho_of(theta, x, y):
    return x * -math.sin(theta) + y * math.cos(theta)


def _fit_circle(pts):
    """Kasa algebraic circle fit -> (cx, cy, r, rms_error/r) or None."""
    n = len(pts)
    if n < 4:
        return None
    sx = sy = sxx = syy = sxy = sxz = syz = sz = 0.0
    for (x, y) in pts:
        z = x * x + y * y
        sx += x; sy += y; sz += z
        sxx += x * x; syy += y * y; sxy += x * y
        sxz += x * z; syz += y * z
    a11 = 2 * (n * sxx - sx * sx)
    a12 = 2 * (n * sxy - sx * sy)
    a22 = 2 * (n * syy - sy * sy)
    b1 = n * sxz - sx * sz
    b2 = n * syz - sy * sz
    det = a11 * a22 - a12 * a12
    if abs(det) < 1e-18:
        return None
    cx = (b1 * a22 - b2 * a12) / det
    cy = (a11 * b2 - a12 * b1) / det
    rs = [math.hypot(x - cx, y - cy) for (x, y) in pts]
    r = sum(rs) / n
    if r <= 1e-9:
        return None
    err = math.sqrt(sum((v - r) ** 2 for v in rs) / n) / r
    return cx, cy, r, err


def _turn_degrees(pts):
    """Total absolute turn along the polyline, in degrees."""
    total = 0.0
    for i in range(1, len(pts) - 1):
        ax = pts[i][0] - pts[i - 1][0]; ay = pts[i][1] - pts[i - 1][1]
        bx = pts[i + 1][0] - pts[i][0]; by = pts[i + 1][1] - pts[i][1]
        if (abs(ax) + abs(ay)) < 1e-12 or (abs(bx) + abs(by)) < 1e-12:
            continue
        cross = ax * by - ay * bx
        dot = ax * bx + ay * by
        total += abs(math.degrees(math.atan2(cross, dot)))
    return total


def _boxes_touch(a, b, gap=0.0):
    return not (a[2] + gap < b[0] or b[2] + gap < a[0]
                or a[3] + gap < b[1] or b[3] + gap < a[1])


# ===========================================================================
# straight runs: collinear (incl. dashed) segments chained into one span
# ===========================================================================

class _Run(object):
    """A maximal chain of collinear segments (a solid line, or a dashed one).

    Dashed grid/centre lines arrive as dozens of separate 2-point paths, so the
    only way to notice "this line crosses the whole sheet" is to chain them
    back together for the purpose of classification. The geometry that ends up
    in the DXF is never modified - a run only decides which layer its member
    ITEMS land on."""

    __slots__ = ("theta", "rho", "t0", "t1", "items", "wclass", "ax", "ay", "dx", "dy")

    def __init__(self, theta, rho, t0, t1, items, wclass):
        self.theta = theta
        self.rho = rho
        self.t0 = t0
        self.t1 = t1
        self.items = items
        self.wclass = wclass
        self.dx, self.dy = math.cos(theta), math.sin(theta)
        nx, ny = -math.sin(theta), math.cos(theta)
        self.ax, self.ay = rho * nx, rho * ny

    @property
    def length(self):
        return self.t1 - self.t0

    def point(self, t):
        return (self.ax + self.dx * t, self.ay + self.dy * t)

    @property
    def p0(self):
        return self.point(self.t0)

    @property
    def p1(self):
        return self.point(self.t1)

    def project(self, pt):
        return (pt[0] - self.ax) * self.dx + (pt[1] - self.ay) * self.dy


def _segments_of(item):
    """A line/fill item -> its straight segments as (p_a, p_b) pairs."""
    pts = item["pts"]
    if len(pts) < 2:
        return []
    if _is_straight(pts):
        return [(pts[0], pts[-1])]
    if len(pts) > MAX_POLY_PTS_FOR_SEGS:
        return []
    out = []
    for i in range(len(pts) - 1):
        a, b = pts[i], pts[i + 1]
        if _hypot(a[0], a[1], b[0], b[1]) >= SEG_MIN_LEN_IN:
            out.append((a, b))
    return out


def _build_runs(items):
    """Collinear-chain every straight segment of every item into runs."""
    buckets = defaultdict(list)
    aq = math.radians(ANGLE_QUANT_DEG)
    for it in items:
        for (a, b) in _segments_of(it):
            if _hypot(a[0], a[1], b[0], b[1]) < SEG_MIN_LEN_IN:
                continue
            theta, rho = _normal_form(a[0], a[1], b[0], b[1])
            buckets[(int(theta / aq), int(round(rho / RHO_QUANT_IN)))].append((theta, rho, a, b, it))

    runs = []
    seen = set()
    ang_tol = math.radians(ANGLE_TOL_DEG)
    max_ang_bucket = int(math.pi / aq) + 1
    for key, members in buckets.items():
        if key in seen:
            continue
        # pull in the neighbouring offset buckets so a run split across a
        # quantisation edge still chains (angle wraps at pi).
        pool = []
        for da in (-1, 0, 1):
            ab = (key[0] + da) % max_ang_bucket
            for dr in (-1, 0, 1):
                nk = (ab, key[1] + dr)
                if nk in buckets and nk not in seen:
                    pool += buckets[nk]
                    seen.add(nk)
        if not pool:
            continue
        # regroup the pool into true collinear sets (bucket edges are coarse)
        groups = []
        for (theta, rho, a, b, it) in pool:
            placed = False
            for g in groups:
                dth = abs(theta - g["theta"])
                dth = min(dth, math.pi - dth)
                if dth <= ang_tol and abs(rho - g["rho"]) <= COLLINEAR_RHO_TOL_IN:
                    g["m"].append((a, b, it))
                    placed = True
                    break
            if not placed:
                groups.append({"theta": theta, "rho": rho, "m": [(a, b, it)]})
        for g in groups:
            runs += _chain_group(g["theta"], g["rho"], g["m"])
    return runs


def _chain_group(theta, rho, members):
    """Sort one collinear set along its direction and cut it at big gaps."""
    dx, dy = math.cos(theta), math.sin(theta)
    nx, ny = -math.sin(theta), math.cos(theta)
    ax, ay = rho * nx, rho * ny
    spans = []
    for (a, b, it) in members:
        ta = (a[0] - ax) * dx + (a[1] - ay) * dy
        tb = (b[0] - ax) * dx + (b[1] - ay) * dy
        spans.append((min(ta, tb), max(ta, tb), it))
    spans.sort(key=lambda s: (s[0], s[1]))
    out = []
    cur_t0, cur_t1, cur_items = spans[0][0], spans[0][1], [spans[0][2]]
    for (t0, t1, it) in spans[1:]:
        if t0 - cur_t1 <= DASH_GAP_MAX_IN:
            cur_t1 = max(cur_t1, t1)
            cur_items.append(it)
        else:
            out.append(_Run(theta, rho, cur_t0, cur_t1, cur_items, _dom_wclass(cur_items)))
            cur_t0, cur_t1, cur_items = t0, t1, [it]
    out.append(_Run(theta, rho, cur_t0, cur_t1, cur_items, _dom_wclass(cur_items)))
    return out


def _dom_wclass(items):
    votes = Counter(it.get("wclass") or "med" for it in items)
    return votes.most_common(1)[0][0]


# ===========================================================================
# shape signatures (legend matching)
# ===========================================================================

def shape_signature(polys, grid=SIG_GRID):
    """Normalised raster fingerprint of a symbol: translate to the origin,
    scale the long side to 1 (aspect preserved, centred), quantise onto a
    grid x grid raster. Returns (bits, aspect, diag) or None."""
    pts_all = [p for poly in polys for p in poly]
    if len(pts_all) < 2:
        return None
    xs = [p[0] for p in pts_all]
    ys = [p[1] for p in pts_all]
    x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
    w, h = x1 - x0, y1 - y0
    span = max(w, h)
    if span <= 1e-9:
        return None
    ox = (span - w) / 2.0
    oy = (span - h) / 2.0
    cells = set()
    step = span / (grid * 2.0)

    def mark(px, py):
        cx = int((px - x0 + ox) / span * grid)
        cy = int((py - y0 + oy) / span * grid)
        cells.add((min(grid - 1, max(0, cy)), min(grid - 1, max(0, cx))))

    for poly in polys:
        for i in range(len(poly) - 1):
            ax, ay = poly[i]
            bx, by = poly[i + 1]
            n = max(1, int(math.hypot(bx - ax, by - ay) / step))
            n = min(n, grid * 4)
            for k in range(n + 1):
                t = k / float(n)
                mark(ax + (bx - ax) * t, ay + (by - ay) * t)
        if len(poly) == 1:
            mark(poly[0][0], poly[0][1])
    if len(cells) < SIG_MIN_CELLS:
        return None
    bits = 0
    for (r, c) in cells:
        bits |= 1 << (r * grid + c)
    aspect = (w / h) if h > 1e-9 else 999.0
    return bits, aspect, math.hypot(w, h)


def _grid_variants(bits, grid=SIG_GRID):
    """The 8 dihedral variants of a signature raster (4 rotations x mirror)."""
    base = [(r, c) for r in range(grid) for c in range(grid)
            if bits >> (r * grid + c) & 1]
    g = grid - 1
    maps = (
        lambda r, c: (r, c),
        lambda r, c: (c, g - r),
        lambda r, c: (g - r, g - c),
        lambda r, c: (g - c, r),
        lambda r, c: (r, g - c),
        lambda r, c: (g - r, c),
        lambda r, c: (c, r),
        lambda r, c: (g - c, g - r),
    )
    out = []
    for m in maps:
        v = 0
        for (r, c) in base:
            rr, cc = m(r, c)
            v |= 1 << (rr * grid + cc)
        out.append(v)
    return out


def signature_matches(a, b, max_dist=SIG_MAX_DIST):
    """True when signature b is signature a under some rotation/mirror."""
    if a is None or b is None:
        return False
    a_bits, a_aspect, _ = a
    b_bits, b_aspect, _ = b
    ok_aspect = False
    for cand in (b_aspect, (1.0 / b_aspect) if b_aspect > 1e-9 else 999.0):
        lo, hi = min(a_aspect, cand), max(a_aspect, cand)
        if lo > 1e-9 and (hi / lo) - 1.0 <= SIG_ASPECT_TOL:
            ok_aspect = True
            break
    if not ok_aspect:
        return False
    best = min(bin(a_bits ^ v).count("1") for v in _grid_variants(b_bits))
    return best <= max_dist


# ===========================================================================
# DXF layer names
# ===========================================================================

def sanitize_layer_name(text, prefix=LEGEND_PREFIX, used=None, limit=31):
    """Legend label -> a valid, unique R12 layer name (<= 31 chars).

    '1 HR. RATED WALL' -> 'L-1-HR-RATED-WALL'
    """
    body = re.sub(r"[^A-Za-z0-9]+", "-", (text or "")).strip("-").upper()
    body = re.sub(r"-{2,}", "-", body)
    if not body:
        body = "SYMBOL"
    name = (prefix + body)[:limit].rstrip("-")
    if used is None:
        return name
    candidate, i = name, 2
    while candidate in used:
        suffix = "-%d" % i
        candidate = (name[:limit - len(suffix)]).rstrip("-") + suffix
        i += 1
    used.add(candidate)
    return candidate


# ===========================================================================
# the classifier
# ===========================================================================

class _Sheet(object):
    """Working state for one page: the items, their indexes, and the running
    assignment (ref -> layer, confidence)."""

    def __init__(self, items, page_w, page_h, scale):
        self.items = items
        self.page_w = float(page_w or 0) or 1.0
        self.page_h = float(page_h or 0) or 1.0
        self.scale = float(scale or 96.0) or 96.0
        self.given_scale = self.scale
        self.scale_samples = []          # (paper inches, real inches) from dim strings
        self.assign = {}
        self.conf = {}
        self.lines = [it for it in items if it["kind"] == "line"]
        self.fills = [it for it in items if it["kind"] == "fill"]
        self.texts = [it for it in items if it["kind"] == "text"]
        self.geom = self.lines + self.fills
        self.reset_extent()

    def reset_extent(self):
        """Bounding box of the geometry that is still unclaimed (so the drawing
        extents mean the PLAN, not the sheet border)."""
        box = (_bbox_of_items([it for it in self.geom if self.free(it)])
               or _bbox_of_items(self.geom)
               or (0.0, 0.0, self.page_w, self.page_h))
        self.extent = box
        self.extent_span = max(box[2] - box[0], box[3] - box[1]) or 1.0

    # -- units ------------------------------------------------------------
    def paper(self, real_inches):
        """Real-world inches -> paper inches at this sheet's scale."""
        return real_inches / self.scale

    # -- assignment -------------------------------------------------------
    def take(self, item, layer, confidence):
        ref = item["ref"]
        if ref in self.assign:
            return False
        self.assign[ref] = layer
        self.conf[ref] = confidence
        return True

    def free(self, item):
        return item["ref"] not in self.assign

    def free_items(self, pool=None):
        return [it for it in (pool if pool is not None else self.items) if self.free(it)]


def classify(items, page_width_in, page_height_in, scale=96.0, read_legend=True):
    """Assign every item a semantic layer.

    ``items`` are the plain dicts produced by ``pdf_to_cad._smart_items``.
    Returns {"assign": {ref: {"layer", "confidence"}}, "layers": [...],
    "stats": {...}}.  Layers are returned in a stable, sensible picker order:
    legend layers first (they are the sheet's own vocabulary), then the A-*
    layers in LAYER_ORDER.
    """
    sheet = _Sheet(items, page_width_in, page_height_in, scale)
    stats = {"walls": 0, "doors": 0, "windows": 0, "columns": 0, "gridLines": 0,
             "dimStrings": 0, "legendRows": 0, "legendMatched": 0, "legendInstances": 0}

    _pass_hatch(sheet)
    legend_layers = _pass_legend(sheet, stats) if read_legend else []
    runs = _build_runs(sheet.free_items(sheet.lines))
    _pass_title_block(sheet, runs)
    # the border and title block ARE most of the page; "how big is the drawing"
    # only means something once they are out of the way
    sheet.reset_extent()
    _pass_grid(sheet, runs, stats)
    _pass_dimensions(sheet, runs, stats)
    # The dimension strings just measured the sheet for us. Trust that over the
    # scale the user happened to have selected: every wall / door / column test
    # below is a real-world size, and at the wrong scale they all miss.
    detected, samples = _estimate_scale(sheet.scale_samples)
    stats["scaleGiven"] = round(sheet.given_scale, 2)
    stats["scaleDetected"] = round(detected, 2) if detected else None
    stats["scaleSamples"] = samples
    if detected:
        sheet.scale = detected
    _pass_doors(sheet, stats)
    # Hatch fields go BEFORE walls on purpose: a tight bundle of evenly spaced
    # strokes would otherwise pair up as a stack of very thin walls.
    _pass_hatch_field(sheet, runs)
    wall_runs = _pass_walls(sheet, runs, stats)
    _pass_windows(sheet, runs, wall_runs, stats)
    _pass_columns(sheet, stats)
    _pass_rooms(sheet)
    _pass_annotation(sheet)
    _pass_furniture(sheet)
    _pass_outlined_text(sheet)
    _pass_fills(sheet)
    _pass_misc(sheet)

    counts = Counter()
    conf_sum = defaultdict(float)
    for ref, layer in sheet.assign.items():
        counts[layer] += 1
        conf_sum[layer] += sheet.conf.get(ref, 0.0)

    layers = []
    for name, label, default_on, hint in legend_layers:
        layers.append(_layer_row(name, label, default_on, hint, counts, conf_sum, "legend"))
    for name in LAYER_ORDER:
        if counts.get(name):
            label, default_on, hint = LAYER_INFO[name]
            layers.append(_layer_row(name, label, default_on, hint, counts, conf_sum, "semantic"))

    total_geom = len(sheet.geom)
    misc_geom = sum(1 for it in sheet.geom if sheet.assign.get(it["ref"]) == "A-MISC")
    stats["miscPercent"] = round(100.0 * misc_geom / total_geom, 1) if total_geom else 0.0
    # A stipple field can be 80% of the objects on a sheet and is always
    # classified, which flatters the headline number - so report the share of
    # the linework a designer actually cares about too.
    real = [it for it in sheet.geom if sheet.assign.get(it["ref"]) != "A-HATCH"]
    misc_real = sum(1 for it in real if sheet.assign.get(it["ref"]) == "A-MISC")
    stats["miscPercentDrawing"] = round(100.0 * misc_real / len(real), 1) if real else 0.0
    stats["items"] = len(items)

    return {
        "assign": {ref: {"layer": layer, "confidence": round(sheet.conf.get(ref, 0.0), 3)}
                   for ref, layer in sheet.assign.items()},
        "layers": layers,
        "stats": stats,
    }


def _layer_row(name, label, default_on, hint, counts, conf_sum, kind):
    count = counts.get(name, 0)
    mean = (conf_sum.get(name, 0.0) / count) if count else 0.0
    return {"name": name, "label": label, "kind": kind, "count": count,
            "confidence": round(mean, 3), "defaultOn": bool(default_on), "hint": hint}


# --- pass 0: hatch ----------------------------------------------------------

def _pass_hatch(sheet):
    """Stipple crowds were already spotted upstream (pdf_to_cad._tag_hatch)."""
    for it in sheet.items:
        if it.get("wclass") == "hatch":
            sheet.take(it, "A-HATCH", 0.85)


# --- pass 1: legend ---------------------------------------------------------

def _pass_legend(sheet, stats):
    """Read the sheet's LEGEND/SYMBOLS table and match its symbols elsewhere."""
    rows = _legend_rows(sheet)
    stats["legendRows"] = len(rows)
    if not rows:
        return []

    used = set()
    out = []
    # Index the free small geometry once, then match each legend row against it.
    # The legend's OWN symbols are excluded - they are the key, not instances of
    # it, and without this the first row claims every other row's glyph.
    own = {id(it) for row in rows for it in row["items"]}
    clusters = _small_clusters(sheet, rows, own)
    tests = 0
    for row in rows:
        name = sanitize_layer_name(row["label"], used=used)
        sig = row["sig"]
        instances = []
        if sig is not None:
            for cl in clusters:
                if tests > MAX_CLUSTER_TESTS:
                    break
                if cl["taken"]:
                    continue
                ratio = cl["diag"] / sig[2] if sig[2] > 1e-9 else 0.0
                if not (INSTANCE_SIZE_MIN <= ratio <= INSTANCE_SIZE_MAX):
                    continue
                tests += 1
                if signature_matches(sig, cl["sig"]):
                    cl["taken"] = True
                    instances.append(cl)
        for it in row["items"]:
            sheet.take(it, name, 0.9)
        if row["text_item"] is not None:
            sheet.take(row["text_item"], name, 0.9)
        for cl in instances:
            for it in cl["items"]:
                sheet.take(it, name, 0.7)
        stats["legendInstances"] += sum(len(cl["items"]) for cl in instances)
        if instances:
            stats["legendMatched"] += 1
        out.append((name, row["label"][:60], True,
                    "From this sheet's legend - %d instance%s found."
                    % (len(instances), "" if len(instances) == 1 else "s")))
    return out


def _legend_rows(sheet):
    """Locate the legend heading, then split the table under it into rows of
    (symbol geometry at the left, label text at the right)."""
    headings = [t for t in sheet.texts
                if LEGEND_TITLE_RE.search(t["text"] or "")
                and len((t["text"] or "").strip()) <= LEGEND_HEADING_MAX_CHARS]
    best = None
    for head in headings:
        rows = _rows_under(sheet, head)
        if len(rows) >= LEGEND_MIN_SYMBOL_ROWS and (best is None or len(rows) > len(best)):
            best = rows
    return best or []


def _rows_under(sheet, head):
    region = (head["x0"] - LEGEND_REGION_BACK_IN, head["y0"] - LEGEND_REGION_H_IN,
              head["x0"] + LEGEND_REGION_W_IN, head["y0"] - 0.02)
    texts = [t for t in sheet.texts
             if region[0] <= (t["x0"] + t["x1"]) / 2 <= region[2]
             and region[1] <= (t["y0"] + t["y1"]) / 2 <= region[3]
             and sheet.free(t)]
    if len(texts) < LEGEND_MIN_ROWS:
        return []
    texts.sort(key=lambda t: -(t["y0"] + t["y1"]) / 2)
    # group by y into rows
    bands = []
    for t in texts:
        yc = (t["y0"] + t["y1"]) / 2
        if bands and abs(bands[-1]["yc"] - yc) <= LEGEND_ROW_TOL_IN:
            bands[-1]["texts"].append(t)
            bands[-1]["yc"] = (bands[-1]["yc"] + yc) / 2
        else:
            bands.append({"yc": yc, "texts": [t]})
    bands = bands[:LEGEND_MAX_ROWS]
    if len(bands) < LEGEND_MIN_ROWS:
        return []
    pitches = [abs(bands[i]["yc"] - bands[i + 1]["yc"]) for i in range(len(bands) - 1)]
    pitch = _median(pitches) if pitches else LEGEND_ROW_TOL_IN * 3
    if pitch <= 1e-6:
        return []
    # The table ends where the line spacing suddenly breaks - otherwise the next
    # unrelated block of text under the legend gets swept in as extra "rows".
    cut = len(bands)
    for i, gap in enumerate(pitches):
        if gap > max(pitch * LEGEND_TABLE_BREAK_FACTOR, 0.5):
            cut = i + 1
            break
    bands = bands[:cut]
    if len(bands) < LEGEND_MIN_ROWS:
        return []
    pitches = [abs(bands[i]["yc"] - bands[i + 1]["yc"]) for i in range(len(bands) - 1)]
    pitch = _median(pitches) or pitch
    agree = sum(1 for p in pitches if abs(p - pitch) <= pitch * LEGEND_PITCH_TOL)
    if pitches and agree / float(len(pitches)) < LEGEND_PITCH_AGREE_MIN:
        return []          # ragged line spacing: a paragraph, not a legend table

    # Symbols usually sit to the LEFT of their label, but plenty of legends
    # (Revit "graphic symbols" sheets in particular) put them on the right - try
    # both and keep whichever actually yields a table.
    best = []
    for side in ("left", "right"):
        rows = _rows_for_side(sheet, region, bands, pitch, side)
        if len(rows) > len(best):
            best = rows
    return best if len(best) >= LEGEND_MIN_SYMBOL_ROWS else []


def _text_columns(texts):
    """Split one row's text into columns at big horizontal gaps.

    Plenty of legends run two or three symbol/label pairs across a row; without
    this the labels of every column get glued into one nonsense layer name."""
    ordered = sorted(texts, key=lambda t: t["x0"])
    groups = [[ordered[0]]]
    for t in ordered[1:]:
        if t["x0"] - groups[-1][-1]["x1"] > LEGEND_COLUMN_GAP_IN:
            groups.append([t])
        else:
            groups[-1].append(t)
    return groups


def _rows_for_side(sheet, region, bands, pitch, side):
    half = max(pitch * 0.48, LEGEND_ROW_TOL_IN)
    rows = []
    for band in bands:
        columns = _text_columns(band["texts"])
        for k, group in enumerate(columns):
            label = " ".join(" ".join(t["text"].split()) for t in group).strip()
            letters = len(re.sub(r"[^A-Za-z0-9]", "", label))
            if letters < LEGEND_LABEL_MIN_CHARS or len(label) > LEGEND_LABEL_MAX_CHARS:
                continue
            if LEGEND_TITLE_RE.fullmatch(label.strip()):
                continue
            if side == "left":
                left = region[0] if k == 0 else columns[k - 1][-1]["x1"] + 0.02
                sym_col = (left, group[0]["x0"] - 0.02)
            else:
                right = region[2] if k == len(columns) - 1 else columns[k + 1][0]["x0"] - 0.02
                sym_col = (group[-1]["x1"] + 0.02, right)
            width = sym_col[1] - sym_col[0]
            if not (LEGEND_SYMBOL_COL_MIN_IN <= width <= LEGEND_SYMBOL_COL_MAX_IN):
                continue
            y_lo, y_hi = band["yc"] - half, band["yc"] + half
            sym = [it for it in sheet.geom
                   if sheet.free(it)
                   and sym_col[0] <= (it["x0"] + it["x1"]) / 2 <= sym_col[1]
                   and it["x0"] >= sym_col[0] - LEGEND_ROW_TOL_IN
                   and it["x1"] <= sym_col[1] + LEGEND_ROW_TOL_IN
                   and y_lo <= (it["y0"] + it["y1"]) / 2 <= y_hi]
            if len(sym) < LEGEND_SYMBOL_MIN_ITEMS:
                continue
            box = _bbox_of_items(sym)
            if box is None:
                continue
            w, h = box[2] - box[0], box[3] - box[1]
            if not (LEGEND_SYMBOL_MIN_W_IN <= max(w, h) <= LEGEND_SYMBOL_MAX_W_IN):
                continue
            if h > pitch * LEGEND_SYMBOL_MAX_H_FACTOR:
                continue
            sig = shape_signature([it["pts"] for it in sym])
            rows.append({"label": label, "items": sym, "sig": sig, "text_item": group[0]})
    return rows


def _median(values):
    if not values:
        return 0.0
    vs = sorted(values)
    n = len(vs)
    return vs[n // 2] if n % 2 else (vs[n // 2 - 1] + vs[n // 2]) / 2.0


def _small_clusters(sheet, rows, exclude=()):
    """Connected components of small free geometry - candidate symbol instances.

    Only shapes that could plausibly BE one of the legend symbols are clustered,
    which is what keeps this affordable on a dense sheet."""
    diags = [r["sig"][2] for r in rows if r["sig"]]
    if not diags:
        return []
    max_diag = max(diags) * INSTANCE_SIZE_MAX
    pool = [it for it in sheet.geom
            if sheet.free(it) and id(it) not in exclude
            and _diag((it["x0"], it["y0"], it["x1"], it["y1"])) <= max_diag]
    if not pool:
        return []
    parent = list(range(len(pool)))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    def union(i, j):
        ri, rj = find(i), find(j)
        if ri != rj:
            parent[rj] = ri

    cell = CLUSTER_GAP_IN
    grid = defaultdict(list)
    for idx, it in enumerate(pool):
        c0 = int(math.floor(it["x0"] / cell)); c1 = int(math.floor(it["x1"] / cell))
        r0 = int(math.floor(it["y0"] / cell)); r1 = int(math.floor(it["y1"] / cell))
        if (c1 - c0 + 1) * (r1 - r0 + 1) > 400:
            continue                       # pathological: skip, it is not a symbol
        for c in range(c0, c1 + 1):
            for r in range(r0, r1 + 1):
                key = (c, r)
                for other in grid[key]:
                    union(idx, other)
                grid[key].append(idx)

    groups = defaultdict(list)
    for idx in range(len(pool)):
        groups[find(idx)].append(pool[idx])

    clusters = []
    for members in groups.values():
        if len(members) > CLUSTER_MAX_ITEMS:
            continue
        box = _bbox_of_items(members)
        if box is None:
            continue
        d = _diag(box)
        if d <= 1e-6 or d > max_diag:
            continue
        sig = shape_signature([m["pts"] for m in members])
        if sig is None:
            continue
        clusters.append({"items": members, "sig": sig, "diag": d, "taken": False})
    return clusters


# --- pass 2: title block ----------------------------------------------------

def _pass_title_block(sheet, runs):
    border = _border_box(sheet, runs)
    if border is None:
        return
    bx0, by0, bx1, by1 = border
    bw, bh = bx1 - bx0, by1 - by0
    if bw <= 0 or bh <= 0:
        return

    strip_x = None
    band_y = None
    for run in runs:
        if run.length < bh * TITLE_LONG_RUN_FRACTION:
            continue
        if abs(math.sin(run.theta)) > 0.98:      # vertical
            x = run.p0[0]
            if bx0 + bw * 0.55 < x < bx1 - TITLE_STRIP_MIN_IN * 0.4:
                width = bx1 - x
                if TITLE_STRIP_MIN_IN <= width <= bw * TITLE_STRIP_MAX_FRACTION:
                    strip_x = x if strip_x is None else min(strip_x, x)
    for run in runs:
        if run.length < bw * TITLE_LONG_RUN_FRACTION:
            continue
        if abs(math.sin(run.theta)) < 0.02:      # horizontal
            y = run.p0[1]
            if by0 + TITLE_BAND_MIN_IN * 0.4 < y < by0 + bh * 0.45:
                height = y - by0
                if TITLE_BAND_MIN_IN <= height <= bh * TITLE_BAND_MAX_FRACTION:
                    band_y = y if band_y is None else max(band_y, y)

    def in_title(it):
        cx = (it["x0"] + it["x1"]) / 2
        cy = (it["y0"] + it["y1"]) / 2
        if cx < bx0 - 0.02 or cx > bx1 + 0.02 or cy < by0 - 0.02 or cy > by1 + 0.02:
            return True                      # outside the frame: margin junk
        if strip_x is not None and cx >= strip_x:
            return True
        if band_y is not None and cy <= band_y:
            return True
        return False

    for it in sheet.items:
        if sheet.free(it) and in_title(it):
            sheet.take(it, "A-TITLE", 0.8)
    # the frame itself
    for run in runs:
        if run.length >= min(bw, bh) * TITLE_LONG_RUN_FRACTION:
            near_edge = (min(abs(run.p0[0] - bx0), abs(run.p0[0] - bx1)) < 0.12
                         or min(abs(run.p0[1] - by0), abs(run.p0[1] - by1)) < 0.12)
            if near_edge:
                for it in run.items:
                    sheet.take(it, "A-TITLE", 0.75)


def _border_box(sheet, runs):
    """The sheet border: the outermost rectangle covering >85% of the page."""
    page_area = sheet.page_w * sheet.page_h
    best = None
    for it in sheet.geom:
        w = it["x1"] - it["x0"]
        h = it["y1"] - it["y0"]
        if w * h >= page_area * TITLE_BORDER_AREA_FRACTION and w * h <= page_area * 1.02:
            if best is None or w * h > (best[2] - best[0]) * (best[3] - best[1]):
                best = (it["x0"], it["y0"], it["x1"], it["y1"])
    if best is not None:
        return best
    # No single frame path - rebuild it from the long runs near the page edges.
    xs, ys = [], []
    for run in runs:
        if abs(math.sin(run.theta)) > 0.98 and run.length >= sheet.page_h * TITLE_LONG_RUN_FRACTION:
            xs.append(run.p0[0])
        elif abs(math.sin(run.theta)) < 0.02 and run.length >= sheet.page_w * TITLE_LONG_RUN_FRACTION:
            ys.append(run.p0[1])
    if len(xs) >= 2 and len(ys) >= 2:
        box = (min(xs), min(ys), max(xs), max(ys))
        if (box[2] - box[0]) * (box[3] - box[1]) >= page_area * TITLE_BORDER_AREA_FRACTION:
            return box
    return None


# --- pass 3: column grid ----------------------------------------------------

def _pass_grid(sheet, runs, stats):
    bubbles = _grid_bubbles(sheet)
    if not bubbles:
        return
    min_span = sheet.extent_span * GRID_SPAN_FRACTION
    for run in runs:
        if run.length < min_span:
            continue
        if not any(sheet.free(it) for it in run.items):
            continue
        # A grid line usually stops SHORT of its bubble, so "touches the bubble"
        # means: the bubble sits on the line's axis, just off one of its ends.
        hit = None
        for b in bubbles:
            if abs(run.rho - _rho_of(run.theta, b["cx"], b["cy"])) > b["r"] * GRID_END_TOL_FACTOR:
                continue
            t = run.project((b["cx"], b["cy"]))
            if (run.t0 - GRID_BUBBLE_REACH_IN <= t <= run.t0 + b["r"]
                    or run.t1 - b["r"] <= t <= run.t1 + GRID_BUBBLE_REACH_IN):
                hit = b
                break
        if not hit:
            continue
        stats["gridLines"] += 1
        for it in run.items:
            sheet.take(it, "A-GRID", 0.85)
        hit["used"] = True
    # A bubble no grid line reached is still a callout, not a column - the two
    # are the same size on paper, so leaving it unclaimed poisons A-COLS.
    for b in bubbles:
        used = b.get("used")
        for it in b["items"]:
            sheet.take(it, "A-GRID" if used else "A-ANNO", 0.85 if used else 0.5)


def _grid_bubbles(sheet):
    """Small circles holding 1-3 characters of text - grid callouts."""
    out = []
    for it in sheet.geom:
        if not sheet.free(it):
            continue
        pts = it["pts"]
        if len(pts) < 5:
            continue
        w = it["x1"] - it["x0"]
        h = it["y1"] - it["y0"]
        d = max(w, h)
        if not (GRID_BUBBLE_MIN_D_IN <= d <= GRID_BUBBLE_MAX_D_IN):
            continue
        if min(w, h) <= 1e-9 or max(w / h, h / w) > 1.25:
            continue
        fit = _fit_circle(pts)
        if fit is None or fit[3] > GRID_BUBBLE_ROUND_TOL:
            continue
        cx, cy, r = fit[0], fit[1], fit[2]
        inside = [t for t in sheet.texts
                  if sheet.free(t)
                  and _hypot((t["x0"] + t["x1"]) / 2, (t["y0"] + t["y1"]) / 2, cx, cy) <= r]
        chars = sum(len(t["text"].strip()) for t in inside)
        if not inside or chars > GRID_BUBBLE_MAX_CHARS:
            continue
        out.append({"cx": cx, "cy": cy, "r": r, "items": [it] + inside})
    return out


# --- pass 4: dimensions -----------------------------------------------------

def _is_dimension_text(text):
    t = (text or "").strip()
    if not t or len(t) > DIM_TEXT_MAX_CHARS:
        return False
    if not DIM_TEXT_HAS_DIGIT.search(t):
        return False
    if not DIM_TEXT_HAS_MARK.search(t):
        return False
    return bool(DIM_TEXT_RE.match(t))


def parse_dimension_inches(text):
    """'12'-6"' -> 150.0 real inches. None when it is not a dimension."""
    t = " ".join((text or "").split())
    if not t or not _is_dimension_text(t):
        return None
    m = DIM_VALUE_RE.match(t)
    if not m:
        return None
    total = 0.0
    seen = False
    if m.group("ft"):
        total += float(m.group("ft")) * 12.0
        seen = True
    if m.group("in"):
        total += float(m.group("in"))
        seen = True
    if m.group("n") and m.group("d"):
        total += float(m.group("n")) / float(m.group("d"))
        seen = True
    if m.group("n2") and m.group("d2"):
        total += float(m.group("n2")) / float(m.group("d2"))
        seen = True
    return total if (seen and total > 0) else None


def _estimate_scale(samples):
    """(paper inches, real inches) pairs -> real inches per paper inch.

    The sheet tells you its own scale: every dimension string is the real
    length of the line it labels, so the ratio of the two IS the plot scale.
    Median first (kills the mislabelled outliers), then a trimmed mean of the
    samples that agree with it."""
    ratios = [real / paper for (paper, real) in samples
              if paper > 1e-6 and SCALE_MIN <= real / paper <= SCALE_MAX]
    if len(ratios) < SCALE_MIN_SAMPLES:
        return None, 0
    med = _median(ratios)
    keep = [r for r in ratios if abs(r - med) <= med * SCALE_SAMPLE_TOL]
    if len(keep) < SCALE_MIN_SAMPLES or len(keep) / float(len(ratios)) < SCALE_AGREE_MIN:
        return None, len(keep)
    mean = sum(keep) / len(keep)
    # Sheets are plotted at standard scales. Landing between two of them means
    # the measurement is wrong (a dimension matched to the wrong line), and a
    # wrong scale is worse than the one the user already chose.
    snap = min(STANDARD_SCALES, key=lambda s: abs(s - mean))
    if abs(snap - mean) / snap > SCALE_SNAP_TOL:
        return None, len(keep)
    return snap, len(keep)


def _pass_dimensions(sheet, runs, stats):
    dim_texts = [t for t in sheet.texts if sheet.free(t) and _is_dimension_text(t["text"])]
    if not dim_texts:
        return
    # short strokes are tick / arrowhead candidates
    ticks = [it for it in sheet.geom
             if sheet.free(it) and _diag((it["x0"], it["y0"], it["x1"], it["y1"])) <= DIM_TICK_MAX_IN]
    tick_grid = defaultdict(list)
    for it in ticks:
        key = (int(((it["x0"] + it["x1"]) / 2) / DIM_TICK_MAX_IN),
               int(((it["y0"] + it["y1"]) / 2) / DIM_TICK_MAX_IN))
        tick_grid[key].append(it)

    long_runs = [r for r in runs if r.length >= DIM_LINE_MIN_IN]
    run_grid = defaultdict(list)
    for r in long_runs:
        for pt in (r.p0, r.point((r.t0 + r.t1) / 2), r.p1):
            run_grid[(int(pt[0] / DIM_TEXT_GAP_IN), int(pt[1] / DIM_TEXT_GAP_IN))].append(r)

    for t in dim_texts:
        tx = (t["x0"] + t["x1"]) / 2
        ty = (t["y0"] + t["y1"]) / 2
        cand = []
        gx, gy = int(tx / DIM_TEXT_GAP_IN), int(ty / DIM_TEXT_GAP_IN)
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                cand += run_grid.get((gx + dx, gy + dy), ())
        best, best_d = None, DIM_TEXT_GAP_IN * 1.6
        for r in cand:
            if not all(sheet.free(it) for it in r.items):
                continue
            proj = max(r.t0, min(r.t1, r.project((tx, ty))))
            px, py = r.point(proj)
            d = _hypot(tx, ty, px, py)
            if d < best_d:
                best, best_d = r, d
        if best is None:
            continue
        found_ticks = []
        ends_with_tick = 0
        for end in (best.p0, best.p1):
            before = len(found_ticks)
            key = (int(end[0] / DIM_TICK_MAX_IN), int(end[1] / DIM_TICK_MAX_IN))
            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    for it in tick_grid.get((key[0] + dx, key[1] + dy), ()):
                        if not sheet.free(it):
                            continue
                        mx = (it["x0"] + it["x1"]) / 2
                        my = (it["y0"] + it["y1"]) / 2
                        if _hypot(mx, my, end[0], end[1]) <= DIM_TICK_NEAR_IN:
                            found_ticks.append(it)
            if len(found_ticks) > before:
                ends_with_tick += 1
        conf = 0.8 if found_ticks else 0.5
        stats["dimStrings"] += 1
        # only a dimension line ticked at BOTH ends measures its own length, so
        # only those are trusted to report the plot scale
        if ends_with_tick == 2:
            real = parse_dimension_inches(t["text"])
            if real:
                sheet.scale_samples.append((best.length, real))
        sheet.take(t, "A-DIMS", conf)
        for it in best.items:
            sheet.take(it, "A-DIMS", conf)
        for it in found_ticks:
            sheet.take(it, "A-DIMS", conf)
        if found_ticks:
            _take_extension_lines(sheet, runs, best)


def _take_extension_lines(sheet, runs, dim_run):
    """The two short witness lines that run from the object to the dim line."""
    for end in (dim_run.p0, dim_run.p1):
        for r in runs:
            if r is dim_run or r.length > DIM_EXT_MAX_IN:
                continue
            if not all(sheet.free(it) for it in r.items):
                continue
            dth = abs(r.theta - dim_run.theta)
            dth = min(dth, math.pi - dth)
            if dth < math.radians(60):
                continue                      # not roughly perpendicular
            near = min(_hypot(r.p0[0], r.p0[1], end[0], end[1]),
                       _hypot(r.p1[0], r.p1[1], end[0], end[1]))
            if near <= DIM_TICK_NEAR_IN * 2:
                for it in r.items:
                    sheet.take(it, "A-DIMS", 0.7)


# --- pass 5: doors ----------------------------------------------------------

def _smooth_parts(pts, corner_deg=38.0):
    """Split a polyline at sharp corners into smooth pieces.

    A door swing is very often ONE path: arc, then the leaf, then back to the
    hinge. Testing the whole path as an arc fails (its total turn is ~180 deg),
    so it has to be cut at the corners first."""
    parts = []
    cur = [pts[0]]
    for i in range(1, len(pts) - 1):
        cur.append(pts[i])
        ax = pts[i][0] - pts[i - 1][0]; ay = pts[i][1] - pts[i - 1][1]
        bx = pts[i + 1][0] - pts[i][0]; by = pts[i + 1][1] - pts[i][1]
        if (abs(ax) + abs(ay)) < 1e-12 or (abs(bx) + abs(by)) < 1e-12:
            continue
        turn = abs(math.degrees(math.atan2(ax * by - ay * bx, ax * bx + ay * by)))
        if turn >= corner_deg:
            parts.append(cur)
            cur = [pts[i]]
    cur.append(pts[-1])
    parts.append(cur)
    return [p for p in parts if len(p) >= 2]


def _arc_in(pts, r_min, r_max):
    """The first arc-shaped piece of this polyline -> (part, radius) or None."""
    parts = _smooth_parts(pts) if len(pts) <= MAX_POLY_PTS_FOR_SEGS else [pts]
    for part in parts:
        if len(part) < 5:
            continue
        turn = _turn_degrees(part)
        if not (DOOR_ARC_MIN_TURN_DEG <= turn <= DOOR_ARC_MAX_TURN_DEG):
            continue
        fit = _fit_circle(part)
        if fit is None:
            continue
        _cx, _cy, r, err = fit
        if err > DOOR_RADIUS_VAR_MAX or not (r_min <= r <= r_max):
            continue
        return part, r, parts
    return None


def _pass_doors(sheet, stats):
    r_min = sheet.paper(DOOR_MIN_R_IN)
    r_max = sheet.paper(DOOR_MAX_R_IN)
    arcs = []
    for it in sheet.geom:
        if not sheet.free(it):
            continue
        pts = it["pts"]
        if len(pts) < 5:
            continue
        found = _arc_in(pts, r_min, r_max)
        if found is None:
            continue
        part, r, parts = found
        # the leaf may already be part of the SAME path (arc + leaf in one go)
        leaf_here = any(len(p) == 2 and abs(_hypot(p[0][0], p[0][1], p[-1][0], p[-1][1]) - r)
                        <= r * DOOR_LEAF_TOL for p in parts if p is not part)
        if leaf_here:
            stats["doors"] += 1
            sheet.take(it, "A-DOOR", 0.85)
            continue
        arcs.append((it, part[0], part[-1], r))
    if not arcs:
        return
    straights = [it for it in sheet.lines
                 if sheet.free(it) and len(it["pts"]) >= 2 and _is_straight(it["pts"])]
    end_grid = defaultdict(list)
    cell = max(DOOR_JOIN_TOL_IN, 1e-4)
    for it in straights:
        for pt in (it["pts"][0], it["pts"][-1]):
            end_grid[(int(pt[0] / cell), int(pt[1] / cell))].append(it)

    for (arc, a_start, a_end, radius) in arcs:
        if not sheet.free(arc):
            continue
        leaf = None
        for end in (a_start, a_end):
            key = (int(end[0] / cell), int(end[1] / cell))
            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    for it in end_grid.get((key[0] + dx, key[1] + dy), ()):
                        if not sheet.free(it):
                            continue
                        pts = it["pts"]
                        length = _hypot(pts[0][0], pts[0][1], pts[-1][0], pts[-1][1])
                        if abs(length - radius) > radius * DOOR_LEAF_TOL:
                            continue
                        if min(_hypot(pts[0][0], pts[0][1], end[0], end[1]),
                               _hypot(pts[-1][0], pts[-1][1], end[0], end[1])) <= DOOR_JOIN_TOL_IN:
                            leaf = it
                            break
                    if leaf:
                        break
                if leaf:
                    break
            if leaf:
                break
        if leaf is None:
            continue
        stats["doors"] += 1
        sheet.take(arc, "A-DOOR", 0.85)
        sheet.take(leaf, "A-DOOR", 0.85)


# --- pass 6: walls ----------------------------------------------------------

def _pass_walls(sheet, runs, stats):
    """Two long parallel runs a wall-thickness apart, plus heavy-pen runs."""
    min_len = sheet.paper(WALL_MIN_LEN_IN)
    t_min = sheet.paper(WALL_MIN_THICK_IN)
    t_max = sheet.paper(WALL_MAX_THICK_IN)
    cand = [r for r in runs if r.length >= min_len and all(sheet.free(it) for it in r.items)]
    if not cand:
        return []
    aq = math.radians(ANGLE_QUANT_DEG)
    max_bucket = int(math.pi / aq) + 1
    by_angle = defaultdict(list)
    for r in cand:
        by_angle[int(r.theta / aq) % max_bucket].append(r)

    ang_tol = math.radians(ANGLE_TOL_DEG)
    paired = []
    used = set()
    for bucket, members in by_angle.items():
        pool = list(members)
        for d in (-1, 1):
            pool += by_angle.get((bucket + d) % max_bucket, [])
        pool.sort(key=lambda r: r.rho)
        for i, a in enumerate(members):
            if id(a) in used:
                continue
            for b in pool:
                if b is a or id(b) in used:
                    continue
                dth = abs(a.theta - b.theta)
                dth = min(dth, math.pi - dth)
                if dth > ang_tol:
                    continue
                offset = abs(a.rho - b.rho)
                if not (t_min <= offset <= t_max):
                    continue
                bt0 = a.project(b.p0)
                bt1 = a.project(b.p1)
                lo, hi = min(bt0, bt1), max(bt0, bt1)
                overlap = min(a.t1, hi) - max(a.t0, lo)
                if overlap < min(a.length, b.length) * WALL_OVERLAP_MIN:
                    continue
                used.add(id(a)); used.add(id(b))
                paired.append((a, b))
                break
    wall_runs = []
    for (a, b) in paired:
        stats["walls"] += 1
        for run in (a, b):
            wall_runs.append(run)
            for it in run.items:
                sheet.take(it, "A-WALL", 0.85)
    # heavy-pen fallback: a long thick run on its own still reads as a wall
    thick_min = sheet.paper(WALL_THICK_PEN_MIN_LEN_IN)
    for r in runs:
        if r.wclass != "thick" or r.length < thick_min:
            continue
        if not all(sheet.free(it) for it in r.items):
            continue
        stats["walls"] += 1
        wall_runs.append(r)
        for it in r.items:
            sheet.take(it, "A-WALL", 0.55)
    _take_wall_extras(sheet, runs, wall_runs)
    return wall_runs


def _take_wall_extras(sheet, runs, wall_runs):
    """Pick up the pieces a wall is chopped into.

    A wall line is broken at every door opening, and the little returns at a
    jamb or a corner are separate paths, so the pairing test only ever claims
    the long middles. Two cheap follow-ups recover the rest:
      * a free run lying ON the same infinite line as a claimed wall run
      * a short free run whose ends both touch claimed wall geometry
    """
    if not wall_runs:
        return
    ang_tol = math.radians(ANGLE_TOL_DEG)
    aq = math.radians(ANGLE_QUANT_DEG)
    max_bucket = int(math.pi / aq) + 1
    by_angle = defaultdict(list)
    for r in wall_runs:
        by_angle[int(r.theta / aq) % max_bucket].append(r)

    min_len = sheet.paper(WALL_EXTRA_MIN_LEN_IN)
    for r in runs:
        if r.length < min_len or not any(sheet.free(it) for it in r.items):
            continue
        bucket = int(r.theta / aq) % max_bucket
        pool = by_angle.get(bucket, [])
        for d in (-1, 1):
            pool = pool + by_angle.get((bucket + d) % max_bucket, [])
        for w in pool:
            dth = abs(r.theta - w.theta)
            dth = min(dth, math.pi - dth)
            if dth > ang_tol or abs(r.rho - w.rho) > COLLINEAR_RHO_TOL_IN * 2:
                continue
            # must be near the wall along the line too, not a mile away on it
            t = (r.t0 + r.t1) / 2
            near = max(w.t0 - WALL_EXTRA_REACH_IN, min(t, w.t1 + WALL_EXTRA_REACH_IN))
            if abs(near - t) > 1e-9:
                continue
            for it in r.items:
                sheet.take(it, "A-WALL", 0.6)
            break

    # short returns/jambs bridging two claimed wall pieces
    cell = max(WALL_JOIN_TOL_IN, 1e-4)
    ends = defaultdict(list)
    for w in wall_runs:
        for pt in (w.p0, w.p1):
            ends[(int(pt[0] / cell), int(pt[1] / cell))].append(pt)
    max_return = sheet.paper(WALL_MAX_THICK_IN) * WALL_RETURN_FACTOR
    for r in runs:
        if r.length > max_return or not any(sheet.free(it) for it in r.items):
            continue
        touching = 0
        for pt in (r.p0, r.p1):
            key = (int(pt[0] / cell), int(pt[1] / cell))
            hit = False
            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    for other in ends.get((key[0] + dx, key[1] + dy), ()):
                        if _hypot(pt[0], pt[1], other[0], other[1]) <= WALL_JOIN_TOL_IN:
                            hit = True
                            break
                    if hit:
                        break
                if hit:
                    break
            touching += 1 if hit else 0
        if touching == 2:
            for it in r.items:
                sheet.take(it, "A-WALL", 0.55)


# --- pass 7: windows --------------------------------------------------------

def _pass_windows(sheet, runs, wall_runs, stats):
    """A window is the 2-3 parallel lines that bridge a gap between two
    collinear wall runs. Genuinely weaker than the other tests: the same
    pattern also appears at cased openings and at some door frames."""
    if not wall_runs:
        return
    w_min = sheet.paper(WINDOW_MIN_W_IN)
    w_max = sheet.paper(WINDOW_MAX_W_IN)
    t_max = sheet.paper(WALL_MAX_THICK_IN)
    ang_tol = math.radians(ANGLE_TOL_DEG)

    groups = defaultdict(list)
    aq = math.radians(ANGLE_QUANT_DEG)
    for r in wall_runs:
        groups[(int(r.theta / aq), int(round(r.rho / (RHO_QUANT_IN * 2))))].append(r)

    for members in groups.values():
        if len(members) < 2:
            continue
        members.sort(key=lambda r: r.t0)
        for i in range(len(members) - 1):
            a, b = members[i], members[i + 1]
            gap = b.t0 - a.t1
            if not (w_min <= gap <= w_max):
                continue
            g0, g1 = a.t1, b.t0
            found = []
            for r in runs:
                if not all(sheet.free(it) for it in r.items):
                    continue
                dth = abs(r.theta - a.theta)
                dth = min(dth, math.pi - dth)
                if dth > ang_tol:
                    continue
                if abs(r.rho - a.rho) > t_max:
                    continue
                t0 = a.project(r.p0)
                t1 = a.project(r.p1)
                lo, hi = min(t0, t1), max(t0, t1)
                if lo < g0 - w_min * 0.25 or hi > g1 + w_min * 0.25:
                    continue
                if (hi - lo) < gap * 0.5:
                    continue
                found.append(r)
            if len(found) >= WINDOW_MIN_LINES:
                stats["windows"] += 1
                for r in found:
                    for it in r.items:
                        sheet.take(it, "A-WINDOW", 0.5)


# --- pass 8: columns --------------------------------------------------------

def _pass_columns(sheet, stats):
    lo = sheet.paper(COL_MIN_SIZE_IN)
    hi = sheet.paper(COL_MAX_SIZE_IN)
    quant = sheet.paper(COL_SIZE_QUANT_IN)
    align = sheet.paper(COL_ALIGN_TOL_IN)
    cand = []
    for it in sheet.geom:
        if not sheet.free(it):
            continue
        pts = it["pts"]
        if len(pts) < 4:
            continue
        w = it["x1"] - it["x0"]
        h = it["y1"] - it["y0"]
        size = max(w, h)
        if not (lo <= size <= hi) or min(w, h) < lo * 0.4:
            continue
        if it["kind"] == "line" and not _is_closed(pts):
            continue
        cand.append((it, w, h))
    if len(cand) < COL_MIN_REPEATS:
        return
    groups = defaultdict(list)
    for (it, w, h) in cand:
        groups[(int(round(w / quant)), int(round(h / quant)))].append(it)
    for members in groups.values():
        if len(members) < COL_MIN_REPEATS:
            continue
        xs = [(m["x0"] + m["x1"]) / 2 for m in members]
        ys = [(m["y0"] + m["y1"]) / 2 for m in members]
        aligned = _max_cluster(xs, align) >= 3 or _max_cluster(ys, align) >= 3
        conf = 0.8 if aligned else 0.6
        for m in members:
            if sheet.take(m, "A-COLS", conf):
                stats["columns"] += 1


def _pass_hatch_field(sheet, runs):
    """Tight bundles of evenly spaced parallel strokes = a hatch pattern
    (rated-wall poche, section fill), not linework anybody wants to trace."""
    aq = math.radians(ANGLE_QUANT_DEG)
    max_bucket = int(math.pi / aq) + 1
    by_angle = defaultdict(list)
    for r in runs:
        if all(sheet.free(it) for it in r.items):
            by_angle[int(r.theta / aq) % max_bucket].append(r)
    for members in by_angle.values():
        if len(members) < HATCH_FIELD_MIN_LINES:
            continue
        members.sort(key=lambda r: r.rho)
        i = 0
        while i < len(members):
            bundle = [members[i]]
            j = i + 1
            while j < len(members):
                pitch = members[j].rho - members[j - 1].rho
                if pitch <= 0 or pitch > HATCH_FIELD_MAX_PITCH_IN:
                    break
                if not _spans_overlap(bundle[-1], members[j]):
                    break
                bundle.append(members[j])
                j += 1
            if len(bundle) >= HATCH_FIELD_MIN_LINES:
                pitches = [bundle[k + 1].rho - bundle[k].rho for k in range(len(bundle) - 1)]
                mean = sum(pitches) / len(pitches)
                var = math.sqrt(sum((p - mean) ** 2 for p in pitches) / len(pitches))
                if mean > 1e-9 and var / mean <= HATCH_FIELD_PITCH_VAR:
                    for r in bundle:
                        for it in r.items:
                            sheet.take(it, "A-HATCH", 0.6)
            i = max(j, i + 1)


def _spans_overlap(a, b):
    t0 = a.project(b.p0)
    t1 = a.project(b.p1)
    return min(a.t1, max(t0, t1)) - max(a.t0, min(t0, t1)) > 0


def _max_cluster(values, tol):
    if not values:
        return 0
    vs = sorted(values)
    best = run = 1
    for i in range(1, len(vs)):
        run = run + 1 if vs[i] - vs[i - 1] <= tol else 1
        best = max(best, run)
    return best


# --- pass 9: room names -----------------------------------------------------

def _pass_rooms(sheet):
    free_geom = [it for it in sheet.geom if sheet.free(it)]
    cell = 0.5
    grid = defaultdict(list)
    for it in free_geom:
        c0 = int(math.floor(it["x0"] / cell)); c1 = int(math.floor(it["x1"] / cell))
        r0 = int(math.floor(it["y0"] / cell)); r1 = int(math.floor(it["y1"] / cell))
        if (c1 - c0 + 1) * (r1 - r0 + 1) > 4000:
            continue
        for c in range(c0, c1 + 1):
            for r in range(r0, r1 + 1):
                grid[(c, r)].append(it)

    def clear_of_linework(box):
        c0 = int(math.floor((box[0] - ROOM_CLEAR_IN) / cell))
        c1 = int(math.floor((box[2] + ROOM_CLEAR_IN) / cell))
        r0 = int(math.floor((box[1] - ROOM_CLEAR_IN) / cell))
        r1 = int(math.floor((box[3] + ROOM_CLEAR_IN) / cell))
        for c in range(c0, c1 + 1):
            for r in range(r0, r1 + 1):
                for it in grid.get((c, r), ()):
                    if _boxes_touch((it["x0"], it["y0"], it["x1"], it["y1"]), box, ROOM_CLEAR_IN):
                        return False
        return True

    for t in sheet.texts:
        if not sheet.free(t):
            continue
        txt = (t["text"] or "").strip()
        letters = re.sub(r"[^A-Za-z]", "", txt)
        if len(letters) < ROOM_MIN_LETTERS or letters != letters.upper():
            continue
        if not ROOM_TEXT_RE.match(txt):
            continue
        box = (t["x0"], t["y0"], t["x1"], t["y1"])
        if not clear_of_linework(box):
            continue
        sheet.take(t, "A-ROOM", 0.55)


# --- pass 10: annotation + leaders -----------------------------------------

def _pass_annotation(sheet):
    boxes = []
    for t in sheet.texts:
        if sheet.free(t):
            sheet.take(t, "A-ANNO", 0.6)
        if sheet.assign.get(t["ref"]) in ("A-ANNO", "A-ROOM"):
            boxes.append((t["x0"], t["y0"], t["x1"], t["y1"]))
    if not boxes:
        return
    cell = 0.5
    grid = defaultdict(list)
    for box in boxes:
        c0 = int(math.floor(box[0] / cell)); c1 = int(math.floor(box[2] / cell))
        r0 = int(math.floor(box[1] / cell)); r1 = int(math.floor(box[3] / cell))
        for c in range(c0, c1 + 1):
            for r in range(r0, r1 + 1):
                grid[(c, r)].append(box)

    for it in sheet.lines:
        if not sheet.free(it):
            continue
        pts = it["pts"]
        if len(pts) < 2 or len(pts) > 6:
            continue
        for end in (pts[0], pts[-1]):
            key = (int(math.floor(end[0] / cell)), int(math.floor(end[1] / cell)))
            hit = False
            for dc in (-1, 0, 1):
                for dr in (-1, 0, 1):
                    for box in grid.get((key[0] + dc, key[1] + dr), ()):
                        if (box[0] - LEADER_TOUCH_IN <= end[0] <= box[2] + LEADER_TOUCH_IN
                                and box[1] - LEADER_TOUCH_IN <= end[1] <= box[3] + LEADER_TOUCH_IN):
                            hit = True
                            break
                    if hit:
                        break
                if hit:
                    break
            if hit:
                sheet.take(it, "A-ANNO", 0.55)
                break


# --- pass 11: furniture -----------------------------------------------------

def _pass_furniture(sheet):
    hi = sheet.paper(FURN_MAX_SIZE_IN)
    for it in sheet.geom:
        if not sheet.free(it):
            continue
        pts = it["pts"]
        if len(pts) < 4:
            continue
        size = max(it["x1"] - it["x0"], it["y1"] - it["y0"])
        if size > hi:
            continue
        if it["kind"] == "fill" or _is_closed(pts):
            sheet.take(it, "A-FURN", 0.4)
        elif not _is_straight(pts):
            # an open curvy little shape (a fixture, a tread, an arc detail) is
            # still furniture-grade clutter, just a less certain call
            sheet.take(it, "A-FURN", 0.3)


# --- pass 12/13: fills, then everything left -------------------------------

def _pass_outlined_text(sheet):
    """Note blocks that were plotted as outlined glyphs rather than real text.

    They arrive as thousands of tiny unrelated strokes; left alone they are the
    single biggest source of A-MISC on sheets from those plotters. A horizontal
    band packed with tiny strokes is a line of text, so call it annotation."""
    pool = [it for it in sheet.geom
            if sheet.free(it)
            and max(it["x1"] - it["x0"], it["y1"] - it["y0"]) <= GLYPH_MAX_SIZE_IN]
    if len(pool) < GLYPH_MIN_IN_RUN:
        return
    pool.sort(key=lambda it: (it["y0"] + it["y1"]) / 2)
    bands = []
    band = [pool[0]]
    last = (pool[0]["y0"] + pool[0]["y1"]) / 2
    for it in pool[1:]:
        yc = (it["y0"] + it["y1"]) / 2
        if yc - last <= GLYPH_BAND_TOL_IN:
            band.append(it)
        else:
            bands.append(band)
            band = [it]
        last = yc
    bands.append(band)

    for band in bands:
        if len(band) < GLYPH_MIN_IN_RUN:
            continue
        band.sort(key=lambda it: it["x0"])
        run = [band[0]]
        for it in band[1:]:
            if it["x0"] - run[-1]["x1"] <= GLYPH_RUN_GAP_IN:
                run.append(it)
            else:
                _take_glyph_run(sheet, run)
                run = [it]
        _take_glyph_run(sheet, run)


def _take_glyph_run(sheet, run):
    if len(run) < GLYPH_MIN_IN_RUN:
        return
    span = max(it["x1"] for it in run) - min(it["x0"] for it in run)
    if span < GLYPH_MIN_RUN_SPAN_IN:
        return
    for it in run:
        sheet.take(it, "A-ANNO", 0.4)


def _pass_fills(sheet):
    for it in sheet.fills:
        sheet.take(it, "A-FILL", 0.7)


def _pass_misc(sheet):
    for it in sheet.items:
        sheet.take(it, "A-MISC", 0.0)


# --- picker helper ----------------------------------------------------------

def preset_selection(layer_names, preset="sprinkler"):
    """Layer names the "For sprinkler design" preset turns ON."""
    if preset != "sprinkler":
        return list(layer_names)
    on = []
    for name in layer_names:
        if name in SPRINKLER_PRESET_OFF:
            continue
        if name in SPRINKLER_PRESET_ON or name.startswith(LEGEND_PREFIX):
            on.append(name)
    return on
