# -*- coding: utf-8 -*-
"""AI layers for PDF-to-CAD: turn the smart classifier's per-entity result into
a small number of REVIEWABLE GROUPS, and apply the user's clean-up decisions.

Why groups at all? ``pdf_to_cad_smart`` names every polyline individually - a
dense sheet is 60,000 of them. Neither a language model nor a human can review
60,000 things. What both CAN review is "this rectangle of A-MISC linework in
the north-east corner, 420 objects, sample text 'STAIR 2'". So:

  1. ``build_groups()`` clusters the classified items into spatial clusters
     WITHIN each heuristic layer (grid connected-components on item centres),
     caps the count at ``MAX_GROUPS`` by merging the smallest neighbours, and
     gives each cluster a stable id and a signature.
  2. The caller draws each group's bbox + id on a raster of the sheet and asks
     Claude what each one actually is (cloud_api/pdfcad_ai.py).
  3. ``apply_overrides()`` folds the AI's answer - and every rename / merge /
     delete the user then performs in the review view - back onto the per-entity
     assignment, so ``pdf_to_cad.convert`` writes exactly what the picker showed.

**This module is stdlib-only, on purpose** - the Web Edition runs the same code
inside Pyodide (see packaging/build_seismic_web_bundle.py), and there is a test
that fails if a third-party import appears anywhere in the file, including
inside a function. The Pillow overlay renderer therefore lives in its own
desktop-only module, ``pdf_to_cad_overlay``.

STABILITY IS THE CONTRACT. ``analyze`` builds the groups, the user reviews them,
and ``convert`` - a separate request, possibly minutes later - rebuilds them from
the same PDF and must get the SAME ids, or the user's deletions land on the wrong
linework. Everything here is therefore a pure function of the items, the
assignment and the page size, with all ordering made explicit.

Units: paper inches, like the rest of the converter.
"""
from __future__ import annotations

import hashlib
from collections import Counter, defaultdict

MAX_GROUPS = 250

# Clustering cell, as a fraction of the sheet's long edge. 1/40 of a 36" sheet is
# ~0.9 paper inches - about 7 ft of building at 1/8" = 1'-0". Small enough that
# two separate stair cores do not merge, big enough that one room's worth of
# linework does not shatter into fifty groups.
CELL_FRACTION = 1.0 / 40.0
CELL_MIN_IN = 0.25

MAX_SAMPLE_TEXT = 5
MAX_TEXT_CHARS = 60

# An item whose bbox is this fraction of the page or more is "sheet-wide" (the
# border, a full-span grid line). Those are clustered by their centre like
# everything else; the note is here so the behaviour is deliberate rather than
# accidental - a sheet-wide item lands in ONE group, it does not smear its layer
# into a single blob.
_KIND_LABEL = {"line": "linework", "fill": "fill", "text": "text"}


# --------------------------------------------------------------------------
# grouping
# --------------------------------------------------------------------------

class _Union(object):
    """Tiny union-find over hashable keys (no numpy in Pyodide)."""

    def __init__(self):
        self.parent = {}

    def find(self, key):
        parent = self.parent
        root = parent.setdefault(key, key)
        while root != parent[root]:
            root = parent[root]
        while parent[key] != root:       # path compression, iterative
            parent[key], key = root, parent[key]
        return root

    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self.parent[rb] = ra


def _cell_size(page_w, page_h):
    return max(float(max(page_w, page_h)) * CELL_FRACTION, CELL_MIN_IN)


def _centre(item):
    return (item["x0"] + item["x1"]) * 0.5, (item["y0"] + item["y1"]) * 0.5


def _merge_bbox(a, b):
    return (min(a[0], b[0]), min(a[1], b[1]), max(a[2], b[2]), max(a[3], b[3]))


def _bbox_centre(box):
    return (box[0] + box[2]) * 0.5, (box[1] + box[3]) * 0.5


class _Cluster(object):
    __slots__ = ("layer", "bbox", "refs", "kinds", "texts", "conf_sum", "conf_n")

    def __init__(self, layer):
        self.layer = layer
        self.bbox = None
        self.refs = []
        self.kinds = Counter()
        self.texts = []
        self.conf_sum = 0.0
        self.conf_n = 0

    def add_item(self, item, confidence):
        box = (item["x0"], item["y0"], item["x1"], item["y1"])
        self.bbox = box if self.bbox is None else _merge_bbox(self.bbox, box)
        self.refs.append(item["ref"])
        self.kinds[item.get("kind") or "line"] += 1
        text = str(item.get("text") or "").strip()
        if text:
            self.texts.append(text[:MAX_TEXT_CHARS])
        if confidence is not None:
            self.conf_sum += float(confidence)
            self.conf_n += 1

    def absorb(self, other):
        self.bbox = other.bbox if self.bbox is None else (
            self.bbox if other.bbox is None else _merge_bbox(self.bbox, other.bbox))
        self.refs.extend(other.refs)
        self.kinds.update(other.kinds)
        self.texts.extend(other.texts)
        self.conf_sum += other.conf_sum
        self.conf_n += other.conf_n

    @property
    def count(self):
        return len(self.refs)

    @property
    def confidence(self):
        return (self.conf_sum / self.conf_n) if self.conf_n else 0.0


def _cluster_one_layer(layer, items, assign, cell):
    """Grid connected-components on item CENTRES (8-neighbour).

    Centres, not bboxes: a single 200 ft wall run would otherwise bridge every
    cell it crosses and glue the whole layer into one blob. Centres keep two
    distant stair cores apart while still joining the linework of one room."""
    buckets = defaultdict(list)
    for item in items:
        cx, cy = _centre(item)
        buckets[(int(cx // cell), int(cy // cell))].append(item)

    union = _Union()
    for key in buckets:
        union.find(key)
    for (ix, iy) in list(buckets):
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                if dx == 0 and dy == 0:
                    continue
                other = (ix + dx, iy + dy)
                if other in buckets:
                    union.union((ix, iy), other)

    clusters = {}
    for key, bucket in buckets.items():
        root = union.find(key)
        cluster = clusters.get(root)
        if cluster is None:
            cluster = clusters[root] = _Cluster(layer)
        for item in bucket:
            got = assign.get(item["ref"]) or {}
            cluster.add_item(item, got.get("confidence"))
    return list(clusters.values())


def _cap_groups(clusters, max_groups):
    """Merge the smallest clusters into their nearest same-layer neighbour until
    there are at most ``max_groups`` of them.

    Deterministic: ties on size break on the bbox, ties on distance break on the
    neighbour's bbox, so the same sheet always caps the same way."""
    if len(clusters) <= max_groups:
        return clusters
    alive = list(clusters)
    while len(alive) > max_groups:
        alive.sort(key=lambda c: (c.count, c.bbox or (0, 0, 0, 0)))
        merged = False
        for i, small in enumerate(alive):
            candidates = [c for c in alive if c is not small and c.layer == small.layer]
            if not candidates:
                continue
            sx, sy = _bbox_centre(small.bbox or (0, 0, 0, 0))
            best = min(candidates, key=lambda c: (
                (_bbox_centre(c.bbox or (0, 0, 0, 0))[0] - sx) ** 2
                + (_bbox_centre(c.bbox or (0, 0, 0, 0))[1] - sy) ** 2,
                c.bbox or (0, 0, 0, 0)))
            best.absorb(small)
            alive.pop(i)
            merged = True
            break
        if not merged:
            # Every remaining layer holds exactly one cluster and there are still
            # too many layers. Merge the two smallest across layers rather than
            # loop forever; the merged group keeps the larger one's layer.
            alive.sort(key=lambda c: (c.count, c.bbox or (0, 0, 0, 0)))
            small = alive.pop(0)
            alive[0].absorb(small)
    return alive


def _signature(cluster, page_w, page_h):
    """Small, sheet-relative description of a group. This is what gets stored as
    training data - it must carry no file path and no customer text beyond the
    few sampled strings the classifier already saw."""
    x0, y0, x1, y1 = cluster.bbox or (0.0, 0.0, 0.0, 0.0)
    w = float(page_w) or 1.0
    h = float(page_h) or 1.0
    return {
        "layer": cluster.layer,
        "bbox": [round(x0 / w, 4), round(y0 / h, 4), round(x1 / w, 4), round(y1 / h, 4)],
        "count": cluster.count,
        "kinds": sorted(cluster.kinds),
        "textSample": _sample_text(cluster.texts),
    }


def _sample_text(texts):
    """Up to MAX_SAMPLE_TEXT distinct strings, longest first - the long ones are
    the ones that actually say what a region is ('STAIR 2', not 'A')."""
    seen = []
    for text in sorted(set(texts), key=lambda t: (-len(t), t)):
        seen.append(text)
        if len(seen) >= MAX_SAMPLE_TEXT:
            break
    return seen


def build_groups(items, assign, page_w, page_h, max_groups=MAX_GROUPS):
    """Cluster classified items into reviewable groups.

    ``items``  - the plain dicts from ``pdf_to_cad._smart_items``.
    ``assign`` - ``{ref: {"layer": name, "confidence": 0..1}}`` from the smart
                 classifier. Items with no assignment are skipped (they are not
                 going into the DXF either).

    Returns ``{"groups": [...], "refGroup": {ref: id}, "sheetHash": "..."}``.
    Each group: ``id, heuristicLayer, confidence, bbox (page inches), count,
    kind, sampleText, legendText?, signature``.
    """
    cell = _cell_size(page_w, page_h)
    by_layer = defaultdict(list)
    for item in items:
        got = assign.get(item["ref"])
        if not got:
            continue
        by_layer[str(got.get("layer") or "A-MISC")].append(item)

    clusters = []
    for layer in sorted(by_layer):
        clusters.extend(_cluster_one_layer(layer, by_layer[layer], assign, cell))
    clusters = _cap_groups(clusters, int(max_groups or MAX_GROUPS))

    # Stable ids: layer, then top-to-bottom, then left-to-right. A PDF's y axis
    # runs up, so "top of the sheet first" is descending y.
    clusters.sort(key=lambda c: (c.layer,
                                 -round((c.bbox or (0, 0, 0, 0))[3], 4),
                                 round((c.bbox or (0, 0, 0, 0))[0], 4),
                                 -c.count))

    groups = []
    ref_group = {}
    for index, cluster in enumerate(clusters):
        # Ids are plain 1-based numbers because they are DRAWN ON THE SHEET for
        # the model to read. "137" is legible at 12 px in a corner of a bbox;
        # "g0137" is not, and a misread id silently relabels the wrong linework.
        gid = str(index + 1)
        x0, y0, x1, y1 = cluster.bbox or (0.0, 0.0, 0.0, 0.0)
        kind = _KIND_LABEL.get(cluster.kinds.most_common(1)[0][0], "linework") if cluster.kinds else "linework"
        row = {
            "id": gid,
            "heuristicLayer": cluster.layer,
            "confidence": round(cluster.confidence, 3),
            "bbox": [round(x0, 3), round(y0, 3), round(x1, 3), round(y1, 3)],
            "count": cluster.count,
            "kind": kind,
            "sampleText": _sample_text(cluster.texts),
            "signature": _signature(cluster, page_w, page_h),
        }
        if cluster.layer.startswith("L-"):
            # legend layers are named after the sheet's own legend row; hand the
            # model that text, it is the best evidence there is for those.
            row["legendText"] = cluster.layer[2:].replace("-", " ").strip()
        groups.append(row)
        for ref in cluster.refs:
            ref_group[ref] = gid

    return {"groups": groups, "refGroup": ref_group,
            "sheetHash": sheet_hash(groups, page_w, page_h)}


def sheet_hash(groups, page_w, page_h):
    """A stable, anonymous fingerprint of this sheet's SHAPE.

    Built only from the page size and the per-layer object counts - no file name,
    no path, no sheet text. It is what ties the stored training labels for one
    sheet together without recording whose drawing it was."""
    counts = Counter()
    for row in groups:
        counts[row["heuristicLayer"]] += int(row["count"])
    parts = ["%.2fx%.2f" % (float(page_w), float(page_h))]
    parts += ["%s=%d" % (name, counts[name]) for name in sorted(counts)]
    return hashlib.sha1("|".join(parts).encode("utf-8")).hexdigest()[:24]


# --------------------------------------------------------------------------
# overrides
# --------------------------------------------------------------------------

def normalize_overrides(raw):
    """Coerce whatever the front end sent into ``{gid: {"layer", "delete"}}``.

    Tolerant on purpose: an override map arrives over HTTP from two different
    front ends, and a stray key must degrade to "no change", never to a crash or
    to a silently wrong layer name."""
    out = {}
    if not isinstance(raw, dict):
        return out
    for gid, value in raw.items():
        gid = str(gid or "").strip()
        if not gid:
            continue
        if isinstance(value, str):
            value = {"layer": value}
        if not isinstance(value, dict):
            continue
        layer = value.get("layer")
        layer = str(layer).strip() if layer else ""
        entry = {"delete": bool(value.get("delete"))}
        if layer:
            entry["layer"] = sanitize_layer_name(layer)
        out[gid] = entry
    return out


# DXF R12 layer names: uppercase, no spaces, and none of $ # % ( ) { } [ ] ; , = .
_LAYER_BAD = set(' \t\r\n"\'*|<>?/\\:;,=`~!@$%^&()[]{}+')


def sanitize_layer_name(name, fallback="A-MISC"):
    """A valid, recognisable DXF layer name. Same spirit as
    ``pdf_to_cad._dxf_layer_from_name`` but applied to user input, before the
    writer ever sees it, so the picker shows exactly what lands in the file."""
    text = str(name or "").strip().upper()
    cleaned = "".join("-" if ch in _LAYER_BAD else ch for ch in text)
    while "--" in cleaned:
        cleaned = cleaned.replace("--", "-")
    cleaned = cleaned.strip("-")[:31]
    return cleaned or fallback


def apply_overrides(assign, ref_group, overrides):
    """Fold the review view's decisions onto the per-entity assignment.

    Returns ``(assign2, stats)``. ``assign2`` is a NEW dict - the caller's is
    untouched - with deleted groups' entities removed and moved groups' entities
    re-pointed at their new layer. ``stats`` reports what happened so the UI can
    say "dropped 4,120 objects" honestly rather than guessing."""
    overrides = normalize_overrides(overrides)
    if not overrides:
        return dict(assign), {"deleted": 0, "moved": 0, "groups": 0}

    out = {}
    deleted = moved = 0
    touched = set()
    for ref, got in assign.items():
        gid = ref_group.get(ref)
        rule = overrides.get(gid) if gid else None
        if rule is None:
            out[ref] = got
            continue
        touched.add(gid)
        if rule.get("delete"):
            deleted += 1
            continue
        layer = rule.get("layer")
        if layer and layer != got.get("layer"):
            row = dict(got)
            row["layer"] = layer
            row["aiOverride"] = True
            out[ref] = row
            moved += 1
        else:
            out[ref] = got
    return out, {"deleted": deleted, "moved": moved, "groups": len(touched)}


def final_layers(groups, overrides):
    """What the picker should list after the AI + the user have had their say:
    ``[{"name", "count", "groups": [id...], "source": "ai"|"heuristic"}]``."""
    overrides = normalize_overrides(overrides)
    rows = {}
    for group in groups:
        rule = overrides.get(group["id"]) or {}
        if rule.get("delete"):
            continue
        name = rule.get("layer") or group["heuristicLayer"]
        row = rows.get(name)
        if row is None:
            row = rows[name] = {"name": name, "count": 0, "groups": [], "source": "heuristic"}
        row["count"] += int(group.get("count") or 0)
        row["groups"].append(group["id"])
        if rule.get("layer"):
            row["source"] = "ai"
    return sorted(rows.values(), key=lambda r: (-r["count"], r["name"]))


# --------------------------------------------------------------------------
# cost estimate (shown BEFORE the call - the owner should never be surprised)
# --------------------------------------------------------------------------

# Calibrated against a real 42x30 architectural sheet (133 groups, 4 tiles):
# 17,306 input / 6,621 output tokens. An image costs about width*height/750
# tokens, so a 1568x1120 tile is ~2,340; each group's prompt line is ~40 in and
# the model writes back ~55 per group (id, label, confidence, a short reason).
TOKENS_PER_TILE = 2400
TOKENS_PER_GROUP = 40
TOKENS_PROMPT_BASE = 700
TOKENS_OUT_PER_GROUP = 55


def estimate_tokens(tiles, group_count):
    """Rough INPUT-token estimate for one classify call."""
    return int(TOKENS_PROMPT_BASE
               + max(1, int(tiles)) * TOKENS_PER_TILE
               + max(0, int(group_count)) * TOKENS_PER_GROUP)


def estimate_output_tokens(group_count):
    """Rough OUTPUT-token estimate. Output is the expensive half per token, so a
    cost shown to the owner that ignored it would be roughly half the truth."""
    return int(max(0, int(group_count)) * TOKENS_OUT_PER_GROUP)
